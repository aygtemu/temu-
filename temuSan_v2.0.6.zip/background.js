// IndexedDB存储
let db;
let isActivated = false;
let isSingleVersion = true; // 默认为单采版
let expireDate = null; // 过期日期
let lastUpdateCheckTime = 0;
const UPDATE_CHECK_INTERVAL = 0; // 关闭时间间隔节流，便于测试

// 保存激活状态
function saveActivationStatus(isActivated, machineCode, expireDate, version, activationCode) {
  const dataToSave = {
    pluginActivated: isActivated,
    activatedMachineCode: machineCode,
    activationDate: new Date().toISOString(),
    pluginVersion: version,
    usedActivationCode: activationCode // 保存使用的激活码
  };
  
  // 如果有到期时间，也保存到期时间
  if (expireDate) {
    dataToSave.expireDate = expireDate;
  }
  
  chrome.storage.local.set(dataToSave, () => {
    console.log('激活状态已保存:', { isActivated, machineCode, version, expireDate, activationCode });
    
    // 如果是激活操作，将激活码添加到已使用列表
    if (isActivated && activationCode) {
      addUsedActivationCode(activationCode);
    }
    
    if (!isActivated) {
      console.log('插件已过期，自动设置为未激活状态');
    }
  });
}

// 添加已使用的激活码到记录
function addUsedActivationCode(activationCode) {
  try {
    // 从chrome.storage.local读取已使用的激活码信息
    chrome.storage.local.get(['usedActivationCodes'], (result) => {
      try {
        const usedCodesArray = result.usedActivationCodes || [];
        
        // 如果激活码不在列表中，则添加
        if (!usedCodesArray.includes(activationCode)) {
          usedCodesArray.push(activationCode);
          // 保存更新后的列表
          chrome.storage.local.set({ 'usedActivationCodes': usedCodesArray }, () => {
            console.log('激活码已添加到已使用列表');
          });
        }
      } catch (innerError) {
        console.error('处理已使用激活码时发生错误:', innerError);
      }
    });
  } catch (error) {
    console.error('保存已使用激活码失败:', error);
  }
}

// 初始化激活状态检查
function checkActivationStatus() {
  return new Promise((resolve) => {
    try {
      chrome.storage.local.get(['pluginActivated', 'pluginVersion', 'expireDate', 'usedActivationCode', 'activatedMachineCode'], (result) => {
        try {
          // 确保result对象存在
          if (!result) {
            console.warn('存储结果为空，使用默认值');
            result = {};
          }
          
          // 初始化激活状态
          isActivated = !!result.pluginActivated; // 明确转换为布尔值
          
          // 根据存储的版本信息设置isSingleVersion
          if (result.pluginVersion) {
            isSingleVersion = (result.pluginVersion === 'single');
          } else {
            // 如果没有版本信息，默认为单采版
            isSingleVersion = true;
            console.log('未找到版本信息，默认为单采版');
          }
          
          // 检查是否已过期
          if (isActivated && result.expireDate) {
            try {
              expireDate = new Date(result.expireDate);
              // 检查日期是否有效
              if (isNaN(expireDate.getTime())) {
                console.error('存储的过期日期无效:', result.expireDate);
                expireDate = null;
                isActivated = false;
                saveActivationStatus(false, result.activatedMachineCode || '', null, result.pluginVersion || 'single', null);
              } else {
                const now = new Date();
                if (now > expireDate) {
                  // 已过期，设置为未激活状态
                  isActivated = false;
                  // 更新存储中的激活状态
                  saveActivationStatus(false, result.activatedMachineCode || '', null, result.pluginVersion || 'single', null);
                }
              }
            } catch (dateError) {
              console.error('解析过期日期失败:', dateError);
              expireDate = null;
              isActivated = false;
              saveActivationStatus(false, result.activatedMachineCode || '', null, result.pluginVersion || 'single', null);
            }
          } else {
            expireDate = null;
            // 如果有激活状态但没有过期日期，考虑它是有效的激活
            if (isActivated && !result.expireDate) {
              console.log('插件已激活但没有设置过期日期');
            }
          }
          
          // 额外的一致性检查
          if (isActivated && !result.usedActivationCode) {
            console.warn('插件标记为已激活但没有保存的激活码');
          }
          
          console.log('插件激活状态检查完成:', {
            isActivated: isActivated,
            isSingleVersion: isSingleVersion,
            expireDate: expireDate ? expireDate.toISOString() : null,
            hasActivationCode: !!result.usedActivationCode
          });
          
          resolve();
        } catch (innerError) {
          console.error('检查激活状态时发生内部错误:', innerError);
          // 出错时设置为安全的默认状态
          isActivated = false;
          isSingleVersion = true;
          expireDate = null;
          resolve();
        }
      });
    } catch (error) {
      console.error('获取激活状态时发生错误:', error);
      // 出错时设置为安全的默认状态
      isActivated = false;
      isSingleVersion = true;
      expireDate = null;
      resolve();
    }
  });
}

// 初始化时检查激活状态
checkActivationStatus();

// 监听存储变化，更新激活状态和版本信息
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === 'local') {
    if (changes.pluginActivated) {
      isActivated = changes.pluginActivated.newValue || false;
    }
    
    if (changes.pluginVersion) {
      isSingleVersion = (changes.pluginVersion.newValue === 'single');
      console.log('插件版本更新为:', isSingleVersion ? '单采版' : '批采版');
    }
    
    if (changes.expireDate) {
      expireDate = changes.expireDate.newValue ? new Date(changes.expireDate.newValue) : null;
    }
  }
});

function initDB() {
  return new Promise((resolve, reject) => {
    try {
      // 首次不带版本打开，避免因历史高版本导致的VersionError
      const request = indexedDB.open('temu_collector');

      // 如果数据库不存在或需要升级，会触发此回调
      request.onupgradeneeded = function (e) {
        try {
          db = e.target.result;
          // 确保 products 仓库存在，并创建必要索引
          let productStore;
          if (!db.objectStoreNames.contains('products')) {
            productStore = db.createObjectStore('products', { keyPath: 'id' });
          } else {
            productStore = e.target.transaction.objectStore('products');
          }
          // 新增：按规范化图片链接的索引，加速去重与查询
          if (productStore && !productStore.indexNames.contains('imgKey')) {
            productStore.createIndex('imgKey', 'imgKey', { unique: false });
          }

          if (!db.objectStoreNames.contains('recycle_bin')) {
            const recycleStore = db.createObjectStore('recycle_bin', { keyPath: 'id' });
            recycleStore.createIndex('deletedAt', 'deletedAt', { unique: false });
          }
        } catch (error) {
          console.error('数据库升级失败:', error);
          reject(error);
        }
      };

      request.onsuccess = function (e) {
        try {
          db = e.target.result;
          const hasProducts = db.objectStoreNames.contains('products');
          const hasRecycle = db.objectStoreNames.contains('recycle_bin');

          // 如果对象仓库都存在，直接完成
          if (hasProducts && hasRecycle) {
            resolve();
            return;
          }

          // 否则进行一次条件升级：关闭后以currentVersion+1重新打开
          const currentVersion = db.version || 1;
          db.close();

          const upgradeRequest = indexedDB.open('temu_collector', currentVersion + 1);
          upgradeRequest.onupgradeneeded = function (ev) {
            const upgradeDb = ev.target.result;
            // 确保 products 仓库及索引
            let productStore;
            if (!upgradeDb.objectStoreNames.contains('products')) {
              productStore = upgradeDb.createObjectStore('products', { keyPath: 'id' });
            } else {
              productStore = ev.target.transaction.objectStore('products');
            }
            if (productStore && !productStore.indexNames.contains('imgKey')) {
              productStore.createIndex('imgKey', 'imgKey', { unique: false });
            }

            if (!upgradeDb.objectStoreNames.contains('recycle_bin')) {
              const recycleStore = upgradeDb.createObjectStore('recycle_bin', { keyPath: 'id' });
              recycleStore.createIndex('deletedAt', 'deletedAt', { unique: false });
            }
          };
          upgradeRequest.onsuccess = function (ev) {
            db = ev.target.result;
            resolve();
          };
          upgradeRequest.onerror = function (errEv) {
            console.error('数据库升级打开失败:', errEv?.target?.error || errEv);
            reject(errEv?.target?.error || errEv);
          };
        } catch (successErr) {
          console.error('初始化数据库成功回调处理失败:', successErr);
          reject(successErr);
        }
      };

      request.onerror = function (e) {
        console.error('数据库打开失败:', e?.target?.error || e);
        reject(e?.target?.error || e);
      };
    } catch (outerErr) {
      console.error('初始化数据库异常:', outerErr);
      reject(outerErr);
    }
  });
}
initDB();

// 新增：与 content.js 保持一致的图片URL规范化函数，用于去重索引
function normalizeImageUrl(url) {
  try {
    if (!url || typeof url !== 'string') return '';
    const base = url.split('?')[0];
    if (base.includes('kwcdn') || base.includes('temu.com')) {
      return `${base}?imageView2/2/w/500/q/70/format/webp`;
    }
    return base;
  } catch (e) {
    return url || '';
  }
}

// base64转Blob
function base64ToBlob(base64) {
	const arr = base64.split(','), mime = arr[0].match(/:(.*?);/)[1], bstr = atob(arr[1]);
	let n = bstr.length, u8arr = new Uint8Array(n);
	while(n--) u8arr[n] = bstr.charCodeAt(n);
	return new Blob([u8arr], {type: mime});
}

// 自动检查更新的函数
function checkForUpdatesAutomatically() {
  const now = Date.now();
  chrome.storage.local.get(['temuLastUpdateCheck'], (result) => {
    const lastCheckTime = result.temuLastUpdateCheck || 0;
    if (UPDATE_CHECK_INTERVAL > 0 && now - lastCheckTime < UPDATE_CHECK_INTERVAL) {
      return; // 测试期间不再输出“跳过检查”日志
    }

    const manifest = chrome.runtime.getManifest();
    const currentVersion = manifest.version;
    console.log('开始自动检查插件在线更新...');

    fetch('https://aygtemu.github.io/temu-/version.json', { cache: 'no-cache' })
      .then(resp => resp.json())
      .then(info => {
        chrome.storage.local.set({ 'temuLastUpdateCheck': now }, () => {
          lastUpdateCheckTime = now;
        });
        const latestVersion = info.version;

        const isNewer = (a, b) => {
          const ap = String(a).split('.').map(Number);
          const bp = String(b).split('.').map(Number);
          for (let i = 0; i < Math.max(ap.length, bp.length); i++) {
            const ai = ap[i] || 0; const bi = bp[i] || 0;
            if (ai > bi) return true;
            if (ai < bi) return false;
          }
          return false;
        };

        if (isNewer(latestVersion, currentVersion)) {
          console.log('发现在线新版本:', latestVersion);
          try {
            chrome.notifications.getPermissionLevel((level) => {
              if (level === 'granted') {
                chrome.notifications.create({
                  type: 'basic',
                  iconUrl: 'icons/icon128.png',
                  title: 'TemuSan插件更新',
                  message: `发现在线新版本 ${latestVersion}，点击扩展图标可选择是否更新。`,
                  priority: 1
                });
              }
            });
          } catch (e) {
            console.warn('发送更新通知失败:', e);
          }
        } else {
          console.log('在线版本检查：当前已是最新');
        }
      })
      .catch(err => {
        console.warn('在线版本检查失败:', err);
      });
  });
}

// 已禁用后台自动更新检查
// chrome.runtime.onInstalled.addListener(details => {
//   console.log('插件已安装或更新，检查更新已禁用');
// });

// chrome.runtime.onStartup.addListener(() => {
//   console.log('浏览器启动，后台自动更新检查已禁用');
// });

// 监听通知点击事件
chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
  chrome.notifications.clear(notificationId);
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  // 响应获取版本信息的请求
  if (msg.action === 'getPluginVersion') {
    sendResponse({ isSingleVersion: isSingleVersion });
    return true;
  }
  
  // 响应检查插件更新的请求
  if (msg.action === 'checkForUpdates') {
    const manifest = chrome.runtime.getManifest();
    const currentVersion = manifest.version;
    fetch('https://aygtemu.github.io/temu-/version.json?t=' + Date.now(), { cache: 'no-cache' })
      .then(r => r.json())
      .then(info => {
        const latestVersion = info.version;
        const isNewer = (a, b) => {
          const ap = String(a).split('.').map(Number);
          const bp = String(b).split('.').map(Number);
          for (let i = 0; i < Math.max(ap.length, bp.length); i++) {
            const ai = ap[i] || 0; const bi = bp[i] || 0;
            if (ai > bi) return true;
            if (ai < bi) return false;
          }
          return false;
        };
        sendResponse({
          updateAvailable: isNewer(latestVersion, currentVersion),
          version: latestVersion,
          currentVersion
        });
      })
      .catch(err => {
        sendResponse({ updateAvailable: false, error: '在线检查失败: ' + err.message });
      });
    return true; // 异步响应
  }
  
  // 响应检查插件过期状态的请求
  if (msg.action === 'checkPluginExpiration') {
    // 检查是否已过期
    let isExpired = false;
    if (isActivated && expireDate) {
      const now = new Date();
      if (now > expireDate) {
        isExpired = true;
        // 已过期，设置为未激活状态
        isActivated = false;
        // 更新存储中的激活状态
        chrome.storage.local.set({ pluginActivated: false }, () => {
          console.log('插件已过期，自动设置为未激活状态');
        });
      }
    }
    sendResponse({ isExpired: isExpired });
    return true;
  }

  // 响应检查插件激活状态的请求
  if (msg.action === 'checkPluginActivation') {
    // 确保激活状态是最新的
    checkActivationStatus().then(() => {
      sendResponse({ isActivated: isActivated });
    });
    return true; // 异步响应
  }
  
  // 批量采集
  if (msg.action === 'batchCollectProducts') {
    // 检查插件激活状态和版本
    if (!isActivated) {
      sendResponse({ success: false, error: '插件未激活，请先激活插件' });
      return true;
    }
    
    if (isSingleVersion) {
      sendResponse({ success: false, error: '您当前使用的是单采版，无法使用批量采集功能' });
      return true;
    }
    
    collectProductsFromTab(sender.tab.id).then(products => {
      sendResponse({ success: true, products });
    }).catch(e => {
      sendResponse({ success: false, error: e.message });
    });
    return true; // 异步响应
  }
  
  if (msg.action === 'collectProduct' && msg.data) {
    // 处理采集商品请求
    initDB().then(() => {
      try {
        const tx = db.transaction(['products'], 'readwrite');
        const store = tx.objectStore('products');
        const imgKey = normalizeImageUrl(msg.data.img);
        const product = {
          id: msg.data.id,
          title: msg.data.title,
          img: msg.data.img,
          imgKey: imgKey,
          price: msg.data.price || '',
          url: msg.data.url,
          time: new Date().toISOString()
        };

        // 优先使用索引检查是否已存在相同图片，避免重复写入导致卡顿
        let index;
        try {
          index = store.index('imgKey');
        } catch (_) {}

        if (index) {
          const dupReq = index.get(imgKey);
          dupReq.onsuccess = () => {
            if (dupReq.result) {
              console.log('检测到重复采集，按图片URL去重:', imgKey);
              sendResponse({ success: true, duplicate: true });
            } else {
              const request = store.put(product);
              request.onsuccess = () => {
                console.log('商品采集成功:', product.id);
                sendResponse({ success: true });
              };
              request.onerror = (e) => {
                console.error('采集保存失败:', e);
                sendResponse({ success: false, error: '数据库保存失败' });
              };
            }
          };
          dupReq.onerror = (e) => {
            console.warn('重复检测出错，回退为直接写入:', e);
            const request = store.put(product);
            request.onsuccess = () => {
              console.log('商品采集成功(回退):', product.id);
              sendResponse({ success: true });
            };
            request.onerror = (err) => {
              console.error('采集保存失败(回退):', err);
              sendResponse({ success: false, error: '数据库保存失败' });
            };
          };
        } else {
          // 索引不存在时直接写入（旧版本兼容）
          const request = store.put(product);
          request.onsuccess = () => {
            console.log('商品采集成功(无索引):', product.id);
            sendResponse({ success: true });
          };
          request.onerror = (e) => {
            console.error('采集保存失败(无索引):', e);
            sendResponse({ success: false, error: '数据库保存失败' });
          };
        }
      } catch (e) {
        console.error('采集商品时出错:', e);
        sendResponse({ success: false, error: '采集处理失败' });
      }
    }).catch(e => {
      console.error('数据库初始化失败:', e);
      sendResponse({ success: false, error: '数据库初始化失败' });
    });
    return true; // 保持消息通道开放
  }
  else if (msg.action === 'saveProduct' && msg.product) {
    initDB().then(() => {
      try {
        const tx = db.transaction(['products'], 'readwrite');
        const store = tx.objectStore('products');
        const prod = Object.assign({}, msg.product);
        // 添加采集时间与图片规范化键
        prod.time = new Date().toISOString();
        if (prod.img) {
          prod.imgKey = normalizeImageUrl(prod.img);
        }
        if (prod.imgBlob) prod.imgBlob = base64ToBlob(prod.imgBlob);

        const request = store.put(prod);
        request.onsuccess = () => {
          console.log('商品保存成功:', prod.id);
          sendResponse({success: true});
        };
        request.onerror = (e) => {
          console.error('数据库保存失败:', e);
          sendResponse({success: false, error: '数据库保存失败'});
        };
      } catch (e) {
        console.error('保存商品时出错:', e);
        sendResponse({success: false, error: e.message});
      }
    }).catch(e => {
      console.error('初始化数据库失败:', e);
      sendResponse({success: false, error: '数据库初始化失败'});
    });
    return true;
  }
  if (msg.action === 'checkProduct' && msg.id) {
    initDB().then(() => {
      try {
        const tx = db.transaction(['products'], 'readonly');
        const store = tx.objectStore('products');
        const request = store.get(msg.id);
        request.onsuccess = function(e) {
          sendResponse({collected: !!e.target.result});
        };
        request.onerror = function(e) {
          console.error('检查商品失败:', e);
          sendResponse({collected: false, error: '检查失败'});
        };
      } catch (e) {
        console.error('检查商品时出错:', e);
        sendResponse({collected: false, error: '检查处理失败'});
      }
    }).catch(e => {
      console.error('数据库初始化失败:', e);
      sendResponse({collected: false, error: '数据库初始化失败'});
    });
    return true;
  }
  if (msg.action === 'checkImageCollected' && msg.imgSrc) {
    initDB().then(() => {
      try {
        const tx = db.transaction(['products'], 'readonly');
        const store = tx.objectStore('products');
        const imgKey = normalizeImageUrl(msg.imgSrc);
        let index;
        try {
          index = store.index('imgKey');
        } catch (_) {}

        if (index) {
          const req = index.get(imgKey);
          req.onsuccess = function(e) {
            const exists = !!e.target.result;
            sendResponse({ collected: exists });
          };
          req.onerror = function(e) {
            console.error('检查图片采集状态失败(索引):', e);
            sendResponse({ collected: false, error: '检查失败' });
          };
        } else {
          // 兼容旧版本：回退到全量扫描（可能较慢）
          const request = store.getAll();
          request.onsuccess = function(e) {
            const products = e.target.result || [];
            const isCollected = products.some(p => normalizeImageUrl(p.img) === imgKey);
            sendResponse({ collected: isCollected });
          };
          request.onerror = function(e) {
            console.error('检查图片采集状态失败(全量):', e);
            sendResponse({ collected: false, error: '检查失败' });
          };
        }
      } catch (e) {
        console.error('检查图片采集状态时出错:', e);
        sendResponse({ collected: false, error: '检查处理失败' });
      }
    }).catch(e => {
      console.error('检查图片采集状态时数据库初始化失败:', e);
      sendResponse({ collected: false, error: '数据库初始化失败' });
    });
    return true;
  }
  if (msg.action === 'getAllProducts') {
    initDB().then(() => {
      try {
        const tx = db.transaction(['products'], 'readonly');
        const store = tx.objectStore('products');
        const request = store.getAll();
        request.onsuccess = function(e) {
          const products = e.target.result || [];
          // 按采集时间从新到旧排序
          products.sort((a, b) => {
            // 如果两个项目都有时间字段，按时间降序排序
            if (a.time && b.time) {
              return new Date(b.time) - new Date(a.time);
            }
            // 如果只有a有时间字段，a排在前面
            if (a.time) return -1;
            // 如果只有b有时间字段，b排在前面
            if (b.time) return 1;
            // 如果都没有时间字段，保持原有顺序
            return 0;
          });
          sendResponse({products: products});
        };
        request.onerror = function(e) {
          console.error('获取所有商品失败:', e);
          sendResponse({products: [], error: '获取数据失败'});
        };
      } catch (e) {
        console.error('获取所有商品时出错:', e);
        sendResponse({products: [], error: '处理失败'});
      }
    }).catch(e => {
      console.error('获取所有商品时数据库初始化失败:', e);
      sendResponse({products: [], error: '数据库初始化失败'});
    });
    return true;
  }
  if (msg.action === 'batchSaveProducts' && msg.products) {
    initDB().then(() => {
      try {
        const tx = db.transaction(['products'], 'readwrite');
        const store = tx.objectStore('products');
        let savedCount = 0;
        let totalCount = msg.products.length;
        
        msg.products.forEach(product => {
          const request = store.put(product);
          request.onsuccess = () => {
            savedCount++;
            if (savedCount === totalCount) {
              console.log(`批量保存完成: ${savedCount} 个商品`);
              sendResponse({success: true, count: savedCount});
            }
          };
          request.onerror = (e) => {
            console.error('批量保存商品失败:', e);
            sendResponse({success: false, error: '保存失败'});
          };
        });
      } catch (e) {
        console.error('批量保存商品时出错:', e);
        sendResponse({success: false, error: e.message});
      }
    }).catch(e => {
      console.error('初始化数据库失败:', e);
      sendResponse({success: false, error: '数据库初始化失败'});
    });
    return true;
  }
  if (msg.action === 'checkMultipleProducts' && msg.productIds) {
    initDB().then(() => {
      try {
        const tx = db.transaction(['products'], 'readonly');
        const store = tx.objectStore('products');
        const uncollectedIds = [];
        let checkedCount = 0;
        
        msg.productIds.forEach(productId => {
          const request = store.get(productId);
          request.onsuccess = function(e) {
            if (!e.target.result) {
              // 商品不存在，添加到未采集列表
              uncollectedIds.push(productId);
            }
            checkedCount++;
            if (checkedCount === msg.productIds.length) {
              // 所有商品检查完成
              sendResponse({uncollectedIds: uncollectedIds});
            }
          };
          request.onerror = function(e) {
            console.error('检查单个商品失败:', e);
            // 出错时也要计数，避免卡住
            checkedCount++;
            if (checkedCount === msg.productIds.length) {
              sendResponse({uncollectedIds: uncollectedIds});
            }
          };
        });
      } catch (e) {
        console.error('检查多个商品时出错:', e);
        sendResponse({uncollectedIds: [], error: '检查处理失败'});
      }
    }).catch(e => {
      console.error('检查商品状态时数据库初始化失败:', e);
      sendResponse({uncollectedIds: [], error: '数据库初始化失败'});
    });
    return true;
  }
  if (msg.action === 'clearAllProducts') {
    initDB().then(() => {
      try {
        const tx = db.transaction(['products'], 'readwrite');
        const store = tx.objectStore('products');
        const request = store.clear();
        request.onsuccess = () => {
          console.log('所有商品数据已清除');
          sendResponse({success: true});
        };
        request.onerror = (e) => {
          console.error('清除数据失败:', e);
          sendResponse({success: false, error: '清除失败'});
        };
      } catch (e) {
        console.error('清除数据时出错:', e);
        sendResponse({success: false, error: e.message});
      }
    }).catch(e => {
      console.error('初始化数据库失败:', e);
      sendResponse({success: false, error: '数据库初始化失败'});
    });
    return true;
  }
  if (msg.action === 'getSavedProductCount') {
    initDB().then(() => {
      try {
        const tx = db.transaction(['products'], 'readonly');
        const store = tx.objectStore('products');
        const countRequest = store.count();
        countRequest.onsuccess = function(e) {
          sendResponse({count: e.target.result});
        };
        countRequest.onerror = function(e) {
          console.error('获取商品数量失败:', e);
          sendResponse({count: 0, error: '获取数量失败'});
        };
      } catch (e) {
        console.error('获取商品数量时出错:', e);
        sendResponse({count: 0, error: '处理失败'});
      }
    }).catch(e => {
      console.error('获取商品数量时数据库初始化失败:', e);
      sendResponse({count: 0, error: '数据库初始化失败'});
    });
    return true;
  }
  if (msg.action === 'getTodaySavedProductCount') {
    initDB().then(() => {
      try {
        const tx = db.transaction(['products'], 'readonly');
        const store = tx.objectStore('products');
        const req = store.getAll();
        req.onsuccess = function(e) {
          try {
            const products = e.target.result || [];
            const today = new Date().toISOString().slice(0, 10);
            const todayCount = products.filter(p => {
              return p.time && p.time.slice(0, 10) === today;
            }).length;
            sendResponse({count: todayCount});
          } catch (e) {
            console.error('处理今日商品数据时出错:', e);
            sendResponse({count: 0, error: '数据处理失败'});
          }
        };
        req.onerror = function(e) {
          console.error('获取今日商品数量失败:', e);
          sendResponse({count: 0, error: '获取数据失败'});
        };
      } catch (e) {
        console.error('获取今日商品数量时出错:', e);
        sendResponse({count: 0, error: '处理失败'});
      }
    }).catch(e => {
      console.error('获取今日商品数量时数据库初始化失败:', e);
      sendResponse({count: 0, error: '数据库初始化失败'});
    });
    return true;
  }
});

// ========================== 版本检测和更新检查功能 ==========================

// 检查扩展更新
async function checkForExtensionUpdates() {
  try {
    // 模拟检查更新过程
    // 在实际应用中，这里可以根据需要添加额外的自定义更新检查逻辑
    // Chrome会自动通过manifest.json中的update_url检查更新
    
    // 获取当前扩展信息
    const manifest = chrome.runtime.getManifest();
    const currentVersion = manifest.version;
    
    console.log('当前扩展版本:', currentVersion);
    console.log('Chrome会通过manifest.json中的update_url自动检查更新');
    
    // 记录最后检查时间
    chrome.storage.local.set({
      lastUpdateCheck: new Date().toISOString()
    });
    
    return {
      currentVersion: currentVersion,
      autoUpdateEnabled: true,
      lastChecked: new Date().toISOString()
    };
  } catch (error) {
    console.error('检查更新失败:', error);
    // 记录错误信息
    chrome.storage.local.set({
      updateError: error.message,
      lastUpdateError: new Date().toISOString()
    });
    throw error;
  }
}

// 手动检查更新函数
function manualCheckUpdates() {
  console.log('开始手动检查更新...');
  return checkForExtensionUpdates();
}

// 通知用户更新错误
function notifyUserOfUpdateError(errorMessage) {
  try {
    // 检查通知权限
    chrome.notifications.getPermissionLevel((level) => {
      if (level === 'granted') {
        chrome.notifications.create({
          type: 'basic',
          iconUrl: 'icons/icon48.png',
          title: '更新检查失败',
          message: '无法检查插件更新，请稍后再试。您可以点击扩展图标手动检查更新。',
          priority: 1
        });
      }
    });
  } catch (notifyError) {
    console.error('发送通知失败:', notifyError);
  }
}

// 监听扩展安装/更新事件
// chrome.runtime.onInstalled.addListener((details) => {
//   if (details.reason === 'update') {
//     console.log('扩展已更新（已禁用通知）');
//     // 已禁用更新通知弹窗
//   }
// });

// 移除了自动定时检查更新，现在只通过手动触发检查更新

// 点击插件图标时，根据激活状态决定打开的页面
chrome.action.onClicked.addListener(() => {
  try {
    chrome.storage.local.get(['pluginActivated', 'expireDate'], (result) => {
      let active = !!(result && result.pluginActivated);
      const expireStr = result && result.expireDate;
      if (active && expireStr) {
        try {
          const exp = new Date(expireStr);
          if (!isNaN(exp) && Date.now() > exp.getTime()) {
            active = false;
          }
        } catch (_) {}
      }
      const target = active ? 'gallery.html' : 'activation.html';
      chrome.tabs.create({ url: chrome.runtime.getURL(target) });
    });
  } catch (e) {
    console.error('打开页面失败:', e);
  }
});
