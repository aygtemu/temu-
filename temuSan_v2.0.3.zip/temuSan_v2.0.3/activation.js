// 生成机器码（基于浏览器信息和系统信息）
function generateMachineCode() {
  // 获取浏览器和系统信息（尽可能使用稳定的特征）
  const navigatorInfo = {
    // 使用经过处理的userAgent，移除可能变化的部分
    userAgent: navigator.userAgent.replace(/Chrome\/\d+\.\d+/, 'Chrome').replace(/Firefox\/\d+\.\d+/, 'Firefox'),
    platform: navigator.platform,
    language: navigator.language,
    hardwareConcurrency: navigator.hardwareConcurrency || 'unknown',
    deviceMemory: navigator.deviceMemory || 'unknown',
    // 添加一些稳定性更高的信息
    screenWidth: screen.width,
    screenHeight: screen.height,
    colorDepth: screen.colorDepth
  };
  
  // 创建一个基于这些信息的哈希值作为机器码
  const infoStr = JSON.stringify(navigatorInfo);
  let hash = 0;
  if (infoStr.length === 0) return hash;
  for (let i = 0; i < infoStr.length; i++) {
    const char = infoStr.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32bit integer
  }
  
  // 将哈希值转换为16进制字符串并格式化
  const hexHash = Math.abs(hash).toString(16);
  const formattedHash = hexHash.padStart(16, '0');
  
  // 将机器码格式化为更易读的形式，例如：XXXX-XXXX-XXXX-XXXX
  const parts = [];
  for (let i = 0; i < formattedHash.length; i += 4) {
    parts.push(formattedHash.substr(i, 4));
  }
  
  return parts.join('-');
}

// 复制文本到剪贴板
function copyToClipboard(text) {
  return navigator.clipboard.writeText(text).then(() => {
    showNotification('复制成功！', 'success');
  }).catch(err => {
    console.error('复制失败:', err);
    showNotification('复制失败，请手动复制', 'error');
    
    // 降级方案：使用传统的复制方法
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.left = '-999999px';
    textArea.style.top = '-999999px';
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    try {
      document.execCommand('copy');
      showNotification('复制成功！', 'success');
    } catch (err) {
      showNotification('复制失败，请手动复制', 'error');
    }
    document.body.removeChild(textArea);
  });
}

// 显示通知信息
function showNotification(message, type = 'info') {
  const resultElement = document.getElementById('activation-result');
  resultElement.textContent = message;
  resultElement.className = 'activation-result';
  resultElement.classList.add(type);
  resultElement.style.display = 'block'; // 确保通知显示出来
  
  // 3秒后自动隐藏通知
  setTimeout(() => {
    resultElement.style.display = 'none';
  }, 3000);
}

// 复制全部信息
function copyAllInfo() {
  const machineCode = document.getElementById('machine-code').textContent;
  const contact = document.getElementById('contact').value;
  const versionSelect = document.getElementById('version');
  const version = versionSelect.options[versionSelect.selectedIndex].text;
  
  if (!contact) {
    showNotification('请先填写联系方式', 'error');
    return;
  }
  
  const allInfo = `机器码: ${machineCode}\n联系方式: ${contact}\n版本: ${version}`;
  copyToClipboard(allInfo);
}

// 保存版本信息
function saveVersionInfo(version) {
  chrome.storage.local.set({
    pluginVersion: version
  }, () => {
    console.log('版本信息已保存:', version);
  });
}

// 验证激活码
function verifyActivationCode() {
  const activationCode = document.getElementById('activation-code').value.trim();
  const machineCode = document.getElementById('machine-code').textContent;
  const contact = document.getElementById('contact').value.trim();
  // 注意：这里不再使用页面上的版本选择，而是从激活码中解析版本信息
  
  if (!activationCode) {
    showNotification('请输入激活码', 'error');
    return;
  }
  
  if (!contact) {
    showNotification('请输入联系方式', 'error');
    return;
  }
  
  try {
    // 解析激活码，同时验证联系方式
    const parsedResult = parseActivationCode(activationCode, machineCode, contact);
    
    // 检查激活码是否已过期
    if (parsedResult.expired) {
      showNotification('该激活码已过期，请使用新的激活码', 'error');
      return;
    }
    
    if (!parsedResult.valid) {
      // 提供更具体的错误信息
      showNotification('激活码无效、与机器码不匹配或联系方式不匹配', 'error');
      // 在控制台显示详细信息，方便调试
      console.log('激活失败详情 - 激活码格式检查:', {
        activationCode: activationCode,
        machineCode: machineCode,
        contact: contact
      });
      return;
    }
    
    // 获取激活天数和版本信息
    const activationDays = parsedResult.days;
    const version = parsedResult.version;
    const generatedTime = parsedResult.generatedTime;
    
    // 检查激活码是否已被使用
    if (checkIfActivationCodeUsed(activationCode)) {
      showNotification('该激活码已被使用，请使用新的激活码', 'error');
      return;
    }
    
    // 计算激活到期时间
    const now = new Date();
    const expireDate = new Date(generatedTime.getTime() + activationDays * 24 * 60 * 60 * 1000);
    
    // 保存激活状态，包括版本信息和激活码
    saveActivationStatus(true, machineCode, expireDate.toISOString(), version, activationCode);
    
    // 显示成功信息，包括到期时间
    const expireDateString = expireDate.toLocaleDateString('zh-CN');
    showNotification(`激活成功！到期时间：${expireDateString}，即将跳转到主界面...`, 'success');
    
    // 2秒后跳转到popup.html
    setTimeout(() => {
      window.location.href = 'popup.html';
    }, 2000);
  } catch (error) {
    console.error('激活码验证失败:', error);
    // 提供更详细的错误信息，帮助用户理解问题
    showNotification('激活码验证过程中发生错误，请检查激活码格式是否正确', 'error');
    console.log('激活失败错误详情:', error);
  }
}

// 简单哈希函数
function simpleHash(str) {
  let hash = 0;
  if (str.length === 0) return hash;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32bit integer
  }
  return hash;
}

// 保存激活状态
function saveActivationStatus(isActivated, machineCode, expireDate, version, activationCode) {
  const dataToSave = {
    pluginActivated: isActivated,
    activatedMachineCode: machineCode,
    activationDate: new Date().toISOString(),
    pluginVersion: version,
    usedActivationCode: activationCode // 保存使用的激活码
  };
  
  // 如果有到期时间，也保存到期时间
  if (expireDate) {
    dataToSave.expireDate = expireDate;
  }
  
  chrome.storage.local.set(dataToSave, () => {
    console.log('激活状态已保存:', { isActivated, machineCode, version, expireDate, activationCode });
    
    // 如果是激活操作，将激活码添加到已使用列表
    if (isActivated && activationCode) {
      addUsedActivationCode(activationCode);
    }
  });
}

// 添加已使用的激活码到记录
function addUsedActivationCode(activationCode) {
  try {
    // 从localStorage读取已使用的激活码信息
    const usedCodes = localStorage.getItem('usedActivationCodes');
    const usedCodesArray = usedCodes ? JSON.parse(usedCodes) : [];
    
    // 如果激活码不在列表中，则添加
    if (!usedCodesArray.includes(activationCode)) {
      usedCodesArray.push(activationCode);
      // 保存更新后的列表
      localStorage.setItem('usedActivationCodes', JSON.stringify(usedCodesArray));
      console.log('激活码已添加到已使用列表');
    }
  } catch (error) {
    console.error('保存已使用激活码失败:', error);
  }
}

// 检查是否已经激活
function checkActivationStatus() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['pluginActivated'], (result) => {
      const isActivated = result.pluginActivated || false;
      resolve(isActivated);
    });
  });
}

// ===== 新增：进入画廊前的联网更新检查 =====
function isNewerVersion(latest, current) {
  const latestParts = (latest || '').split('.').map(Number);
  const currentParts = (current || '').split('.').map(Number);
  for (let i = 0; i < Math.max(latestParts.length, currentParts.length); i++) {
    const l = latestParts[i] || 0;
    const c = currentParts[i] || 0;
    if (l > c) return true;
    if (l < c) return false;
  }
  return false;
}

async function downloadUpdatePackage(url) {
  try {
    const a = document.createElement('a');
    a.href = url;
    a.download = '';
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  } catch (e) {
    console.warn('触发下载失败:', e);
    alert('下载链接：' + url);
  }
}

async function checkAndEnterGalleryWithUpdatePrompt() {
  try {
    const currentVersion = chrome.runtime.getManifest().version;
    let latestVersion = null;
    let updateContent = null;
    let downloadUrl = null;

    const resp = await fetch('https://aygtemu.github.io/temu-/version.json');
    if (resp.ok) {
      const info = await resp.json();
      latestVersion = info.version;
      updateContent = info.updateContent || '无更新内容说明';
      downloadUrl = info.downloadUrl || 'https://aygtemu.github.io/temu-/temuSan_latest.zip';

      if (isNewerVersion(latestVersion, currentVersion)) {
        const ok = confirm(`发现新版本 ${latestVersion}！\n\n当前版本：${currentVersion}\n\n更新内容：${updateContent}\n\n是否立即下载更新？`);
        if (ok) {
          await downloadUpdatePackage(downloadUrl);
          alert('更新包已开始下载。请按以下步骤覆盖更新：\n\n1. 打开 chrome://extensions\n2. 开启“开发者模式”\n3. 如果是“已解压”的本地安装：将下载的文件解压后覆盖旧目录并点击“重新加载”。\n4. 如果是从商店安装：请前往商店页面更新或等待自动更新。');
          return; // 留在当前弹窗，方便查看说明
        }
      }
    }
  } catch (e) {
    console.warn('检查更新失败，直接进入画廊:', e);
  }
  // 无更新或用户取消，直接进入画廊
  try {
    window.open(chrome.runtime.getURL('gallery.html'), '_blank');
    window.close();
  } catch (e) {
    // 兜底回退到原popup
    window.location.href = 'popup.html';
  }
}

// 初始化页面
async function initPage() {
  // 检查是否已经激活
  const isActivated = await checkActivationStatus();
  
  if (isActivated) {
    // 如果已经激活：先联网检查更新，再决定是否进入画廊
    await checkAndEnterGalleryWithUpdatePrompt();
    return;
  }
  
  // 生成并显示机器码
  const machineCode = generateMachineCode();
  document.getElementById('machine-code').textContent = machineCode;
  
  // 绑定一键复制全部信息按钮事件
  document.getElementById('copy-all-info').addEventListener('click', copyAllInfo);
  
  // 绑定验证激活码按钮事件
  document.getElementById('verify-activation-code').addEventListener('click', verifyActivationCode);
  
  // 当版本选择改变时保存版本信息
  document.getElementById('version').addEventListener('change', (e) => {
    saveVersionInfo(e.target.value);
  });
  
  // 默认保存当前选择的版本
  const defaultVersion = document.getElementById('version').value;
  saveVersionInfo(defaultVersion);
}

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', initPage);