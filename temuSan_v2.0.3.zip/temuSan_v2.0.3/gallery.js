// gallery.js 画廊页面，展示和批量筛选图片
let db;
// 添加全局变量用于存储激活信息
let pluginActivationInfo = null;

// 分页相关全局变量
let currentPage = 1;
let pageSize = 0; // 0表示显示全部
let totalPages = 1;
let allProducts = []; // 存储所有产品数据
let filteredProducts = []; // 存储过滤后的数据

// 词库相关全局变量
let prohibitedWords = new Set();
let filterWords = new Set();
let isProhibitedFilterActive = false;
let enableImageTextCheck = false; // 新增：是否启用图片文字检测

// 存储键名
const PROHIBITED_WORDS_KEY = 'temu_prohibited_words';
const FILTER_WORDS_KEY = 'temu_filter_words';

// 导出全局变量供模块使用
window.PROHIBITED_WORDS_KEY = PROHIBITED_WORDS_KEY;
window.FILTER_WORDS_KEY = FILTER_WORDS_KEY;
window.prohibitedWords = prohibitedWords;
window.filterWords = filterWords;

// 简化的Windows API模块引用
let windowsWordsApi = null;
async function loadWindowsApi() {
  console.log('API模块加载功能已简化');
  // 创建一个空的API对象，避免引用错误
  windowsWordsApi = {
    updateWordsFromServer: async () => ({ prohibitedWords: new Set(), filterWords: new Set() }),
    batchCheckProhibitedWordsOnline: async () => []
  };
}

// 移除自动加载，只在需要时手动调用
// window.addEventListener('DOMContentLoaded', () => {
//   loadWindowsApi().catch(err => {
//     console.error('加载Windows API模块失败:', err);
//   });
// });

// 添加页面大小变化事件监听器
document.addEventListener('DOMContentLoaded', () => {
  const pageSizeSelect = document.getElementById('page-size-select');
  if (pageSizeSelect) {
    pageSizeSelect.addEventListener('change', function() {
      pageSize = parseInt(this.value);
      currentPage = 1; // 重置到第一页
      // 保存到本地存储，记住用户选择
      try {
        localStorage.setItem('temu_gallery_page_size', pageSize.toString());
      } catch (e) {
        console.warn('无法保存页面大小设置到本地存储:', e);
      }
      updateGalleryDisplay();
    });
    
    // 为页面大小选择框禁用方向键默认行为
    pageSizeSelect.addEventListener('keydown', function(e) {
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
        e.preventDefault();
      }
    });
    
    // 从本地存储加载上次选择的值，没有则使用默认值
    try {
      const savedPageSize = localStorage.getItem('temu_gallery_page_size');
      if (savedPageSize !== null) {
        pageSizeSelect.value = savedPageSize;
        pageSize = parseInt(savedPageSize);
      } else {
        pageSizeSelect.value = '0'; // 默认显示全部
        pageSize = 0;
      }
    } catch (e) {
      console.warn('无法从本地存储加载页面大小设置:', e);
      pageSizeSelect.value = '0'; // 默认显示全部
      pageSize = 0;
    }
  }
});

function initDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('temu_collector', 2);
    request.onupgradeneeded = function(e) {
      try {
        db = e.target.result;
        if (!db.objectStoreNames.contains('products')) {
          db.createObjectStore('products', { keyPath: 'id' });
        }
        // 添加回收站存储
        if (!db.objectStoreNames.contains('recycle_bin')) {
          const recycleStore = db.createObjectStore('recycle_bin', { keyPath: 'id' });
          recycleStore.createIndex('deletedAt', 'deletedAt', { unique: false });
        }
      } catch (error) {
        console.error('数据库升级失败:', error);
        reject(error);
      }
    };
    request.onsuccess = function(e) {
      db = e.target.result;
      resolve();
    };
    request.onerror = (e) => {
      console.error('数据库打开失败:', e);
      reject(e);
    };
  });
}

function getAllProducts() {
  return new Promise(resolve => {
    const tx = db.transaction(['products'], 'readonly');
    const store = tx.objectStore('products');
    const req = store.getAll();
    req.onsuccess = () => {
      const arr = req.result || [];
      // 按采集时间从新到旧排序（最新的在前）
      arr.sort((a, b) => {
        // 如果两个项目都有时间字段，按时间降序排序
        if (a.time && b.time) {
          return new Date(b.time) - new Date(a.time);
        }
        // 如果只有a有时间字段，a排在前面
        if (a.time) return -1;
        // 如果只有b有时间字段，b排在前面
        if (b.time) return 1;
        // 如果都没有时间字段，保持原有顺序
        return 0;
      });
      arr.forEach(item => {
        if (item.imgBlob) {
          item.imgBlobUrl = URL.createObjectURL(item.imgBlob);
        }
      });
      resolve(arr);
    };
    req.onerror = () => resolve([]);
  });
}
function saveAllProducts(arr) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(['products'], 'readwrite');
    const store = tx.objectStore('products');
    
    tx.oncomplete = () => {
      console.log('数据库保存完成');
      resolve();
    };
    
    tx.onerror = (e) => {
      console.error('数据库保存失败:', e);
      reject(e);
    };
    
    store.clear().onsuccess = () => {
      console.log('数据库清空完成，开始保存', arr.length, '条数据');
      
      // 去重逻辑：确保没有重复的图片链接
      const uniqueProducts = [];
      const seenImages = new Set();
      
      arr.forEach(item => {
        // 使用图片URL作为唯一标识（去除查询参数）
        const imgKey = item.img ? item.img.split('?')[0] : null;
        
        if (imgKey && !seenImages.has(imgKey)) {
          seenImages.add(imgKey);
          uniqueProducts.push(item);
        } else if (!imgKey) {
          // 如果没有图片URL，仍然添加项目
          uniqueProducts.push(item);
        } else {
          console.log('跳过重复商品:', imgKey);
        }
      });
      
      console.log(`去重后保存 ${uniqueProducts.length} 条数据（原 ${arr.length} 条）`);
      
      uniqueProducts.forEach(item => {
        store.put(item);
      });
    };
  });
}

// 回收站相关函数
function moveToRecycleBin(products) {
  return new Promise(resolve => {
    const tx = db.transaction(['recycle_bin'], 'readwrite');
    const store = tx.objectStore('recycle_bin');
    
    let completed = 0;
    const now = new Date().toISOString();
    
    products.forEach(product => {
      const recycleItem = {
        ...product,
        id: `${product.id}_deleted_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`, // 生成唯一ID
        deletedAt: now,
        originalId: product.id // 保存原始ID用于恢复
      };
      
      const addReq = store.add(recycleItem);
      addReq.onsuccess = () => {
        completed++;
        if (completed === products.length) {
          resolve();
        }
      };
      addReq.onerror = (e) => {
        console.error('移动到回收站失败:', e, recycleItem);
        completed++;
        if (completed === products.length) {
          resolve();
        }
      };
    });
  });
}

function getRecycleBinItems() {
  return new Promise(resolve => {
    const tx = db.transaction(['recycle_bin'], 'readonly');
    const store = tx.objectStore('recycle_bin');
    const req = store.getAll();
    req.onsuccess = () => {
      const arr = req.result || [];
      // 按删除时间从新到旧排序
      arr.sort((a, b) => new Date(b.deletedAt) - new Date(a.deletedAt));
      arr.forEach(item => {
        if (item.imgBlob) {
          item.imgBlobUrl = URL.createObjectURL(item.imgBlob);
        }
      });
      resolve(arr);
    };
    req.onerror = () => resolve([]);
  });
}

function restoreFromRecycleBin(ids) {
  return new Promise(resolve => {
    const tx = db.transaction(['recycle_bin', 'products'], 'readwrite');
    const recycleStore = tx.objectStore('recycle_bin');
    const productStore = tx.objectStore('products');
    
    let completed = 0;
    
    ids.forEach(id => {
      const getReq = recycleStore.get(id);
      getReq.onsuccess = () => {
        const item = getReq.result;
        if (item) {
          // 恢复到原始状态
          const restoredItem = { ...item };
          restoredItem.id = item.originalId; // 恢复原始ID
          delete restoredItem.deletedAt;
          delete restoredItem.originalId;
          
          // 检查是否已存在相同ID的数据
          const checkReq = productStore.get(restoredItem.id);
          checkReq.onsuccess = () => {
            if (checkReq.result) {
              // 如果已存在，生成新的ID避免冲突
              const originalId = restoredItem.id;
              restoredItem.id = `${originalId}_restored_${Date.now()}`;
              console.log(`⚠️ 检测到ID冲突，已重新生成ID: ${originalId} -> ${restoredItem.id}`);
            }
            
            // 使用put而不是add，避免ID冲突
             const putReq = productStore.put(restoredItem);
             putReq.onsuccess = () => {
               // 从回收站删除
               recycleStore.delete(id).onsuccess = () => {
                 completed++;
                 if (completed === ids.length) {
                   resolve();
                 }
               };
             };
             
             putReq.onerror = (e) => {
               console.error('恢复数据失败:', e, restoredItem);
               completed++;
               if (completed === ids.length) {
                 resolve();
               }
             };
          };
          
          checkReq.onerror = () => {
            // 检查失败，直接尝试恢复
            productStore.put(restoredItem).onsuccess = () => {
              recycleStore.delete(id).onsuccess = () => {
                completed++;
                if (completed === ids.length) {
                  resolve();
                }
              };
            };
          };
        } else {
          completed++;
          if (completed === ids.length) {
            resolve();
          }
        }
      };
    });
  });
}

function permanentDeleteFromRecycleBin(ids) {
  return new Promise(resolve => {
    const tx = db.transaction(['recycle_bin'], 'readwrite');
    const store = tx.objectStore('recycle_bin');
    
    let completed = 0;
    
    ids.forEach(id => {
      const deleteReq = store.delete(id);
      deleteReq.onsuccess = () => {
        completed++;
        if (completed === ids.length) {
          resolve();
        }
      };
      deleteReq.onerror = () => {
        completed++;
        if (completed === ids.length) {
          resolve();
        }
      };
    });
  });
}

// 初始化词库管理器
function initWordFilterManager() {
  loadWordSets();
  setupPanelToggle();
  setupWordActions();
  // 不自动设置网络监控，只在点击联网检测时才设置
  
  // 初始化按钮状态
  updateButtonStates();
}

// 更新按钮状态
function updateButtonStates() {
  const filterBtn = document.getElementById('filter-by-prohibited');
  const resetBtn = document.getElementById('reset-filter');
  
  if (filterBtn) {
    // 筛选按钮只有在未筛选状态且有违禁词时才能用
    // 筛选成功后（isProhibitedFilterActive为true）禁用筛选按钮
    filterBtn.disabled = isProhibitedFilterActive || prohibitedWords.size === 0;
    
    // 直接设置背景色
    if (filterBtn.disabled) {
      filterBtn.style.backgroundColor = '#888'; // 禁用时暗灰色
      filterBtn.style.opacity = '0.6';
    } else {
      filterBtn.style.backgroundColor = '#ff6700'; // 可用时橙色
      filterBtn.style.opacity = '1';
    }
    
    filterBtn.style.cursor = filterBtn.disabled ? 'not-allowed' : 'pointer';
    
    console.log('筛选按钮状态更新：', { 
      isProhibitedFilterActive: isProhibitedFilterActive, 
      hasProhibitedWords: prohibitedWords.size > 0, 
      disabled: isProhibitedFilterActive || prohibitedWords.size === 0 
    });
  }
  
  if (resetBtn) {
    // 重置按钮只有在筛选状态下才能用
    resetBtn.disabled = !isProhibitedFilterActive;
    
    // 直接设置背景色
    if (resetBtn.disabled) {
      resetBtn.style.backgroundColor = '#888'; // 禁用时暗灰色
      resetBtn.style.opacity = '0.6';
    } else {
      resetBtn.style.backgroundColor = '#28a745'; // 可用时绿色
      resetBtn.style.opacity = '1';
    }
    
    resetBtn.style.cursor = resetBtn.disabled ? 'not-allowed' : 'pointer';
  }
}

// 从存储加载词库
function loadWordSets() {
  chrome.storage.local.get([PROHIBITED_WORDS_KEY, FILTER_WORDS_KEY], function(result) {
    if (result[PROHIBITED_WORDS_KEY]) {
      prohibitedWords = new Set(result[PROHIBITED_WORDS_KEY]);
    }
    if (result[FILTER_WORDS_KEY]) {
      filterWords = new Set(result[FILTER_WORDS_KEY]);
    }
    updateWordCountDisplay();
    // 更新按钮状态，确保有违禁词时筛选按钮可用
    updateButtonStates();
    if (isProhibitedFilterActive) {
      applyProhibitedFilter();
    }
  });
}

// 保存词库到存储
function saveWordSets() {
  chrome.storage.local.set({
    [PROHIBITED_WORDS_KEY]: Array.from(prohibitedWords),
    [FILTER_WORDS_KEY]: Array.from(filterWords)
  }, function() {
    updateWordCountDisplay();
    // 更新按钮状态，确保词库变化后按钮状态正确
    updateButtonStates();
  });
}

// 更新词库数量显示
function updateWordCountDisplay() {
  document.getElementById('prohibited-count').textContent = prohibitedWords.size;
  document.getElementById('filter-count').textContent = filterWords.size;
}

// 设置面板切换功能
function setupPanelToggle() {
  const panel = document.getElementById('word-filter-panel');
  const toggleBtn = document.getElementById('toggle-panel-btn');
  
  if (panel && toggleBtn) {
    toggleBtn.addEventListener('click', function() {
      // 立即切换面板显示状态和按钮样式
      panel.classList.toggle('show');
      toggleBtn.classList.toggle('panel-active');
      
      // 面板打开时，先确保面板完全显示，然后再开始检测过滤词
      if (panel.classList.contains('show')) {
        // 使用setTimeout让浏览器先完成面板的渲染和显示，然后再执行耗时的检测操作
        setTimeout(() => {
          detectFilterWords();
        }, 0);
      }
    });
  }
}

// 检测违禁词 - 仅在点击筛选按钮时调用
function detectProhibitedWords() {
  console.log('开始检测违禁词...');
  
  // 显示检测中提示
  const resultContainer = document.getElementById('filter-results');
  if (resultContainer) {
    resultContainer.innerHTML = '<div style="color:#faad14;">正在检测违禁词...</div>';
    resultContainer.style.display = 'block';
  }
  
  // 使用filteredProducts而非allProducts，确保只检测时间筛选范围内的数据
  const dataToCheck = filteredProducts.length > 0 ? filteredProducts : allProducts;
  
  // 模拟检测过程
  setTimeout(() => {
    let totalItems = dataToCheck.length;
    let prohibitedCount = 0;
    
    // 统计包含违禁词的商品数量
    dataToCheck.forEach(item => {
      if (containsProhibitedWords(item.title) || (enableImageTextCheck && item.imgAlt && containsProhibitedWords(item.imgAlt))) {
        prohibitedCount++;
      }
    });
    
    // 显示检测结果
    if (resultContainer) {
      resultContainer.innerHTML = `<div style="color:#ff6700;">检测完成：共 ${totalItems} 个商品，其中 ${prohibitedCount} 个包含违禁词</div>`;
    }
  }, 500);
}

// 检测过滤词
function detectFilterWords() {
  console.log('开始检测过滤词...');
  
  const resultDisplay = document.getElementById('filter-result-display');
  if (resultDisplay) {
    resultDisplay.textContent = '检测中...';
  }
  
  // 模拟检测过程
  setTimeout(() => {
    // 使用时间筛选后的数据，而不是所有商品
    const data = (typeof filteredProducts !== 'undefined' && filteredProducts.length >= 0) ? filteredProducts : [];
    let totalItems = data.length;
    let itemsWithFilterWords = 0;
    
    // 统计包含过滤词的商品数量
    data.forEach(item => {
      // 只检查标题中的过滤词
      if (item.title) {
        const originalTitle = item.title;
        const filteredTitle = applyFilterWordsLocal(originalTitle);
        
        // 如果标题发生变化，说明包含过滤词
        if (originalTitle !== filteredTitle) {
          itemsWithFilterWords++;
        }
      }
    });
    
    // 在新位置以XXX/XXXX格式显示检测结果
    if (resultDisplay) {
      resultDisplay.textContent = `${itemsWithFilterWords}/${totalItems}`;
    }
  }, 500);
}

// 设置词库操作按钮
function setupWordActions() {
  // 违禁词操作
  document.getElementById('import-prohibited').addEventListener('click', () => importWords(prohibitedWords, true));
  document.getElementById('view-prohibited').addEventListener('click', () => viewWords(prohibitedWords, '违禁词列表'));
  document.getElementById('clear-prohibited').addEventListener('click', () => clearWords(prohibitedWords, true));
  
  // 过滤词操作
  document.getElementById('import-filter').addEventListener('click', () => importWords(filterWords, false));
  document.getElementById('view-filter').addEventListener('click', () => viewWords(filterWords, '过滤词列表'));
  document.getElementById('clear-filter').addEventListener('click', () => clearWords(filterWords, false));
  
  // 筛选操作
  document.getElementById('filter-by-prohibited').addEventListener('click', applyProhibitedFilter);
  document.getElementById('reset-filter').addEventListener('click', resetFilter);
  
  // 图片文字检测开关
  const imageTextCheckCheckbox = document.getElementById('enable-image-text-check');
  if (imageTextCheckCheckbox) {
    imageTextCheckCheckbox.addEventListener('change', function() {
      enableImageTextCheck = this.checked;
      // 如果筛选已激活，重新应用筛选
      if (isProhibitedFilterActive) {
        applyProhibitedFilter();
      }
    });
  }
  
  // 移除了过滤结果容器的创建，过滤词检测结果现在显示在过滤词导入查看按钮下方
    
  // 联网检测操作 - 从网络获取违禁词词库并进行检测，同时检查插件更新
  const networkCheckBtn = document.getElementById('network-check');
  if (networkCheckBtn) {
    networkCheckBtn.addEventListener('click', async function() {
      // 显示加载状态
      const originalText = networkCheckBtn.textContent;
      const originalColor = networkCheckBtn.style.backgroundColor;
      networkCheckBtn.textContent = '检测中...';
      networkCheckBtn.style.backgroundColor = '#faad14';
      networkCheckBtn.disabled = true;
      
      try {
        // 从网络获取违禁词词库并检测
        await detectProhibitedWordsOnline();
        
        // 检测插件更新
        console.log('开始检查插件更新...');
        const updateResult = await chrome.runtime.sendMessage({action: 'checkForUpdates'});
        
        if (updateResult.error) {
          console.warn('检查更新时出错:', updateResult.error);
        } else {
          console.log('插件更新检查结果:', updateResult);
          // 如果想显示更新检查结果给用户，可以在这里添加代码
        }
        
      } catch (error) {
        console.error('操作失败:', error);
        alert('联网检测失败：' + error.message);
      } finally {
        // 恢复按钮状态
        networkCheckBtn.textContent = originalText;
        networkCheckBtn.style.backgroundColor = originalColor;
        networkCheckBtn.disabled = false;
      }
    });
  }
    
  // 从网络获取违禁词词库并检测 - 与本地违禁词检测功能效果一致
  async function detectProhibitedWordsOnline() {
    console.log('开始从网络获取违禁词词库...');
    
    // 显示检测中提示
    const resultContainer = document.getElementById('filter-results');
    if (resultContainer) {
      resultContainer.innerHTML = '<div style="color:#faad14;">正在从网络获取违禁词词库并检测...</div>';
      resultContainer.style.display = 'block';
    }
    
    try {
      let response, text, data;
      let retries = 3;
      
      // 添加重试机制处理可能的错误
      while (retries > 0) {
        try {
          // 从GitHub获取违禁词词库
          const url = 'https://aygtemu.github.io/temu-/words.json';
          console.log(`尝试从 ${url} 获取违禁词词库，剩余${retries}次重试机会...`);
          
          response = await fetch(url, {
            headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json'
            }
          });
          
          if (response.status === 429) {
            retries--;
            const waitTime = Math.pow(2, 3 - retries) * 1000; // 指数退避: 1s, 2s, 4s
            console.log(`检测到请求限制，${retries}次重试机会，${waitTime}ms后重试...`);
            if (resultContainer) {
              resultContainer.innerHTML = `<div style="color:#faad14;">检测到请求限制，${Math.floor(waitTime/1000)}秒后重试...</div>`;
            }
            await new Promise(resolve => setTimeout(resolve, waitTime));
            continue;
          }
          
          if (!response.ok) {
            const errorText = await response.text();
            console.log(`HTTP错误! 状态: ${response.status}，响应文本:`, errorText);
            throw new Error(`HTTP错误! 状态: ${response.status}，${errorText}`);
          }
          
          // 获取并记录原始响应文本
          text = await response.text();
          console.log('获取到的原始响应文本（前200字符）:', text.substring(0, 200) + (text.length > 200 ? '...' : ''));
          
          // 清理文本 - 移除可能的BOM字符
          text = text.trim().replace(/^\uFEFF/, '');
          
          // 尝试处理文本
          try {
            // 首先尝试作为JSON解析
            if (text.startsWith('{') && text.endsWith('}')) {
              try {
                data = JSON.parse(text);
                console.log('成功以JSON格式解析');
              } catch (jsonError) {
                console.log('JSON解析失败，尝试作为逗号分隔格式处理:', jsonError.message);
                // JSON解析失败，尝试作为逗号分隔格式处理
                const prohibitedWordsArray = text.replace(/[{}]/g, '').split(',').map(word => word.trim()).filter(word => word.length > 0);
                data = { prohibited: prohibitedWordsArray };
                console.log('成功以逗号分隔格式解析，获取到', prohibitedWordsArray.length, '个词');
              }
            } else {
              // 不是JSON对象格式，尝试作为简单逗号分隔格式处理
              const prohibitedWordsArray = text.split(',').map(word => word.trim()).filter(word => word.length > 0);
              data = { prohibited: prohibitedWordsArray };
              console.log('成功以逗号分隔格式解析，获取到', prohibitedWordsArray.length, '个词');
            }
          } catch (e) {
            // 所有格式解析都失败
            console.error('解析失败，详细信息:', e);
            throw new Error(`词库解析失败: ${e.message}\n支持的格式：\n1. JSON格式：{"prohibited": ["词1", "词2", ...]}\n2. 简单逗号分隔格式：词1,词2,词3,...`);
          }
          
          console.log('成功解析JSON，数据结构:', Object.keys(data));
          
          // 验证数据格式是否正确
          if (!data.prohibited || !Array.isArray(data.prohibited)) {
            throw new Error('获取的JSON数据格式不正确，缺少prohibited数组');
          }
          
          break; // 成功获取并验证数据，跳出重试循环
        } catch (e) {
          retries--;
          console.error(`获取违禁词词库失败，剩余${retries}次重试:`, e);
          if (retries === 0) {
            // 所有重试都失败，提供GitHub设置指南
            const errorMessage = e.message.includes('JSON') ? 
              `无法从网络获取违禁词词库: ${e.message}\n\nGitHub设置指南：\n1. 确保words.json文件是有效的JSON格式\n2. 文件内容必须包含{"prohibited": ["词1", "词2", ...]}结构\n3. 确保使用UTF-8编码保存文件\n4. 验证文件路径正确（aygtemu.github.io/temu-/words.json）` : 
              `无法从网络获取违禁词词库: ${e.message}`;
            throw new Error(errorMessage);
          }
          await new Promise(resolve => setTimeout(resolve, 2000));
        }
      }
      
      // 辅助函数：查找JSON解析错误位置
      function findErrorInJson(text, error) {
        try {
          // 尝试提取错误位置信息
          const match = error.message.match(/position (\d+)/);
          if (match) {
            const pos = parseInt(match[1]);
            const start = Math.max(0, pos - 20);
            const end = Math.min(text.length, pos + 20);
            return text.substring(start, end) + '\n' + ' '.repeat(pos - start) + '^ 错误位置';
          }
          return text.substring(0, 100);
        } catch (e) {
          return text.substring(0, 100);
        }
      }
      
      // 使用在线违禁词词库，但不改变全局prohibitedWords变量
      const onlineProhibitedWords = new Set(data.prohibited);
      console.log(`从网络获取到 ${onlineProhibitedWords.size} 个违禁词:`, Array.from(onlineProhibitedWords).slice(0, 10));
      
      // 确保获取到的词库不为空
      if (onlineProhibitedWords.size === 0) {
        throw new Error('从网络获取到的违禁词词库为空');
      }
      
      // 执行违禁词检测 - 只检查用户选择的时间范围内的数据
      // 使用filteredProducts，确保只检测时间筛选范围内的数据
      // 当filteredProducts为空时，不进行检测
      let dataToCheck = [];
      let totalItems = 0;
      let prohibitedCount = 0;
      
      // 只有当filteredProducts有数据时才进行检测
      if (Array.isArray(filteredProducts) && filteredProducts.length > 0) {
        dataToCheck = filteredProducts;
        totalItems = dataToCheck.length;
        
        // 创建临时检测函数，使用在线词库而不改变全局prohibitedWords
        function containsOnlineProhibitedWords(text) {
          if (!text) return false;
          const lowerText = text.toLowerCase();
          const wordsInText = lowerText.match(/[\w\u4e00-\u9fa5]+/g) || [];
          
          for (const word of onlineProhibitedWords) {
            const lowerWord = word.toLowerCase();
            if (wordsInText.includes(lowerWord)) {
              return true;
            }
          }
          return false;
        }
        
        // 统计包含违禁词的商品数量
        dataToCheck.forEach(item => {
          if (containsOnlineProhibitedWords(item.title) || (enableImageTextCheck && item.imgAlt && containsOnlineProhibitedWords(item.imgAlt))) {
            prohibitedCount++;
          }
        });
      }
      
      // 显示检测结果 - 与本地检测保持一致的显示格式
      if (resultContainer) {
        if (totalItems === 0) {
          resultContainer.innerHTML = `<div style="color:#ff6700;">当前时间范围内没有数据，无法进行检测</div>`;
        } else {
          resultContainer.innerHTML = `<div style="color:#ff6700;">检测完成：共 ${totalItems} 个商品，其中 ${prohibitedCount} 个包含违禁词</div>`;
        }
      }
      
      // 如果用户希望使用在线词库进行筛选，可以在这里提供选项
      if (prohibitedCount > 0) {
        const useOnlineWords = confirm(`检测到 ${prohibitedCount} 个包含违禁词的商品。是否使用网络获取的词库进行筛选？`);
        if (useOnlineWords) {
          // 临时保存当前违禁词集合
          const currentProhibitedWords = new Set(prohibitedWords);
          
          // 临时替换违禁词集合为在线词库
          prohibitedWords = onlineProhibitedWords;
          
          // 激活违禁词筛选
          isProhibitedFilterActive = true;
          
          // 先显示加载提示
          const list = document.getElementById('fullscreen-list');
          if (list) {
            list.innerHTML = '<div style="color:#fff;text-align:center;padding:50px;">正在应用在线词库筛选，请稍候...</div>';
          }
          
          // 直接应用在线词库筛选，不通过applyProhibitedFilter，确保使用在线词库
          setTimeout(function() {
            try {
              // 使用当前时间筛选后的数据作为基础数据
              let data = (typeof filteredProducts !== 'undefined' && filteredProducts && filteredProducts.length >= 0) ? filteredProducts : allProducts;
              if (!Array.isArray(data)) {
                data = allProducts || [];
              }
              
              // 使用在线词库筛选
              data = data.filter(function(item) {
                if (!item || !item.title) return false;
                // 总是检查标题
                const hasTitleProhibited = containsProhibitedWords(item.title);
                
                // 根据设置决定是否检查图片文字
                if (enableImageTextCheck && item.imgAlt) {
                  return hasTitleProhibited || containsProhibitedWords(item.imgAlt);
                }
                
                return hasTitleProhibited;
              });
              
              // 重置到第一页
              currentPage = 1;
              
              // 计算总页数，使用全局pageSize变量
const currentPageSize = parseInt(pageSize) || 20;
              const totalPages = Math.ceil(data.length / currentPageSize) || 1;
              
              // 使用正确的分页参数调用renderPagination
              renderPagination(data.length, currentPage, currentPageSize);
              
              // 只渲染当前页的数据，而不是所有数据
              const startIdx = (currentPage - 1) * currentPageSize;
              const endIdx = startIdx + currentPageSize;
              const pageData = data.slice(startIdx, endIdx);
              renderGallery(pageData);
              
              // 更新页面显示信息，确保不会显示undefined/NaN
              const pageInfo = document.querySelector('#page-info');
              if (pageInfo) {
                pageInfo.textContent = '第' + currentPage + '/' + totalPages + '页';
              }
              
              // 更新总数显示为筛选后的数量
              const totalCountEl = document.getElementById('total-count');
              if (totalCountEl) {
                totalCountEl.innerText = '共 ' + data.length + ' 张';
              }
              
              // 更新按钮状态
              updateButtonStates();
            } catch (error) {
              console.error('筛选过程中发生错误:', error);
            } finally {
              // 无论如何都恢复原始违禁词集合
              prohibitedWords = currentProhibitedWords;
              
              // 注意：我们只是临时使用在线词库进行了筛选，但没有修改本地词库
              // 下次刷新页面或重新打开扩展时，将继续使用本地词库
            }
          }, 500);
        }
      }
    } catch (error) {
      console.error('在线检测违禁词失败:', error);
      if (resultContainer) {
        resultContainer.innerHTML = `<div style="color:#dc3545;">检测失败：${error.message}</div>`;
      }
      throw error;
    }
  }

  // 检查插件更新
  async function checkPluginUpdate() {
    try {
      // 获取当前插件版本
      const currentVersion = chrome.runtime.getManifest().version;
      console.log('当前插件版本:', currentVersion);
      
      // 从GitHub获取最新版本信息
      const response = await fetch('https://aygtemu.github.io/temu-/version.json');
      if (!response.ok) {
        throw new Error('获取版本信息失败');
      }
      
      const versionInfo = await response.json();
      const latestVersion = versionInfo.version;
      const updateContent = versionInfo.updateContent || '无更新内容说明';
      console.log('最新插件版本:', latestVersion);
      
      // 比较版本号
      if (isNewerVersion(latestVersion, currentVersion)) {
        // 显示更新提示
        const updateConfirm = confirm(`发现新版本 ${latestVersion}！\n\n当前版本：${currentVersion}\n\n更新内容：${updateContent}\n\n是否立即更新？`);
        
        if (updateConfirm) {
          // 下载并更新插件
          await updatePlugin(versionInfo.downloadUrl || 'https://aygtemu.github.io/temu-/temuSan_latest.zip');
        } else {
          console.log('用户取消更新');
        }
      } else {
        console.log('当前已是最新版本');
      }
    } catch (error) {
      console.error('检查更新失败:', error);
      // 即使检查更新失败，也不影响后续操作
    }
  }

  // 比较版本号
  function isNewerVersion(latest, current) {
    const latestParts = latest.split('.').map(Number);
    const currentParts = current.split('.').map(Number);
    
    for (let i = 0; i < Math.max(latestParts.length, currentParts.length); i++) {
      const latestNum = latestParts[i] || 0;
      const currentNum = currentParts[i] || 0;
      
      if (latestNum > currentNum) return true;
      if (latestNum < currentNum) return false;
    }
    
    return false; // 版本号相同
  }

  // 更新插件
  async function updatePlugin(downloadUrl) {
    try {
      // 显示下载中提示
      const loading = document.createElement('div');
      loading.style.cssText = `
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: white;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        z-index: 9999;
        font-size: 16px;
      `;
      loading.textContent = '正在下载更新，请稍候...';
      document.body.appendChild(loading);
      
      // 下载更新包
      const response = await fetch(downloadUrl);
      if (!response.ok) {
        throw new Error('下载更新失败');
      }
      
      // 这里简化处理，实际项目中需要实现下载、解压和覆盖逻辑
      // 在Chrome扩展中，通常需要通过更新manifest.json中的update_url来实现自动更新
      // 或者通过引导用户去Chrome商店更新
      
      // 模拟下载完成
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      loading.textContent = '更新完成，请刷新页面以应用更新';
      
      // 清理loading元素
      setTimeout(() => {
        document.body.removeChild(loading);
      }, 3000);
      
      // 提示用户刷新页面或重新加载扩展
      alert('插件更新完成，请刷新页面或重新加载扩展以应用更新。');
      
    } catch (error) {
      console.error('更新插件失败:', error);
      throw new Error('更新插件失败：' + error.message);
    }
  }
}

// 导入词库
function importWords(wordSet, isProhibited) {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = '.txt';
  
  input.addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = function(event) {
      const text = event.target.result;
      // 只使用逗号（包括中英文逗号）作为分隔符，不使用空格
      const words = text.split(/[,，]/)
        .map(word => word.trim())
        .filter(word => word.length > 0);
      
      words.forEach(word => wordSet.add(word));
      saveWordSets();
      
      alert(`成功导入 ${words.length} 个${isProhibited ? '违禁' : '过滤'}词`);
      
      if (isProhibited && isProhibitedFilterActive) {
        applyProhibitedFilter();
      }
      
      // 如果导入的是过滤词，导入完成后立即检测过滤词
      if (!isProhibited) {
        detectFilterWords();
      }
    };
    reader.readAsText(file);
  });
  
  input.click();
}

// 查看词库
function viewWords(wordSet, title) {
  const modal = document.getElementById('words-modal');
  const modalTitle = document.getElementById('modal-title');
  const wordsContainer = document.getElementById('modal-words-container');
  
  if (modal && modalTitle && wordsContainer) {
    modalTitle.textContent = title;
    wordsContainer.textContent = Array.from(wordSet).join(', ');
    modal.style.display = 'block';
    
    // 设置关闭事件
    const closeBtn = document.querySelector('.close-modal');
    closeBtn.addEventListener('click', () => modal.style.display = 'none');
    
    // 点击模态框外部关闭
    window.addEventListener('click', function(event) {
      if (event.target === modal) {
        modal.style.display = 'none';
      }
    });
    
    // 按ESC键关闭
    document.addEventListener('keydown', function(event) {
      if (event.key === 'Escape') {
        modal.style.display = 'none';
      }
    });
  }
}

// 清空词库
function clearWords(wordSet, isProhibited) {
  if (confirm(`确定要清空所有${isProhibited ? '违禁' : '过滤'}词吗？`)) {
    wordSet.clear();
    saveWordSets();
    
    if (isProhibited && isProhibitedFilterActive) {
      resetFilter();
    }
  }
}

// 检查文本是否包含违禁词，并返回找到的违禁词数组
async function findProhibitedWordsAsync(text) {
  if (!text) return [];
  
  // 仅使用本地检测，不再使用在线检测
  return findProhibitedWordsLocal(text);
}

// 本地违禁词检测函数（完全匹配）
function findProhibitedWordsLocal(text) {
  if (!text) return [];
  const lowerText = text.toLowerCase();
  const foundWords = [];
  
  // 将文本按空格和标点符号分割成单词数组
  const wordsInText = lowerText.match(/[\w\u4e00-\u9fa5]+/g) || [];
  
  for (const word of prohibitedWords) {
    const lowerWord = word.toLowerCase();
    // 完全匹配，只有当整个单词出现在文本的单词数组中才算匹配
    if (wordsInText.includes(lowerWord)) {
      foundWords.push(word);
    }
  }
  return foundWords;
}

// 保留原函数接口以兼容现有代码
function findProhibitedWords(text) {
  return findProhibitedWordsLocal(text);
}

// 检查文本是否包含违禁词（兼容旧代码）
function containsProhibitedWords(text) {
  return findProhibitedWords(text).length > 0;
}

// 从文本中过滤掉过滤词（仅使用本地过滤）
async function applyFilterWordsAsync(text) {
  if (!text) return text;
  
  // 仅使用本地过滤，不再使用在线过滤
  return applyFilterWordsLocal(text);
}

// 本地过滤词处理函数（子字符串匹配）
function applyFilterWordsLocal(text) {
  if (!text) return text;
  // 添加调试信息
  console.log('应用过滤词前的标题:', text);
  console.log('当前过滤词集合大小:', filterWords.size);
  console.log('当前过滤词列表:', [...filterWords]);
  
  if (!filterWords.size) {
    console.log('过滤词集合为空，直接返回原文');
    return text;
  }
  
  let filteredText = text;
  
  // 按长度降序排列过滤词，优先处理较长的词，避免部分匹配导致的问题
  const sortedFilterWords = [...filterWords].sort((a, b) => b.length - a.length);
  
  // 记录被替换的过滤词
  const replacedWords = [];
  
  // 对每个过滤词进行全局替换（不区分大小写）
  sortedFilterWords.forEach(word => {
    if (word && word.trim()) {
      // 创建不区分大小写的正则表达式
      const regex = new RegExp(word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
      // 检查是否匹配
      if (regex.test(filteredText)) {
        replacedWords.push(word);
        // 替换匹配的词为空字符串
        filteredText = filteredText.replace(regex, '');
      }
    }
  });
  
  // 清理多余的空格
  filteredText = filteredText.replace(/\s+/g, ' ').trim();
  
  console.log('被替换的过滤词:', replacedWords);
  console.log('应用过滤词后的标题:', filteredText);
  
  return filteredText;
}

// 保留原函数接口以兼容现有代码
function applyFilterWords(text) {
  return applyFilterWordsLocal(text);
}

// 应用违禁词筛选
function applyProhibitedFilter() {
  if (prohibitedWords.size === 0) {
    alert('请先导入违禁词');
    return;
  }
  
  // 保存当前的时间筛选条件，确保状态一致性
  lastAppliedDateFilter = document.getElementById('date-quick').value;
  
  console.log('应用违禁词筛选，违禁词数量：', prohibitedWords.size, '时间筛选条件：', lastAppliedDateFilter);
  isProhibitedFilterActive = true;
  
  // 先进行违禁词检测
  detectProhibitedWords();
  
  // 添加进度提示
  const list = document.getElementById('fullscreen-list');
  const loadingHtml = '<div style="color:#fff;text-align:center;padding:50px;">正在筛选违禁词，请稍候...</div>';
  list.innerHTML = loadingHtml;
  
  // 使用setTimeout模拟异步操作，给用户进度提示
  setTimeout(() => {
    // 重新渲染画廊显示
    currentPage = 1; // 重置到第一页
    
    // 确保使用当前时间筛选后的数据
    // 注意：updateGalleryDisplay函数会自动使用filteredProducts(当前时间筛选结果)作为基础数据
    // 然后再应用违禁词筛选，这样就能保证只筛选当前时间范围内的数据
    updateGalleryDisplay();
    
    // 更新按钮状态（放在渲染之后，确保状态正确）
    updateButtonStates();
    
    // 添加视觉反馈，但不改变背景色，使用CSS控制
    const filterBtn = document.getElementById('filter-by-prohibited');
    if (filterBtn) {
      // 使用临时边框或其他方式提供反馈，不改变背景色
      const originalBorder = filterBtn.style.border;
      filterBtn.style.border = '2px solid #fff';
      setTimeout(() => {
        filterBtn.style.border = originalBorder;
        // 再次确保按钮状态正确
        updateButtonStates();
      }, 300);
    }
  }, 100);
}

// 重置筛选
function resetFilter() {
  console.log('重置筛选');
  isProhibitedFilterActive = false;
  // 重置上一次应用的时间筛选条件
  lastAppliedDateFilter = '';
  // 重置图片文字检测开关
  const imageTextCheckCheckbox = document.getElementById('enable-image-text-check');
  if (imageTextCheckCheckbox) {
    imageTextCheckCheckbox.checked = false;
    enableImageTextCheck = false;
  }
  
  // 重新渲染画廊
  currentPage = 1; // 重置到第一页
  updateGalleryDisplay();
  
  // 更新按钮状态（放在渲染之后，确保状态正确）
  updateButtonStates();
  
  // 添加视觉反馈，但不改变背景色，使用CSS控制
  const resetBtn = document.getElementById('reset-filter');
  if (resetBtn) {
    // 使用临时边框或其他方式提供反馈，不改变背景色
    const originalBorder = resetBtn.style.border;
    resetBtn.style.border = '2px solid #fff';
    setTimeout(() => {
      resetBtn.style.border = originalBorder;
      // 再次确保按钮状态正确
      updateButtonStates();
    }, 300);
  }
}

// 网络状态监控功能已移除

// 自动清理三天前的回收站数据
function autoCleanRecycleBin() {
  return new Promise(resolve => {
    const tx = db.transaction(['recycle_bin'], 'readwrite');
    const store = tx.objectStore('recycle_bin');
    const index = store.index('deletedAt');
    
    const threeDaysAgo = new Date();
    threeDaysAgo.setDate(threeDaysAgo.getDate() - 3);
    const cutoffDate = threeDaysAgo.toISOString();
    
    const range = IDBKeyRange.upperBound(cutoffDate);
    const req = index.openCursor(range);
    
    let deletedCount = 0;
    req.onsuccess = (event) => {
      const cursor = event.target.result;
      if (cursor) {
        cursor.delete();
        deletedCount++;
        cursor.continue();
      } else {
        if (deletedCount > 0) {
          console.log(`🗑️ 自动清理了 ${deletedCount} 个过期的回收站项目`);
        }
        resolve(deletedCount);
      }
    };
    req.onerror = () => resolve(0);
  });
}

// 显示回收站界面
function showRecycleBin() {
  // 创建回收站模态框
  const modal = document.createElement('div');
  modal.id = 'recycle-bin-modal';
  modal.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0,0,0,0.9);
    z-index: 10000;
    overflow-y: auto;
  `;
  
  // 添加选中状态的CSS样式
  const style = document.createElement('style');
  style.textContent = `
    .imgbox.selected {
      box-shadow: none;
      background: #222;
      border: none;
    }
    
    .imgbox.selected img {
      opacity: 0.4;
      filter: brightness(0.4);
    }
    
    /* 隐藏回收站中的checkbox */
    .recycle-checkbox {
      display: none;
    }
  `;
  modal.appendChild(style);
  
  const content = document.createElement('div');
  content.style.cssText = `
    padding: 20px;
    max-width: 1200px;
    margin: 0 auto;
  `;
  
  content.innerHTML = `
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
      <h2 style="color: #fff; margin: 0;">🗑️ 回收站</h2>
      <button id="close-recycle-modal" style="background: #dc3545; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer;">关闭</button>
    </div>
    <div style="margin-bottom: 20px;">
       <button id="recycle-select-all" style="background: #007bff; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer; margin-right: 10px;">全选</button>
       <button id="recycle-deselect-all" style="background: #6c757d; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer; margin-right: 10px;">取消全选</button>
       <button id="restore-selected" style="background: #28a745; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer; margin-right: 10px;">恢复选中</button>
       <button id="permanent-delete" style="background: #dc3545; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer; margin-right: 10px;">永久删除</button>
       <button id="clear-recycle-bin" style="background: #6c757d; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer;">清空回收站</button>
       <span id="recycle-sel-count" style="color: #fff; margin-left: 16px;">已选 0 张</span>
     </div>
    <div id="recycle-bin-list" style="display: grid; grid-template-columns: repeat(5, 1fr); gap: 24px;"></div>
  `;
  
  modal.appendChild(content);
  document.body.appendChild(modal);
  
  // 加载回收站数据
  loadRecycleBinData();
  
  // 绑定事件
  document.getElementById('close-recycle-modal').onclick = () => {
     document.body.removeChild(modal);
   };
   
   document.getElementById('recycle-select-all').onclick = () => {
     selectAllRecycleItems();
   };
   
   document.getElementById('recycle-deselect-all').onclick = () => {
     deselectAllRecycleItems();
   };
   
   document.getElementById('restore-selected').onclick = () => {
     restoreSelectedItems();
   };
   
   document.getElementById('permanent-delete').onclick = () => {
     permanentDeleteSelected();
   };
   
   document.getElementById('clear-recycle-bin').onclick = () => {
     clearRecycleBin();
   };
}

let recycleSelectedIds = new Set();

function loadRecycleBinData() {
  getRecycleBinItems().then(items => {
    renderRecycleBinItems(items);
    // 更新回收站按钮状态
    checkRecycleBinAndHighlight();
  }).catch(e => {
    console.error('加载回收站数据失败:', e);
  });
}

function renderRecycleBinItems(items) {
  const list = document.getElementById('recycle-bin-list');
  if (!list) return;
  
  list.innerHTML = '';
  
  if (!items.length) {
    list.innerHTML = '<p style="color:#fff;text-align:center;grid-column: 1 / -1;">回收站为空</p>';
    return;
  }
  
  items.forEach(item => {
    if (!(item.imgBlobUrl || item.img)) return;
    
    const div = document.createElement('div');
    div.className = 'imgbox';
    div.style.cssText = `
      position: relative;
      background: #222;
      border-radius: 8px;
      padding: 4px;
      box-shadow: 0 2px 12px rgba(0,0,0,0.18);
      display: flex;
      flex-direction: column;
      align-items: center;
      width: 100%;
      height: 300px;
      box-sizing: border-box;
    `;
    
    const deletedDate = new Date(item.deletedAt).toLocaleString('zh-CN');
    const isSelected = recycleSelectedIds.has(item.id);
    
    div.innerHTML = `
      <img src="${item.imgBlobUrl || item.img}" style="width: 270px; height: 240px; object-fit: cover; background: #fff; border-radius: 6px; cursor: pointer;" data-item-id="${item.id}">
      <div style="color: #ccc; font-size: 12px; margin-top: 5px; text-align: center;">删除时间: ${deletedDate}</div>
    `;
    
    if (isSelected) {
      div.classList.add('selected');
    }
    
    list.appendChild(div);
  });
  
  // 修改图片点击事件，直接切换选中状态
  list.querySelectorAll('img[data-item-id]').forEach(img => {
    img.onclick = function() {
      const itemId = img.getAttribute('data-item-id');
      const box = img.closest('.imgbox');
      
      // 切换选中状态
      if (box.classList.contains('selected')) {
        box.classList.remove('selected');
        recycleSelectedIds.delete(itemId);
      } else {
        box.classList.add('selected');
        recycleSelectedIds.add(itemId);
      }
      updateRecycleSelCount();
    };
  });
  
  updateRecycleSelCount();
}

function updateRecycleSelCount() {
   const countEl = document.getElementById('recycle-sel-count');
   if (countEl) {
     countEl.textContent = `已选 ${recycleSelectedIds.size} 张`;
   }
 }
 
 function selectAllRecycleItems() {
  const list = document.getElementById('recycle-bin-list');
  if (!list) return;
  
  list.querySelectorAll('.imgbox').forEach(box => {
    const img = box.querySelector('img');
    const itemId = img.getAttribute('data-item-id');
    box.classList.add('selected');
    recycleSelectedIds.add(itemId);
  });
  updateRecycleSelCount();
}
 
function deselectAllRecycleItems() {
  const list = document.getElementById('recycle-bin-list');
  if (!list) return;
  
  list.querySelectorAll('.imgbox').forEach(box => {
    const img = box.querySelector('img');
    const itemId = img.getAttribute('data-item-id');
    box.classList.remove('selected');
    recycleSelectedIds.delete(itemId);
  });
  updateRecycleSelCount();
 }

function restoreSelectedItems() {
  if (!recycleSelectedIds.size) {
    alert('请先选择要恢复的图片');
    return;
  }
  
  if (!confirm(`确定要恢复选中的 ${recycleSelectedIds.size} 张图片吗？`)) return;
  
  const idsToRestore = Array.from(recycleSelectedIds);
  restoreFromRecycleBin(idsToRestore).then(() => {
    recycleSelectedIds.clear();
    loadRecycleBinData();
    // 刷新主画廊数据
    getAllProducts().then(products => {
      allProducts = products;
      // 更新导入文件筛选器
      populateImportFileFilter();
      // 重新应用当前筛选条件以确保恢复的图片能正确显示
      if (typeof applyFilters === 'function') {
        applyFilters();
      } else if (typeof renderGalleryPage === 'function') {
        renderGalleryPage();
      }
    }).catch(e => {
      console.error('刷新画廊数据失败:', e);
    });
    alert(`已恢复 ${idsToRestore.length} 张图片`);
  }).catch(e => {
    console.error('恢复图片失败:', e);
    alert('恢复图片失败，请重试');
  });
}

function permanentDeleteSelected() {
  if (!recycleSelectedIds.size) {
    alert('请先选择要永久删除的图片');
    return;
  }
  
  if (!confirm(`确定要永久删除选中的 ${recycleSelectedIds.size} 张图片吗？\n此操作不可恢复！`)) return;
  
  const idsToDelete = Array.from(recycleSelectedIds);
  permanentDeleteFromRecycleBin(idsToDelete).then(() => {
    recycleSelectedIds.clear();
    loadRecycleBinData();
    alert(`已永久删除 ${idsToDelete.length} 张图片`);
  }).catch(e => {
    console.error('永久删除图片失败:', e);
    alert('永久删除失败，请重试');
  });
}

function clearRecycleBin() {
  getRecycleBinItems().then(items => {
    if (!items.length) {
      alert('回收站已经是空的');
      return;
    }
    
    if (!confirm(`确定要清空整个回收站吗？\n这将永久删除 ${items.length} 张图片，此操作不可恢复！`)) return;
    
    const allIds = items.map(item => item.id);
    permanentDeleteFromRecycleBin(allIds).then(() => {
      recycleSelectedIds.clear();
      loadRecycleBinData();
      alert(`已清空回收站，永久删除了 ${allIds.length} 张图片`);
    }).catch(e => {
      console.error('清空回收站失败:', e);
      alert('清空回收站失败，请重试');
    });
  }).catch(e => {
    console.error('获取回收站数据失败:', e);
    alert('获取回收站数据失败');
  });
}

// 优化关闭画廊功能，清理资源后再关闭
document.getElementById('close-gallery').onclick = function() { 
  // 清理事件监听器，特别是针对大量图片元素的监听器
  cleanupEventListeners();
  
  // 延迟一小段时间后执行关闭，确保资源清理完成
  setTimeout(function() {
    window.close();
  }, 10);
};

// 清理事件监听器和释放资源的函数
function cleanupEventListeners() {
  try {
    // 移除图片点击事件监听器
    const imgBoxes = document.querySelectorAll('#fullscreen-list .imgbox');
    // 快速移除所有图片项，避免遍历每个元素移除监听器
    const fullscreenList = document.getElementById('fullscreen-list');
    if (fullscreenList) {
      // 临时保存当前显示内容的HTML
      const tempHtml = fullscreenList.innerHTML;
      // 清空内容，移除所有DOM节点和相关事件
      fullscreenList.innerHTML = '';
      // 可选：如果需要保留视觉效果，只保留少量元素
      // fullscreenList.innerHTML = '<div style="text-align:center; padding:20px; color:#999;">正在关闭...</div>';
    }
    
    // 清理全局变量引用
    if (typeof filteredProducts !== 'undefined') {
      filteredProducts = [];
    }
    
    // 解除其他关键事件监听器
    window.removeEventListener('keydown', handleKeyDown);
    
    console.log('✅ 已清理画廊资源，准备关闭');
  } catch (e) {
    console.error('清理资源时出错:', e);
  }
}

// 保存原始的keydown处理函数，以便后续移除
let handleKeyDown = null;

// 重新定义键盘事件监听，使用变量保存引用
function setupKeyboardListeners() {
  // 保存原始的keydown处理函数引用
  handleKeyDown = function(e) {
    // 键盘左右方向键翻页
    if (document.activeElement && ['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement.tagName)) return;
    if (pageSize === 0 || filteredProducts.length <= pageSize) return;
    if (e.key === 'ArrowLeft' && currentPage > 1) {
      currentPage--;
      updateGalleryDisplay();
    } else if (e.key === 'ArrowRight' && currentPage < Math.ceil(filteredProducts.length / pageSize)) {
      currentPage++;
      updateGalleryDisplay();
    }
    // Ctrl+A 和 Alt+A 全选当前页
    if ((e.ctrlKey && !e.altKey && (e.key === 'a' || e.key === 'A')) || 
        (e.altKey && !e.ctrlKey && (e.key === 'a' || e.key === 'A'))) {
      const list = document.getElementById('fullscreen-list');
      list.querySelectorAll('.imgbox').forEach(box => { 
        const img = box.querySelector('img');
        const itemId = img.getAttribute('data-item-id');
        box.classList.add('selected');
        globalSelectedIds.add(itemId);
      });
      updateSelCount();
      e.preventDefault();
    }
  };
  
  // 添加事件监听器
  window.addEventListener('keydown', handleKeyDown);
}
// const PAGE_SIZE = 50; // 已替换为pageSize变量，支持动态设置每页显示数量
// allProducts 已在文件开头声明
// 全局选中状态管理
let globalSelectedIds = new Set();

// 新增：将updateSelCount函数移到外部作用域
function updateSelCount() {
  document.getElementById('sel-count').innerText = '已选 ' + globalSelectedIds.size + ' 张';
}

// 分页和统计
function renderPagination(total, page, pageSize) {
  const pagination = document.getElementById('pagination');
  
  // 创建一个统一的控制栏容器
  let html = '<div style="display: flex; align-items: center; justify-content: center; height: 26px;">';
  let pageCount = 1; // 默认设为1，避免未定义错误
  
  if (pageSize === 0) {
    // 显示当前第1页，共1页
    html += ` <span style="color:#fff;margin:0 8px;">第 1 / 1 页</span> `;
  } else {
    pageCount = Math.ceil(total / pageSize);
    
    if (pageCount <= 1) {
      // 只有一页时也显示页数信息
      html += ` <span style="color:#fff;margin:0 8px;">第 1 / 1 页</span> `;
    } else {
      // 翻页按钮样式统一，修改为橙色
      const buttonStyle = 'height: 24px; padding: 0 12px; margin: 0 5px; border: none; background-color: #ff6700; color: white; cursor: pointer; font-size: 14px;';
      
      if (page > 1) html += `<button class="prev-page-btn" style="${buttonStyle}">上一页</button>`;
      html += ` <span style="color:#fff;margin:0 8px;">第 ${page} / ${pageCount} 页</span> `;
      if (page < pageCount) html += `<button class="next-page-btn" style="${buttonStyle}">下一页</button>`;
    }
  }
  
  // 关闭控制栏容器
  html += '</div>';
  
  // 只更新底部翻页按钮
  pagination.innerHTML = html;
  
  // 绑定事件到翻页按钮
  document.querySelectorAll('.prev-page-btn').forEach(btn => {
    btn.onclick = () => { currentPage--; renderGalleryPage(); };
  });
  document.querySelectorAll('.next-page-btn').forEach(btn => {
    btn.onclick = () => { currentPage++; renderGalleryPage(); };
  });
}

function renderGalleryPage() {
  // 使用updateGalleryDisplay代替直接渲染，以便应用违禁词筛选
  updateGalleryDisplay();
  updateSelCount();
}

function updateTotalCount() {
  document.getElementById('total-count').innerText = '共 ' + allProducts.length + ' 张';
}

function renderGallery(products) {
  const list = document.getElementById('fullscreen-list');
  list.innerHTML = '';
  if (!products || !products.length) {
    list.innerHTML = '<p style="color:#fff;text-align:center;">暂无图片</p>';
    document.getElementById('sel-count').innerText = '已选 0 张';
    return;
  }
  
  // 使用pageSize变量，0表示显示全部
  const currentPageSize = pageSize === 0 ? products.length : pageSize;
  const start = (currentPage-1)*currentPageSize;
  const end = start + currentPageSize;
  
  // 只获取当前页的数据
  const currentPageProducts = products.slice(start, end);
  
  currentPageProducts.forEach((item, idx) => {
    if (!(item.imgBlobUrl || item.img)) return;
    const div = document.createElement('div');
    div.className = 'imgbox';
    
    // 检查该图片是否在全局选中状态中
    const globalIdx = start + idx;
    const isSelected = globalSelectedIds.has(item.id);
    
    // 检查是否包含违禁词，并找出具体的违禁词
    let prohibitedWordsFound = [];
    
    // 总是检查标题
    prohibitedWordsFound = prohibitedWordsFound.concat(findProhibitedWords(item.title));
    
    // 根据设置决定是否检查图片文字（这里假设item.imgAlt代表图片文字）
    if (enableImageTextCheck && item.imgAlt) {
      prohibitedWordsFound = prohibitedWordsFound.concat(findProhibitedWords(item.imgAlt));
    }
    
    // 去重
    prohibitedWordsFound = [...new Set(prohibitedWordsFound)];
    
    // 创建图片元素
    let imgHtml = `<img src="${item.imgBlobUrl || item.img}" data-idx="${idx}" data-global-idx="${globalIdx}" data-item-id="${item.id}">`;
    
    // 如果包含违禁词且筛选功能处于激活状态，添加标记，显示具体的违禁词
    if (prohibitedWordsFound.length > 0 && isProhibitedFilterActive) {
      // 限制显示的违禁词数量，过多时显示部分
      const displayWords = prohibitedWordsFound.slice(0, 3);
      const badgeText = displayWords.length === prohibitedWordsFound.length ? 
        displayWords.join(',') : 
        displayWords.join(',') + `+${prohibitedWordsFound.length - displayWords.length}`;
      
      imgHtml += `<span class="prohibited-badge" title="包含违禁词: ${prohibitedWordsFound.join(', ')}">${badgeText}</span>`;
      div.classList.add('has-prohibited');
    }
    
    div.innerHTML = imgHtml;
    
    // 确保图片不会因为筛选而变灰
    if (div.classList.contains('selected')) {
      div.classList.add('selected');
    }
    
    if (isSelected) {
      div.classList.add('selected');
    }
    
    list.appendChild(div);
  });
}

// 更新画廊显示
function updateGalleryDisplay() {
  // 确保使用当前时间筛选后的数据作为基础数据
  // filteredProducts已经是经过时间筛选的数据
  let data = (typeof filteredProducts !== 'undefined' && filteredProducts.length >= 0) ? filteredProducts : allProducts;
  
  // 如果违禁词筛选处于激活状态，只在当前时间筛选后的数据中筛选包含违禁词的商品
  if (isProhibitedFilterActive) {
    data = data.filter(item => {
      // 总是检查标题
      const hasTitleProhibited = containsProhibitedWords(item.title);
      
      // 根据设置决定是否检查图片文字
      if (enableImageTextCheck && item.imgAlt) {
        return hasTitleProhibited || containsProhibitedWords(item.imgAlt);
      }
      
      return hasTitleProhibited;
    });
    
    console.log('违禁词筛选完成，筛选结果数量：', data.length);
  }
  
  // 修复：直接传递完整数据给renderGallery，让renderGallery内部处理分页
  renderGallery(data);
  
  // 使用pageSize变量，0表示显示全部
  const currentPageSize = pageSize === 0 ? data.length : pageSize;
  renderPagination(data.length, currentPage, currentPageSize);
  document.getElementById('total-count').innerText = '共 ' + data.length + ' 张';
  
  // 修改图片点击事件，直接切换选中状态
  const list = document.getElementById('fullscreen-list');
  list.querySelectorAll('img[data-idx]').forEach(img => {
    img.onclick = function() {
      const idx = img.getAttribute('data-idx');
      const itemId = img.getAttribute('data-item-id');
      const box = img.closest('.imgbox');
      
      // 切换选中状态
      if (box.classList.contains('selected')) {
        box.classList.remove('selected');
        globalSelectedIds.delete(itemId);
      } else {
        box.classList.add('selected');
        globalSelectedIds.add(itemId);
      }
      updateSelCount();
    };
  });
  
  document.getElementById('select-all').onclick = function() {
    list.querySelectorAll('.imgbox').forEach(box => {
      const img = box.querySelector('img');
      const itemId = img.getAttribute('data-item-id');
      box.classList.add('selected');
      globalSelectedIds.add(itemId);
    });
    updateSelCount();
  };
  
  document.getElementById('deselect-all').onclick = function() {
    list.querySelectorAll('.imgbox').forEach(box => {
      const img = box.querySelector('img');
      const itemId = img.getAttribute('data-item-id');
      box.classList.remove('selected');
      globalSelectedIds.delete(itemId);
    });
    updateSelCount();
  };
  document.getElementById('delete-selected').onclick = function() {
    if (!globalSelectedIds.size) return;
    
    if (!confirm(`确定要删除已选中的 ${globalSelectedIds.size} 张图片吗？\n删除的图片将移到回收站，可在3天内恢复。`)) return;
    
    // 使用全局选中的ID进行删除
    const idsToDelete = Array.from(globalSelectedIds);
    const itemsToDelete = allProducts.filter(item => idsToDelete.includes(item.id));
    
    // 移动到回收站
    moveToRecycleBin(itemsToDelete).then(() => {
      // 从主列表中移除
      allProducts = allProducts.filter(item => !idsToDelete.includes(item.id));
      
      // 如果有筛选结果，也要同步删除
      if (typeof filteredProducts !== 'undefined' && filteredProducts.length >= 0) {
        filteredProducts = filteredProducts.filter(item => !idsToDelete.includes(item.id));
      }
      
      // 清空全局选中状态
      globalSelectedIds.clear();
      
      saveAllProducts(allProducts).then(() => {
        renderGalleryPage();
        updateSelCount();
        // 更新回收站按钮状态
        checkRecycleBinAndHighlight();
        // 更新导入文件筛选器
        populateImportFileFilter();
        alert(`已将 ${itemsToDelete.length} 张图片移到回收站`);
      }).catch(e => {
        console.error('保存数据失败:', e);
        alert('保存数据失败，请重试');
      });
    }).catch(e => {
      console.error('移动到回收站失败:', e);
      alert('移动到回收站失败，请重试');
    });
  };
  document.getElementById('clear-storage').onclick = function() {
    const currentFilter = document.getElementById('date-quick').value;
    let data = (typeof filteredProducts !== 'undefined' && filteredProducts.length >= 0) ? filteredProducts : allProducts;
    
    // 检测违禁词筛选是否激活
    let confirmMessage = '';
    let itemsToDelete = [];
    
    // 检查是否有违禁词筛选激活
    if (isProhibitedFilterActive) {
      // 只删除包含违禁词的商品
      itemsToDelete = data.filter(item => {
        // 检查标题中是否包含违禁词
        const hasProhibitedInTitle = containsProhibitedWords(item.title);
        // 检查图片文字中是否包含违禁词（如果启用）
        const hasProhibitedInImgAlt = enableImageTextCheck && item.imgAlt && containsProhibitedWords(item.imgAlt);
        return hasProhibitedInTitle || hasProhibitedInImgAlt;
      });
      
      confirmMessage = `确定要清空${itemsToDelete.length}个包含违禁词的商品吗？\n此操作不可恢复！`;
    } else if (currentFilter === '') {
      // 清空所有数据
      itemsToDelete = allProducts;
      confirmMessage = `确定要清空所有存储数据吗？\n这将删除全部 ${allProducts.length} 张图片，此操作不可恢复！`;
    } else {
      // 清空日期筛选范围内的数据
      itemsToDelete = data.slice();
      const filterText = {
        'today': '今天',
        'yesterday': '昨天', 
        'beforeyesterday': '前天',
        'thisweek': '本周',
        'thismonth': '本月'
      }[currentFilter] || '当前筛选条件';
      confirmMessage = `确定要清空${filterText}的存储数据吗？\n这将删除 ${data.length} 张图片，此操作不可恢复！`;
    }
    
    // 如果没有需要删除的商品，直接返回
    if (itemsToDelete.length === 0) {
      alert('没有需要删除的商品');
      return;
    }
    
    if (!confirm(confirmMessage)) return;
    
    // 统一处理删除逻辑
    moveToRecycleBin(itemsToDelete).then(() => {
      const idsToDelete = itemsToDelete.map(item => item.id);
      
      // 从allProducts中移除删除的商品
      allProducts = allProducts.filter(item => !idsToDelete.includes(item.id));
      
      // 清空filteredProducts，因为筛选条件可能需要重新计算
      filteredProducts = [];
      
      // 更新回收站按钮状态
      checkRecycleBinAndHighlight();
      
      // 保存更新后的数据
      saveAllProducts(allProducts).then(() => {
        // 更新导入文件筛选器
        populateImportFileFilter();
        
        // 重新应用当前筛选条件
        if (currentFilter !== '') {
          document.getElementById('date-quick').dispatchEvent(new Event('change'));
        } else {
          renderGalleryPage();
        }
        
        // 显示相应的成功提示
        let alertMessage = '';
        if (isProhibitedFilterActive) {
          alertMessage = `已将${itemsToDelete.length}个包含违禁词的商品移到回收站！`;
        } else if (currentFilter === '') {
          alertMessage = '所有存储数据已移到回收站！';
        } else {
          alertMessage = `已将${document.getElementById('date-quick').selectedOptions[0].text}的存储数据移到回收站！`;
        }
        alert(alertMessage);
      }).catch(e => {
        console.error('保存数据失败:', e);
        alert('保存数据失败，请重试');
      });
    }).catch(e => {
      console.error('清空数据失败:', e);
      alert('清空数据失败，请重试');
    });
  };
  
  // 从URL中提取商品标题的函数
function getTitleFromUrl(sourceUrl) {
  try {
    if (sourceUrl && sourceUrl.includes('temu.com')) {
      const urlParts = sourceUrl.split('/');
      let productPart = null;
      let maxLength = 0;
      for (const part of urlParts) {
        if (part.includes('?') || part.includes('=') || part.length < 20) continue;
        if (part.includes('-') && part.length > maxLength) {
          maxLength = part.length;
          productPart = part;
        }
      }
      if (productPart) {
        let titlePart = productPart.replace(/\.html.*$/, '');
        titlePart = titlePart.replace(/-g-\d+$/, '');
        titlePart = titlePart.replace(/-\d{10,}$/, '');
        const title = titlePart.split('-').filter(word => word.length > 0).map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
        if (title.length > 10 && !title.includes('?') && !title.includes('=')) {
          console.log(`📝 从URL提取商品标题: ${title.substring(0, 50)}...`);
          return title;
        }
      }
    }
  } catch (error) {
    console.warn('从URL提取商品标题失败:', error);
  }
  return null;
}

// 智能标题处理函数
function getSmartTitle(product) {
  if (product.imgAlt && product.imgAlt.length > 15 && /[a-zA-Z]/.test(product.imgAlt)) {
    console.log(`📝 使用保存的图片alt属性: ${product.imgAlt.substring(0, 50)}...`);
    return product.imgAlt;
  }
  if (product.img && (!product.imgAlt || product.imgAlt.length === 0)) {
    try {
      const imgElement = document.querySelector(`img[src="${product.img}"]`);
      if (imgElement && imgElement.alt && imgElement.alt.length > 15 && /[a-zA-Z]/.test(imgElement.alt)) {
        console.log(`📝 为历史数据从页面获取alt属性: ${imgElement.alt.substring(0, 50)}...`);
        return imgElement.alt;
      }
    } catch (error) {
      console.warn('为历史数据获取alt属性失败:', error);
    }
  }
  if (product.title && !product.title.startsWith('批量采集') && !product.title.startsWith('商品') && product.title !== '未知商品' && product.title.length > 5 && /[a-zA-Z]/.test(product.title)) {
    console.log(`📝 使用原始标题: ${product.title.substring(0, 50)}...`);
    return product.title;
  }
  const urlTitle = getTitleFromUrl(product.url || product.sourceUrl);
  if (urlTitle) return urlTitle;
  if (product.img) {
    try {
      const imgUrl = product.img;
      if (imgUrl.includes('kwcdn.com') && imgUrl.includes('goods')) {
        const urlParts = imgUrl.split('/');
        const fileName = urlParts[urlParts.length - 1];
        if (fileName && fileName.includes('-') && fileName.length > 10) {
          const titlePart = fileName.split('-')[0];
          if (titlePart && titlePart.length > 5) {
            console.log(`📝 从图片URL提取标题: ${titlePart}`);
            return titlePart.charAt(0).toUpperCase() + titlePart.slice(1);
          }
        }
      }
    } catch (error) {
      console.warn('从图片URL提取标题失败:', error);
    }
  }
  if (product.timestamp || product.addedAt) {
    const timestamp = product.timestamp || product.addedAt;
    const date = new Date(timestamp);
    const dateStr = date.toLocaleDateString('zh-CN');
    return `商品 ${dateStr}`;
  }
  return product.title || '未知商品';
}

document.getElementById('export-csv').onclick = function() {
  const data = (typeof filteredProducts !== 'undefined' && filteredProducts.length >= 0) ? filteredProducts : allProducts;
  const header = ['商品ID', '图片链接', '商品标题'];
  const customPrefix = document.getElementById('custom-prefix').value.trim();
  if (customPrefix) {
    localStorage.setItem('lastCustomPrefix', customPrefix);
  }
  const now = new Date();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const datePrefix = `kj${month}${day}`;
  const rows = data.map((p, index) => {
    const sequenceNumber = String(index + 1).padStart(6, '0');
    const newId = `${datePrefix}${sequenceNumber}`;
    let title = getSmartTitle(p);
    // 应用过滤词
    title = applyFilterWords(title);
    // 将图片URL中的avif格式改为webp格式
    let imgUrl = p.img || '';
    if (imgUrl.includes('format/avif')) {
      imgUrl = imgUrl.replace('format/avif', 'format/webp');
    }
    return [newId, imgUrl, title];
  });
  let csv = header.join(',') + '\n' + rows.map(r => r.map(x => '"' + (x || '').replace(/"/g, '""') + '"').join(',')).join('\n');
  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  let baseFileName = customPrefix ? `${customPrefix}-${month}${day}-导出条数${data.length}` : `筛选成功-${month}${day}-导出条数${data.length}`;
  const dateKey = `export_count_${month}${day}`;
  let exportCount = parseInt(localStorage.getItem(dateKey) || '0');
  exportCount++;
  localStorage.setItem(dateKey, exportCount.toString());
  const exportedIds = JSON.parse(localStorage.getItem('exportedProductIds') || '[]');
  const newExportedIds = data.map(p => p.id);
  const updatedExportedIds = [...new Set([...exportedIds, ...newExportedIds])];
  localStorage.setItem('exportedProductIds', JSON.stringify(updatedExportedIds));
  let fileName = exportCount === 1 ? `${baseFileName}.csv` : `${baseFileName}-${exportCount}.csv`;
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  a.click();
  URL.revokeObjectURL(url);
};

document.getElementById('export-txt').onclick = function() {
  const data = (typeof filteredProducts !== 'undefined' && filteredProducts.length >= 0) ? filteredProducts : allProducts;
  const customPrefix = document.getElementById('custom-prefix').value.trim();
  if (customPrefix) {
    localStorage.setItem('lastCustomPrefix', customPrefix);
  }
  const now = new Date();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const datePrefix = `kj${month}${day}`;
  
  const rows = data.map((p, index) => {
    // 优先检查是否有原始行数据
    if (p.originalLine) {
      console.log('使用原始行数据(应用过滤词前):', p.originalLine);
      // 尝试解析原始行数据并应用过滤词
      const parts = p.originalLine.split('-----');
      if (parts.length >= 3) {
        // 第三部分是标题，应用过滤词
        parts[2] = applyFilterWords(parts[2]);
        const filteredLine = parts.join('-----');
        console.log('使用原始行数据(应用过滤词后):', filteredLine);
        return filteredLine;
      }
      return p.originalLine;
    }
    
    // 检查是否有原始ID
    let productId = p.originalId || '';
    
    // 如果没有原始ID，生成新ID
    if (!productId) {
      const sequenceNumber = String(index + 1).padStart(6, '0');
      productId = `${datePrefix}${sequenceNumber}`;
    }
    
    let title = getSmartTitle(p);
    // 应用过滤词
    title = applyFilterWords(title);
    let imgLink = p.img || '';
      
      // 将图片URL中的avif格式改为webp格式
      if (imgLink.includes('format/avif')) {
        imgLink = imgLink.replace('format/avif', 'format/webp');
      }
    
    const match = imgLink.match(/\.(jpeg|jpg|png|gif|webp)/i);
    if (match) {
      imgLink = imgLink.substring(0, match.index + match[0].length);
    }
    
    return [productId, imgLink, title].join('-----');
  });
  
  let txt = rows.join('\n');
  const blob = new Blob([txt], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  let baseFileName = customPrefix ? `${customPrefix}-${month}${day}-导出条数${data.length}` : `筛选成功-${month}${day}-导出条数${data.length}`;
  const dateKey = `export_count_${month}${day}`;
  let exportCount = parseInt(localStorage.getItem(dateKey) || '0');
  exportCount++;
  localStorage.setItem(dateKey, exportCount.toString());
  const exportedIds = JSON.parse(localStorage.getItem('exportedProductIds') || '[]');
  const newExportedIds = data.map(p => p.id);
  const updatedExportedIds = [...new Set([...exportedIds, ...newExportedIds])];
  localStorage.setItem('exportedProductIds', JSON.stringify(updatedExportedIds));
  let fileName = exportCount === 1 ? `${baseFileName}.txt` : `${baseFileName}-${exportCount}.txt`;
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  a.click();
  URL.revokeObjectURL(url);
};

// 导出选中项功能
if (document.getElementById('export-selected')) {
  document.getElementById('export-selected').onclick = function() {
    if (!globalSelectedIds.size) {
      alert('请先选择要导出的图片！');
      return;
    }
    
    const data = (typeof filteredProducts !== 'undefined' && filteredProducts.length >= 0) ? filteredProducts : allProducts;
    const selectedProducts = data.filter(p => globalSelectedIds.has(p.id));
    
    if (selectedProducts.length === 0) {
      alert('没有找到选中的图片数据！');
      return;
    }
    
    // 提示用户选择导出格式
    const exportFormat = prompt(`已选中 ${globalSelectedIds.size} 张图片，选择导出格式：\n1. CSV\n2. TXT`, '1');
    
    if (!exportFormat) return; // 用户取消
    
    const customPrefix = document.getElementById('custom-prefix').value.trim();
    if (customPrefix) {
      localStorage.setItem('lastCustomPrefix', customPrefix);
    }
    
    const now = new Date();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const datePrefix = `kj${month}${day}`;
    
    if (exportFormat === '1') {
      // 导出为CSV格式
      const header = ['商品ID', '图片链接', '商品标题'];
      const rows = selectedProducts.map((p, index) => {
        const sequenceNumber = String(index + 1).padStart(6, '0');
        const newId = `${datePrefix}${sequenceNumber}`;
        let title = getSmartTitle(p);
        // 将图片URL中的avif格式改为webp格式
        let imgUrl = p.img || '';
        if (imgUrl.includes('format/avif')) {
          imgUrl = imgUrl.replace('format/avif', 'format/webp');
        }
        return [newId, imgUrl, title];
      });
      let csv = header.join(',') + '\n' + rows.map(r => r.map(x => '"' + (x || '').replace(/"/g, '""') + '"').join(',')).join('\n');
      const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      let baseFileName = customPrefix ? `${customPrefix}-${month}${day}-选中导出${selectedProducts.length}条` : `选中导出-${month}${day}-${selectedProducts.length}条`;
      const dateKey = `export_count_${month}${day}`;
      let exportCount = parseInt(localStorage.getItem(dateKey) || '0');
      exportCount++;
      localStorage.setItem(dateKey, exportCount.toString());
      const exportedIds = JSON.parse(localStorage.getItem('exportedProductIds') || '[]');
      const newExportedIds = selectedProducts.map(p => p.id);
      const updatedExportedIds = [...new Set([...exportedIds, ...newExportedIds])];
      localStorage.setItem('exportedProductIds', JSON.stringify(updatedExportedIds));
      let fileName = exportCount === 1 ? `${baseFileName}.csv` : `${baseFileName}-${exportCount}.csv`;
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      a.click();
      URL.revokeObjectURL(url);
      alert(`已成功导出选中的 ${selectedProducts.length} 张图片为CSV格式！`);
    } else if (exportFormat === '2') {
      // 导出为TXT格式
      const rows = selectedProducts.map((p, index) => {
        // 优先检查是否有原始行数据
        if (p.originalLine) {
          console.log('使用原始行数据(应用过滤词前):', p.originalLine);
          // 尝试解析原始行数据并应用过滤词
          const parts = p.originalLine.split('-----');
          if (parts.length >= 3) {
            // 第三部分是标题，应用过滤词
            parts[2] = applyFilterWords(parts[2]);
            const filteredLine = parts.join('-----');
            console.log('使用原始行数据(应用过滤词后):', filteredLine);
            return filteredLine;
          }
          return p.originalLine;
        }
        
        // 检查是否有原始ID
        let productId = p.originalId || '';
        
        // 如果没有原始ID，生成新ID
        if (!productId) {
          const sequenceNumber = String(index + 1).padStart(6, '0');
          productId = `${datePrefix}${sequenceNumber}`;
        }
        
        let title = getSmartTitle(p);
        // 应用过滤词
        title = applyFilterWords(title);
        let imgLink = p.img || '';
        
        // 将图片URL中的avif格式改为webp格式
        if (imgLink.includes('format/avif')) {
          imgLink = imgLink.replace('format/avif', 'format/webp');
        }
        
        const match = imgLink.match(/\.(jpeg|jpg|png|gif|webp)/i);
        if (match) {
          imgLink = imgLink.substring(0, match.index + match[0].length);
        }
        
        return [productId, imgLink, title].join('-----');
      });
      
      let txt = rows.join('\n');
      const blob = new Blob([txt], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      let baseFileName = customPrefix ? `${customPrefix}-${month}${day}-选中导出${selectedProducts.length}条` : `选中导出-${month}${day}-${selectedProducts.length}条`;
      const dateKey = `export_count_${month}${day}`;
      let exportCount = parseInt(localStorage.getItem(dateKey) || '0');
      exportCount++;
      localStorage.setItem(dateKey, exportCount.toString());
      const exportedIds = JSON.parse(localStorage.getItem('exportedProductIds') || '[]');
      const newExportedIds = selectedProducts.map(p => p.id);
      const updatedExportedIds = [...new Set([...exportedIds, ...newExportedIds])];
      localStorage.setItem('exportedProductIds', JSON.stringify(updatedExportedIds));
      let fileName = exportCount === 1 ? `${baseFileName}.txt` : `${baseFileName}-${exportCount}.txt`;
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      a.click();
      URL.revokeObjectURL(url);
      alert(`已成功导出选中的 ${selectedProducts.length} 张图片为TXT格式！`);
    } else {
      alert('请输入有效的导出格式选项（1或2）！');
    }
  };
}

  updateSelCount();
}

// 时间筛选（今天、昨天、前天、本周、本月）
// filteredProducts 已在文件开头声明
// 保存上一次应用的时间筛选条件
let lastAppliedDateFilter = '';

// 统一的筛选函数
function applyFilters() {
  const dateValue = document.getElementById('date-quick').value;
  const unexportedOnly = document.getElementById('unexported-only').checked;
  const importFileFilter = document.getElementById('import-file-filter').value;
  
  // 重要：当时间筛选条件改变时，重置违禁词筛选状态
  // 这样用户切换时间后需要重新点击筛选违禁词按钮
  if (dateValue !== lastAppliedDateFilter) {
    isProhibitedFilterActive = false;
    console.log('时间筛选条件改变，已重置违禁词筛选状态');
  }
  // 保存当前时间筛选条件
  lastAppliedDateFilter = dateValue;
  
  let start = '', end = '';
  const today = new Date();
  
  // 首先按时间筛选
  if (dateValue === 'today') {
    start = end = today.toISOString().slice(0,10);
  } else if (dateValue === 'yesterday') {
    const y = new Date(today.getTime()-86400000);
    start = end = y.toISOString().slice(0,10);
  } else if (dateValue === 'week') {
    // 本周第一天
    const weekStart = new Date(today);
    weekStart.setDate(today.getDate() - today.getDay() + (today.getDay() === 0 ? -6 : 1));
    start = weekStart.toISOString().slice(0,10);
    // 本周最后一天
    const weekEnd = new Date(weekStart);
    weekEnd.setDate(weekStart.getDate() + 6);
    end = weekEnd.toISOString().slice(0,10);
  } else if (dateValue === 'month') {
    // 本月第一天
    const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
    start = monthStart.toISOString().slice(0,10);
    // 本月最后一天
    const monthEnd = new Date(today.getFullYear(), today.getMonth() + 1, 0);
    end = monthEnd.toISOString().slice(0,10);
  }
  
  // 按时间筛选
  if (dateValue === 'all' || dateValue === '') {
    filteredProducts = allProducts;
  } else if (start && end) {
    filteredProducts = allProducts.filter(p => {
      if (!p.time) return false;
      const t = p.time.slice(0,10);
      return t >= start && t <= end;
    });
  } else {
    filteredProducts = allProducts;
  }
  
  // 按数据来源筛选
  if (importFileFilter === 'local') {
    // 本机采集：category不是'导入数据'的数据
    filteredProducts = filteredProducts.filter(p => p.category !== '导入数据');
  } else if (importFileFilter !== 'all' && importFileFilter !== 'local') {
    // 具体的导入文件：先筛选导入数据，再按文件名筛选
    filteredProducts = filteredProducts.filter(p => p.category === '导入数据' && p.importSource === importFileFilter);
  }
  
  // 如果勾选了"仅显示未导出"，在时间筛选基础上进一步筛选
  if (unexportedOnly) {
    const exportedIds = JSON.parse(localStorage.getItem('exportedProductIds') || '[]');
    filteredProducts = filteredProducts.filter(p => !exportedIds.includes(p.id));
  }
  
  // 筛选时清空全局选中状态
  globalSelectedIds.clear();
  
  currentPage = 1;
  // 更新按钮状态，确保筛选按钮状态正确
  updateButtonStates();
  // 使用updateGalleryDisplay代替直接调用renderGallery
  updateGalleryDisplay();
  
  // 当面板展开时，自动检测过滤词
  const panel = document.getElementById('word-filter-panel');
  if (panel && panel.classList.contains('show')) {
    detectFilterWords();
  }
  
  // 过滤词检测现在只在面板展开时进行，不再在筛选条件改变时自动检测
}

// 时间筛选变化事件
document.getElementById('date-quick').onchange = applyFilters;

// 未导出筛选变化事件
document.getElementById('unexported-only').onchange = applyFilters;

// 导入文件名筛选变化事件
document.getElementById('import-file-filter').onchange = applyFilters;

// 为筛选下拉框禁用方向键默认行为
document.getElementById('date-quick').addEventListener('keydown', function(e) {
  if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
    e.preventDefault();
  }
});

document.getElementById('import-file-filter').addEventListener('keydown', function(e) {
  if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
    e.preventDefault();
  }
});

// 使用优化的键盘事件监听设置
setupKeyboardListeners();

initDB().then(() => {
  // 检查回收站数据并高亮提醒
  checkRecycleBinAndHighlight();
  
  // 检查插件激活状态并显示剩余使用时间
  checkPluginActivationAndShowRemainingTime();
  
  // 初始化词库管理器
  initWordFilterManager();
  
  // 恢复上次保存的自定义前缀
  const lastCustomPrefix = localStorage.getItem('lastCustomPrefix');
  if (lastCustomPrefix) {
    document.getElementById('custom-prefix').value = lastCustomPrefix;
  }
  
  // 绑定回收站按钮事件
  document.getElementById('recycle-bin').onclick = function() {
    showRecycleBin();
  };
  
  // 定期检查回收站状态（每30秒检查一次）
  setInterval(() => {
    checkRecycleBinAndHighlight();
  }, 30 * 1000);
  
  getAllProducts().then(products => {
    allProducts = products;
    // 填充导入文件名筛选选项
    populateImportFileFilter();
    // 默认显示今天的图片
    const dateQuickElement = document.getElementById('date-quick');
    if (dateQuickElement) {
      try {
        dateQuickElement.dispatchEvent(new Event('change'));
      } catch (e) {
        console.error('触发日期筛选事件失败:', e);
      }
    } else {
      console.warn('date-quick 元素不存在');
    }
  }).catch(e => {
    console.error('获取产品数据失败:', e);
  });
}).catch(e => {
  console.error('数据库初始化失败:', e);
});

// 填充导入文件名筛选选项
function populateImportFileFilter() {
  const importFileFilter = document.getElementById('import-file-filter');
  if (!importFileFilter) return;
  
  // 保存当前选中的值
  const currentValue = importFileFilter.value;
  
  // 获取所有不同的导入文件名（只从现有数据中获取）
  const importSources = [...new Set(allProducts
    .filter(p => p.category === '导入数据' && p.importSource)
    .map(p => p.importSource))]
    .sort(); // 按字母顺序排序
  
  // 清空现有选项并添加基础选项
  importFileFilter.innerHTML = `
    <option value="all" style="background: #222;">所有数据</option>
    <option value="local" style="background: #222;">本机采集</option>
  `;
  
  // 添加每个导入文件名作为选项
  importSources.forEach(source => {
    const option = document.createElement('option');
    option.value = source;
    option.textContent = source;
    option.style.background = '#222';
    importFileFilter.appendChild(option);
  });
  
  // 恢复之前的选择（如果该选项仍然存在）
  const validOptions = ['all', 'local', ...importSources];
  if (validOptions.includes(currentValue)) {
    importFileFilter.value = currentValue;
  } else {
    // 如果之前选择的文件已被删除，重置为"所有数据"
    importFileFilter.value = 'all';
  }
  
  console.log(`📋 更新筛选器: 本机采集 + ${importSources.length} 个导入文件`);
}

// 检查回收站数据并高亮提醒用户及时删除
function checkRecycleBinAndHighlight() {
  getRecycleBinItems().then(items => {
    const recycleBinBtn = document.getElementById('recycle-bin');
    if (!recycleBinBtn) return;
    
    if (items.length > 0) {
      // 有数据时高亮提醒
      recycleBinBtn.style.background = '#dc3545'; // 红色高亮
      recycleBinBtn.style.boxShadow = '0 0 10px rgba(220, 53, 69, 0.6)';
      recycleBinBtn.style.animation = 'pulse 2s infinite';
      recycleBinBtn.innerHTML = `🗑️ 回收站 (${items.length})`;
      recycleBinBtn.title = `回收站有 ${items.length} 个项目需要处理，点击查看并及时删除`;
      
      // 添加脉冲动画样式
      if (!document.getElementById('recycle-pulse-style')) {
        const style = document.createElement('style');
        style.id = 'recycle-pulse-style';
        style.textContent = `
          @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
          }
        `;
        document.head.appendChild(style);
      }
    } else {
      // 无数据时恢复正常样式
      recycleBinBtn.style.background = '#6c757d'; // 灰色
      recycleBinBtn.style.boxShadow = 'none';
      recycleBinBtn.style.animation = 'none';
      recycleBinBtn.innerHTML = '🗑️ 回收站';
      recycleBinBtn.title = '回收站为空';
    }
  }).catch(e => {
    console.error('检查回收站状态失败:', e);
  });
}

// ==================== 插件激活状态检查和剩余时间显示 ====================

// 检查插件激活状态并显示剩余使用时间
function checkPluginActivationAndShowRemainingTime() {
  try {
    chrome.storage.local.get(['pluginActivated', 'activationDate', 'activatedMachineCode', 'expireDate'], (result) => {
      let isActivated = result.pluginActivated || false;
      let expireDate = result.expireDate || null;
      
      // 检查是否已过期
      if (isActivated && expireDate) {
        const expiry = new Date(expireDate);
        const now = new Date();
        if (now > expiry) {
          // 已过期，设置为未激活状态
          isActivated = false;
          expireDate = null;
          // 更新存储中的激活状态
          chrome.storage.local.set({ pluginActivated: false }, () => {
            console.log('插件已过期，自动设置为未激活状态');
          });
        }
      }
      
      if (isActivated) {
        // 插件已激活，计算剩余使用时间
        let remainingDays = 0;
        
        // 如果有到期时间，使用到期时间计算
        if (result.expireDate) {
          const expireDate = new Date(result.expireDate);
          const now = new Date();
          const timeDiff = expireDate.getTime() - now.getTime();
          remainingDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
        } else {
          // 如果没有到期时间，使用默认的30天计算（向后兼容）
          const activationDate = result.activationDate ? new Date(result.activationDate) : new Date();
          remainingDays = calculateRemainingDays(activationDate);
        }
        
        // 显示剩余使用时间
        const remainingTimeElement = document.getElementById('remaining-time');
        if (remainingTimeElement) {
          if (remainingDays > 0) {
            remainingTimeElement.textContent = `剩余使用时间: ${remainingDays} 天`;
          } else {
            remainingTimeElement.textContent = '剩余使用时间: 已过期';
          }
        }
        
        // 保存激活信息供后续使用
        pluginActivationInfo = {
          activated: true,
          activationDate: result.activationDate ? new Date(result.activationDate) : new Date(),
          expireDate: result.expireDate ? new Date(result.expireDate) : null,
          remainingDays: remainingDays
        };
      } else {
        // 插件未激活或已过期
        const remainingTimeElement = document.getElementById('remaining-time');
        if (remainingTimeElement) {
          remainingTimeElement.textContent = '插件未激活';
        }
        
        pluginActivationInfo = {
          activated: false
        };
        
        // 如果已过期，显示提示信息
        if (result.expireDate && new Date(result.expireDate) < new Date()) {
          alert('插件已过期，请重新激活以继续使用！');
        }
      }
    });
  } catch (error) {
    console.error('检查插件激活状态失败:', error);
  }
}

// 计算剩余天数（假设激活后有30天使用期）
function calculateRemainingDays(activationDate) {
  try {
    const now = new Date();
    const expiryDate = new Date(activationDate);
    // 假设插件激活后有30天使用期
    expiryDate.setDate(expiryDate.getDate() + 30);
    
    const timeDiff = expiryDate.getTime() - now.getTime();
    const daysDiff = Math.ceil(timeDiff / (1000 * 3600 * 24));
    
    return daysDiff > 0 ? daysDiff : 0;
  } catch (error) {
    console.error('计算剩余天数失败:', error);
    return 0;
  }
}

// ==================== 导入导出功能 ====================

// 导出画廊数据
document.getElementById('export-data').onclick = function() {
  try {
    const currentFilter = document.getElementById('date-quick').value;
    const data = (typeof filteredProducts !== 'undefined' && filteredProducts.length >= 0) ? filteredProducts : allProducts;
    
    if (data.length === 0) {
      alert('当前没有可导出的数据！');
      return;
    }
    
    // 获取自定义前缀
    const customPrefix = document.getElementById('custom-prefix').value.trim();
    
    // 保存自定义前缀到localStorage
    if (customPrefix) {
      localStorage.setItem('lastCustomPrefix', customPrefix);
    }
    
    exportGalleryData(data, currentFilter, '全部', customPrefix);
    alert(`✅ 成功导出 ${data.length} 条${{
      'today': '今天',
      'yesterday': '昨天', 
      'week': '本周',
      'month': '本月',
      'all': '全部'
    }[currentFilter] || '筛选'}的数据！`);
    
  } catch (error) {
    console.error('导出数据失败:', error);
    alert('导出数据失败，请重试！');
  }
};

// 分割导出功能
document.getElementById('split-export').onclick = async function() {
  try {
    const currentFilter = document.getElementById('date-quick').value;
    const data = (typeof filteredProducts !== 'undefined' && filteredProducts.length >= 0) ? filteredProducts : allProducts;
    
    if (data.length === 0) {
      alert('当前没有可导出的数据！');
      return;
    }
    
    // 获取用户输入的导出数量
    const exportCountInput = prompt(
      `📋 提取式导出\n\n` +
      `当前数据总数: ${data.length} 个商品\n\n` +
      `请输入要导出的商品数量:`,
      '1000'
    );
    
    if (!exportCountInput) {
      return; // 用户取消
    }
    
    const exportCount = parseInt(exportCountInput.trim());
    
    // 验证输入
    if (isNaN(exportCount) || exportCount <= 0) {
      alert('请输入有效的数字（大于0）！');
      return;
    }
    
    if (exportCount >= data.length) {
      alert(`输入的数量(${exportCount})不能大于或等于总数量(${data.length})\n请使用普通导出功能！`);
      return;
    }
    
    const remainingCount = data.length - exportCount;
    
    // 二次确认
    const confirmed = confirm(
      `📋 提取导出确认\n\n` +
      `将导出前 ${exportCount} 个商品\n` +
      `剩余 ${remainingCount} 个商品保留在画廊\n\n` +
      `确定要继续吗？`
    );
    
    if (!confirmed) {
      return;
    }
    
    // 获取自定义前缀
    const customPrefix = document.getElementById('custom-prefix').value.trim();
    if (customPrefix) {
      localStorage.setItem('customPrefix', customPrefix);
    }
    
    // 开始提取导出
    console.log(`📋 开始提取导出: ${exportCount} 个商品`);
    
    await exportSplitData(data, exportCount, currentFilter, customPrefix);
    
    console.log(`✅ 提取导出完成: ${exportCount} 个商品`);
    
  } catch (error) {
    console.error('提取导出失败:', error);
    alert('提取导出失败，请重试！');
  }
};

// 提取式分割导出功能
async function exportSplitData(data, exportCount, currentFilter, customPrefix) {
  try {
    // 提取指定数量的数据
    const dataToExport = data.slice(0, exportCount);
    const dataToKeep = data.slice(exportCount);
    
    // 导出数据
    const filterText = {
      'today': '今天',
      'yesterday': '昨天', 
      'week': '本周',
      'month': '本月',
      'all': '全部'
    }[currentFilter] || '筛选';
    
    const exportInfo = `提取${exportCount}个商品`;
    exportGalleryData(dataToExport, currentFilter, exportInfo, customPrefix);
    
    // 从数据库中删除已导出的数据（移到回收站）
    await moveToRecycleBin(dataToExport);
    
    // 更新全局数据
    allProducts = dataToKeep;
    
    // 重新应用筛选
    document.getElementById('date-quick').dispatchEvent(new Event('change'));
    
    // 显示成功信息
    const resultMessage = 
      `✅ 提取导出完成！\n\n` +
      `• 已导出: ${exportCount} 个商品\n` +
      `• 剩余: ${dataToKeep.length} 个商品保留在画廊\n\n` +
      `📝 导出的商品已移入回收站，可以随时恢复`;
    
    alert(resultMessage);
    
  } catch (error) {
    console.error('提取导出失败:', error);
    throw error;
  }
}



// 导出数据的通用函数
function exportGalleryData(data, currentFilter, batchName, customPrefix) {
  // 准备导出数据结构
  const exportData = {
    version: '1.0',
    exportTime: new Date().toISOString(),
    exportFilter: currentFilter,
    batchName: batchName,
    totalCount: data.length,
    data: data.map(item => ({
      id: item.id,
      title: applyFilterWords(item.title),
      img: item.img,
      imgAlt: item.imgAlt || '',
      url: item.url,
      time: item.time,
      timestamp: item.timestamp,
      addedAt: item.addedAt,
      sourceUrl: item.sourceUrl,
      type: item.type || 'collected',
      category: item.category || '采集记录',
      status: item.status || 'collected'
    }))
  };
  
  // 生成文件名（包含数据数量）
  const now = new Date();
  const dateStr = now.toISOString().slice(0, 19).replace(/[:-]/g, '').replace('T', '_');
  const filterText = {
    'today': '今天',
    'yesterday': '昨天', 
    'week': '本周',
    'month': '本月',
    'all': '全部'
  }[currentFilter] || '筛选';
  
  // 使用自定义前缀或默认前缀
  let filePrefix;
  if (customPrefix) {
    filePrefix = customPrefix;
  } else {
    filePrefix = 'TEMU画廊';
  }
  
  // 在文件名中加入数据数量
  const fileName = `${filePrefix}_${filterText}_${batchName}_${data.length}条_${dateStr}.json`;
  
  // 创建并下载文件
  const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  
  console.log(`✅ 已导出 ${data.length} 条数据到文件: ${fileName}`);
}

// 导入画廊数据
document.getElementById('import-data').onclick = function() {
  const fileInput = document.getElementById('import-file');
  fileInput.click();
};

// TXT文件导入功能
document.getElementById('import-txt').onclick = function() {
  const fileInput = document.getElementById('import-txt-file');
  fileInput.click();
};

// 处理TXT文件导入
document.getElementById('import-txt-file').onchange = function(event) {
  const file = event.target.files[0];
  if (!file) return;
  
  // 保存文件名用于后续标记
  const importFileName = file.name;
  
  // 检查文件扩展名，不区分大小写
  if (!file.name.toLowerCase().endsWith('.txt')) {
    alert('请选择有效的 TXT 数据文件！\n\n提示：文件每行可包含：\n- 仅图片链接\n- 或 ID-----图片链接-----标题 格式');
    return;
  }
  
  const reader = new FileReader();
  reader.onload = async function(e) {
    try {
      const txtContent = e.target.result;
      const lines = txtContent.split('\n').filter(line => line.trim().length > 0);
      
      if (lines.length === 0) {
        alert('文件中没有可导入的数据！');
        return;
      }
      
      let importData = [];
      let parseErrorCount = 0;
      
      // 解析每一行数据
      console.log('开始解析TXT文件内容，共', lines.length, '行数据');
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i].trim();
        console.log('解析行', i+1, ':', line);
        
        // 尝试使用-----分割
        const parts = line.split('-----');
        console.log('分割后部分数:', parts.length, '，内容:', parts);
        
        let imgLink = '';
        let title = '导入的商品';
        let originalId = '';
        
        if (parts.length >= 2) {
          // 有-----分隔符的情况
          originalId = parts[0].trim(); // 保存原始ID
          imgLink = parts[1];
          title = parts[2] || '导入的商品';
          console.log('成功解析行(格式1)', i+1, ':', {originalId, imgLink, title});
        } else if (line.match(/https?:\/\/.+\.(jpg|jpeg|png|gif|bmp|webp|avif)/i)) {
          // 仅图片链接的情况
          imgLink = line;
          console.log('成功解析行(格式2)', i+1, ':', {imgLink, title});
        } else {
          parseErrorCount++;
          console.error('解析行失败:', line);
          continue;
        }
        
        // 生成唯一ID，但同时保存原始ID
        const newId = `txt_import_${Date.now()}_${i}_${Math.random().toString(36).substr(2, 6)}`;
        
        importData.push({
          id: newId, // 内部唯一ID用于系统识别
          originalId: originalId, // 保存用户的原始ID
          title: title,
          img: imgLink,
          url: '',
          time: new Date().toISOString(),
          timestamp: Date.now(),
          addedAt: Date.now(),
          sourceUrl: '',
          type: 'collected',
          category: 'TXT导入数据',
          importSource: importFileName,
          // 保存原始行数据，确保导出时可以恢复全部内容
          originalLine: line
        });
      }
      
      if (importData.length === 0) {
        alert(`解析失败：未找到有效的数据行\n共检测到 ${parseErrorCount} 行格式错误\n\n提示：有效的TXT文件每行可包含：\n- 仅图片链接（支持jpg、jpeg、png、gif、bmp、webp、avif格式）\n- 或 ID-----图片链接-----标题 格式`);
        return;
      }
      
      // 询问导入方式
      const importMode = confirm(
        `检测到 ${importData.length} 条有效数据\n` +
        `可能存在 ${parseErrorCount} 行格式错误\n\n` +
        `选择导入方式:\n` +
        `确定 = 追加导入（保留现有数据）\n` +
        `取消 = 替换导入（清空现有数据后导入）`
      );
      
      let successCount = 0;
      let duplicateCount = 0;
      let errorCount = 0;
      
      if (importMode) {
        // 追加模式：检查重复
        console.log('📥 开始追加导入TXT数据...');
        
        const existingIds = new Set(allProducts.map(p => p.id));
        
        for (const item of importData) {
          try {
            // 检查是否重复（使用生成的唯一ID避免冲突）
            const newId = `txt_import_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
            item.id = newId;
            
            allProducts.push(item);
            successCount++;
            
          } catch (error) {
            console.error('导入单条数据失败:', error, item);
            errorCount++;
          }
        }
        
      } else {
        // 替换模式：清空后导入
        if (!confirm('⚠️ 替换导入将清空所有现有数据，确定要继续吗？\n\n此操作不可撤销！')) {
          return;
        }
        
        console.log('🔄 开始替换导入TXT数据...');
        
        // 先将现有数据移到回收站
        if (allProducts.length > 0) {
          await moveToRecycleBin(allProducts);
          console.log(`📦 已将 ${allProducts.length} 条现有数据移到回收站`);
        }
        
        // 清空现有数据
        allProducts = [];
        
        // 导入新数据
        for (const item of importData) {
          try {
            const newId = `txt_import_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
            item.id = newId;
            
            allProducts.push(item);
            successCount++;
            
          } catch (error) {
            console.error('导入单条数据失败:', error, item);
            errorCount++;
          }
        }
      }
      
      // 保存到数据库
      try {
        await saveAllProducts(allProducts);
        
        // 更新导入文件筛选选项
        populateImportFileFilter();
        
        // 刷新画廊显示
        if (typeof applyFilters === 'function') {
          applyFilters();
        } else {
          renderGalleryPage();
        }
        
        // 清空文件输入
        event.target.value = '';
        
        // 显示导入结果
        let resultMessage = `✅ TXT数据导入完成！\n\n`;
        resultMessage += `成功导入: ${successCount} 条\n`;
        if (duplicateCount > 0) {
          resultMessage += `跳过重复: ${duplicateCount} 条\n`;
        }
        if (errorCount > 0) {
          resultMessage += `导入失败: ${errorCount} 条\n`;
        }
        if (parseErrorCount > 0) {
          resultMessage += `解析错误: ${parseErrorCount} 行\n`;
        }
        resultMessage += `\n当前总数据: ${allProducts.length} 条`;
        
        alert(resultMessage);
        
        console.log(`📥 TXT导入完成: 成功 ${successCount}, 失败 ${errorCount}, 解析错误 ${parseErrorCount}`);
        
      } catch (error) {
        console.error('保存导入数据失败:', error);
        alert('保存导入数据失败，请重试！');
      }
      
    } catch (error) {
        console.error('解析导入文件失败:', error);
        alert('文件格式错误或损坏，请检查文件是否为有效的TXT数据文件！\n\n提示：有效的TXT文件每行可包含：\n- 仅图片链接（支持jpg、jpeg、png、gif、bmp、webp、avif格式）\n- 或 ID-----图片链接-----标题 格式');
      }
  };
  
  reader.onerror = function() {
    alert('读取文件失败，请重试！');
  };
  
  reader.readAsText(file, 'utf-8');
};

// 处理文件导入
document.getElementById('import-file').onchange = function(event) {
  const file = event.target.files[0];
  if (!file) return;
  
  // 保存文件名用于后续标记
  const importFileName = file.name;
  
  if (!file.name.endsWith('.json')) {
    alert('请选择有效的 JSON 数据文件！');
    return;
  }
  
  const reader = new FileReader();
  reader.onload = async function(e) {
    try {
      const jsonData = JSON.parse(e.target.result);
      
      // 验证数据格式
      if (!jsonData.version || !jsonData.data || !Array.isArray(jsonData.data)) {
        throw new Error('文件格式不正确，请选择有效的画廊数据文件！');
      }
      
      const importData = jsonData.data;
      if (importData.length === 0) {
        alert('文件中没有可导入的数据！');
        return;
      }
      
      // 询问导入方式
      const importMode = confirm(
        `检测到 ${importData.length} 条数据\n` +
        `导出时间: ${new Date(jsonData.exportTime).toLocaleString('zh-CN')}\n\n` +
        `选择导入方式:\n` +
        `确定 = 追加导入（保留现有数据）\n` +
        `取消 = 替换导入（清空现有数据后导入）`
      );
      
      let successCount = 0;
      let duplicateCount = 0;
      let errorCount = 0;
      
      if (importMode) {
        // 追加模式：检查重复
        console.log('📥 开始追加导入数据...');
        
        const existingIds = new Set(allProducts.map(p => p.id));
        
        for (const item of importData) {
          try {
            // 检查是否重复
            if (existingIds.has(item.id)) {
              duplicateCount++;
              console.log(`⚠️ 跳过重复数据: ${item.id}`);
              continue;
            }
            
            // 确保数据完整性
            const newItem = {
              id: item.id || `import_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
              title: item.title || '导入的商品',
              img: item.img,
              imgAlt: item.imgAlt || '',
              url: item.url || '',
              time: item.time || new Date().toISOString(),
              timestamp: item.timestamp || Date.now(),
              addedAt: item.addedAt || Date.now(),
              sourceUrl: item.sourceUrl || item.url || '',
              type: item.type || 'collected',
              category: '导入数据',
              importSource: importFileName, // 记录导入文件名
              status: item.status || 'collected'
            };
            
            allProducts.push(newItem);
            successCount++;
            
          } catch (error) {
            console.error('导入单条数据失败:', error, item);
            errorCount++;
          }
        }
        
      } else {
        // 替换模式：清空后导入
        if (!confirm('⚠️ 替换导入将清空所有现有数据，确定要继续吗？\n\n此操作不可撤销！')) {
          return;
        }
        
        console.log('🔄 开始替换导入数据...');
        
        // 先将现有数据移到回收站
        if (allProducts.length > 0) {
          await moveToRecycleBin(allProducts);
          console.log(`📦 已将 ${allProducts.length} 条现有数据移到回收站`);
        }
        
        // 清空现有数据
        allProducts = [];
        
        // 导入新数据
        for (const item of importData) {
          try {
            const newItem = {
              id: item.id || `import_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
              title: item.title || '导入的商品',
              img: item.img,
              imgAlt: item.imgAlt || '',
              url: item.url || '',
              time: item.time || new Date().toISOString(),
              timestamp: item.timestamp || Date.now(),
              addedAt: item.addedAt || Date.now(),
              sourceUrl: item.sourceUrl || item.url || '',
              type: item.type || 'collected',
              category: '导入数据',
              importSource: importFileName, // 记录导入文件名
              status: item.status || 'collected'
            };
            
            allProducts.push(newItem);
            successCount++;
            
          } catch (error) {
            console.error('导入单条数据失败:', error, item);
            errorCount++;
          }
        }
      }
      
      // 保存到数据库
      try {
        await saveAllProducts(allProducts);
        
        // 更新导入文件筛选选项
        populateImportFileFilter();
        
        // 刷新画廊显示
        if (typeof applyFilters === 'function') {
          applyFilters();
        } else {
          renderGalleryPage();
        }
        
        // 清空文件输入
        event.target.value = '';
        
        // 显示导入结果
        let resultMessage = `✅ 数据导入完成！\n\n`;
        resultMessage += `成功导入: ${successCount} 条\n`;
        if (duplicateCount > 0) {
          resultMessage += `跳过重复: ${duplicateCount} 条\n`;
        }
        if (errorCount > 0) {
          resultMessage += `导入失败: ${errorCount} 条\n`;
        }
        resultMessage += `\n当前总数据: ${allProducts.length} 条`;
        
        alert(resultMessage);
        
        console.log(`📥 导入完成: 成功 ${successCount}, 重复 ${duplicateCount}, 失败 ${errorCount}`);
        
      } catch (error) {
        console.error('保存导入数据失败:', error);
        alert('保存导入数据失败，请重试！');
      }
      
    } catch (error) {
      console.error('解析导入文件失败:', error);
      alert('文件格式错误或损坏，请检查文件是否为有效的画廊数据文件！');
    }
  };
  
  reader.onerror = function() {
    alert('读取文件失败，请重试！');
  };
  
  reader.readAsText(file, 'utf-8');
};
