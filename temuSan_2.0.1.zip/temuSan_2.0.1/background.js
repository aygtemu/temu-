// IndexedDB存储
let db;
let isActivated = false;
let isSingleVersion = true; // 默认为单采版
let expireDate = null; // 过期日期

// 保存激活状态
function saveActivationStatus(isActivated, machineCode, expireDate, version, activationCode) {
  const dataToSave = {
    pluginActivated: isActivated,
    activatedMachineCode: machineCode,
    activationDate: new Date().toISOString(),
    pluginVersion: version,
    usedActivationCode: activationCode // 保存使用的激活码
  };
  
  // 如果有到期时间，也保存到期时间
  if (expireDate) {
    dataToSave.expireDate = expireDate;
  }
  
  chrome.storage.local.set(dataToSave, () => {
    console.log('激活状态已保存:', { isActivated, machineCode, version, expireDate, activationCode });
    
    // 如果是激活操作，将激活码添加到已使用列表
    if (isActivated && activationCode) {
      addUsedActivationCode(activationCode);
    }
    
    if (!isActivated) {
      console.log('插件已过期，自动设置为未激活状态');
    }
  });
}

// 添加已使用的激活码到记录
function addUsedActivationCode(activationCode) {
  try {
    // 从localStorage读取已使用的激活码信息
    const usedCodes = localStorage.getItem('usedActivationCodes');
    const usedCodesArray = usedCodes ? JSON.parse(usedCodes) : [];
    
    // 如果激活码不在列表中，则添加
    if (!usedCodesArray.includes(activationCode)) {
      usedCodesArray.push(activationCode);
      // 保存更新后的列表
      localStorage.setItem('usedActivationCodes', JSON.stringify(usedCodesArray));
      console.log('激活码已添加到已使用列表');
    }
  } catch (error) {
    console.error('保存已使用激活码失败:', error);
  }
}

// 初始化激活状态检查
function checkActivationStatus() {
  return new Promise((resolve) => {
    try {
      chrome.storage.local.get(['pluginActivated', 'pluginVersion', 'expireDate', 'usedActivationCode', 'activatedMachineCode'], (result) => {
        try {
          // 确保result对象存在
          if (!result) {
            console.warn('存储结果为空，使用默认值');
            result = {};
          }
          
          // 初始化激活状态
          isActivated = !!result.pluginActivated; // 明确转换为布尔值
          
          // 根据存储的版本信息设置isSingleVersion
          if (result.pluginVersion) {
            isSingleVersion = (result.pluginVersion === 'single');
          } else {
            // 如果没有版本信息，默认为单采版
            isSingleVersion = true;
            console.log('未找到版本信息，默认为单采版');
          }
          
          // 检查是否已过期
          if (isActivated && result.expireDate) {
            try {
              expireDate = new Date(result.expireDate);
              // 检查日期是否有效
              if (isNaN(expireDate.getTime())) {
                console.error('存储的过期日期无效:', result.expireDate);
                expireDate = null;
                isActivated = false;
                saveActivationStatus(false, result.activatedMachineCode || '', null, result.pluginVersion || 'single', null);
              } else {
                const now = new Date();
                if (now > expireDate) {
                  // 已过期，设置为未激活状态
                  isActivated = false;
                  // 更新存储中的激活状态
                  saveActivationStatus(false, result.activatedMachineCode || '', null, result.pluginVersion || 'single', null);
                }
              }
            } catch (dateError) {
              console.error('解析过期日期失败:', dateError);
              expireDate = null;
              isActivated = false;
              saveActivationStatus(false, result.activatedMachineCode || '', null, result.pluginVersion || 'single', null);
            }
          } else {
            expireDate = null;
            // 如果有激活状态但没有过期日期，考虑它是有效的激活
            if (isActivated && !result.expireDate) {
              console.log('插件已激活但没有设置过期日期');
            }
          }
          
          // 额外的一致性检查
          if (isActivated && !result.usedActivationCode) {
            console.warn('插件标记为已激活但没有保存的激活码');
          }
          
          console.log('插件激活状态检查完成:', {
            isActivated: isActivated,
            isSingleVersion: isSingleVersion,
            expireDate: expireDate ? expireDate.toISOString() : null,
            hasActivationCode: !!result.usedActivationCode
          });
          
          resolve();
        } catch (innerError) {
          console.error('检查激活状态时发生内部错误:', innerError);
          // 出错时设置为安全的默认状态
          isActivated = false;
          isSingleVersion = true;
          expireDate = null;
          resolve();
        }
      });
    } catch (error) {
      console.error('获取激活状态时发生错误:', error);
      // 出错时设置为安全的默认状态
      isActivated = false;
      isSingleVersion = true;
      expireDate = null;
      resolve();
    }
  });
}

function initDB() {
	return new Promise((resolve, reject) => {
		const request = indexedDB.open('temu_collector', 2);
		request.onupgradeneeded = function(e) {
			try {
				db = e.target.result;
				if (!db.objectStoreNames.contains('products')) {
					db.createObjectStore('products', { keyPath: 'id' });
				}
				// 添加回收站存储
				if (!db.objectStoreNames.contains('recycle_bin')) {
					const recycleStore = db.createObjectStore('recycle_bin', { keyPath: 'id' });
					recycleStore.createIndex('deletedAt', 'deletedAt', { unique: false });
				}
			} catch (error) {
				console.error('数据库升级失败:', error);
				reject(error);
			}
		};
		request.onsuccess = function(e) {
			db = e.target.result;
			resolve();
		};
		request.onerror = (e) => {
			console.error('数据库打开失败:', e);
			reject(e);
		};
	});
}
initDB();

// base64转Blob
function base64ToBlob(base64) {
	const arr = base64.split(','), mime = arr[0].match(/:(.*?);/)[1], bstr = atob(arr[1]);
	let n = bstr.length, u8arr = new Uint8Array(n);
	while(n--) u8arr[n] = bstr.charCodeAt(n);
	return new Blob([u8arr], {type: mime});
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // 处理服务器健康检查请求
  if (msg.action === 'checkServerHealth') {
    checkServerHealth().then(result => {
      sendResponse(result);
    }).catch(error => {
      sendResponse({
        healthy: false,
        error: error.message || '检查失败',
        lastChecked: new Date().toISOString()
      });
    });
    return true; // 保持消息通道开放，等待异步响应
  }
  // 响应获取版本信息的请求
  if (msg.action === 'getPluginVersion') {
    sendResponse({ isSingleVersion: isSingleVersion });
    return true;
  }
  
  // 响应检查插件过期状态的请求
  if (msg.action === 'checkPluginExpiration') {
    // 检查是否已过期
    let isExpired = false;
    if (isActivated && expireDate) {
      const now = new Date();
      if (now > expireDate) {
        isExpired = true;
        // 已过期，设置为未激活状态
        isActivated = false;
        // 更新存储中的激活状态
        chrome.storage.local.set({ pluginActivated: false }, () => {
          console.log('插件已过期，自动设置为未激活状态');
        });
      }
    }
    sendResponse({ isExpired: isExpired });
    return true;
  }

  // 响应检查插件激活状态的请求
  if (msg.action === 'checkPluginActivation') {
    // 确保激活状态是最新的
    checkActivationStatus().then(() => {
      sendResponse({ isActivated: isActivated });
    });
    return true; // 异步响应
  }
  
  // 批量采集
  if (msg.action === 'batchCollectProducts') {
    // 检查插件激活状态和版本
    if (!isActivated) {
      sendResponse({ success: false, error: '插件未激活，请先激活插件' });
      return true;
    }
    
    if (isSingleVersion) {
      sendResponse({ success: false, error: '您当前使用的是单采版，无法使用批量采集功能' });
      return true;
    }
    
    collectProductsFromTab(sender.tab.id).then(products => {
      sendResponse({ success: true, products });
    }).catch(e => {
      sendResponse({ success: false, error: e.message });
    });
    return true; // 异步响应
  }
  
  if (msg.action === 'collectProduct' && msg.data) {
    // 处理采集商品请求
    initDB().then(() => {
      try {
        const tx = db.transaction(['products'], 'readwrite');
        const store = tx.objectStore('products');
        const product = {
          id: msg.data.id,
          title: msg.data.title,
          img: msg.data.img,
          price: msg.data.price || '',
          url: msg.data.url,
          time: new Date().toISOString()
        };
        
        const request = store.put(product);
        request.onsuccess = () => {
          console.log('商品采集成功:', product.id);
          sendResponse({success: true});
        };
        request.onerror = (e) => {
          console.error('采集保存失败:', e);
          sendResponse({success: false, error: '数据库保存失败'});
        };
      } catch (e) {
        console.error('采集商品时出错:', e);
        sendResponse({success: false, error: '采集处理失败'});
      }
    }).catch(e => {
      console.error('数据库初始化失败:', e);
      sendResponse({success: false, error: '数据库初始化失败'});
    });
    return true; // 保持消息通道开放
  }
  else if (msg.action === 'saveProduct' && msg.product) {
    initDB().then(() => {
      try {
        const tx = db.transaction(['products'], 'readwrite');
        const store = tx.objectStore('products');
        const prod = Object.assign({}, msg.product);
        // 添加采集时间
        prod.time = new Date().toISOString();
        if (prod.imgBlob) prod.imgBlob = base64ToBlob(prod.imgBlob);
        
        const request = store.put(prod);
        request.onsuccess = () => {
          console.log('商品保存成功:', prod.id);
          sendResponse({success: true});
        };
        request.onerror = (e) => {
          console.error('数据库保存失败:', e);
          sendResponse({success: false, error: '数据库保存失败'});
        };
      } catch (e) {
        console.error('保存商品时出错:', e);
        sendResponse({success: false, error: e.message});
      }
    }).catch(e => {
      console.error('初始化数据库失败:', e);
      sendResponse({success: false, error: '数据库初始化失败'});
    });
    return true;
  }
  if (msg.action === 'checkProduct' && msg.id) {
    initDB().then(() => {
      try {
        const tx = db.transaction(['products'], 'readonly');
        const store = tx.objectStore('products');
        const request = store.get(msg.id);
        request.onsuccess = function(e) {
          sendResponse({collected: !!e.target.result});
        };
        request.onerror = function(e) {
          console.error('检查商品失败:', e);
          sendResponse({collected: false, error: '检查失败'});
        };
      } catch (e) {
        console.error('检查商品时出错:', e);
        sendResponse({collected: false, error: '检查处理失败'});
      }
    }).catch(e => {
      console.error('数据库初始化失败:', e);
      sendResponse({collected: false, error: '数据库初始化失败'});
    });
    return true;
  }
  if (msg.action === 'checkImageCollected' && msg.imgSrc) {
    initDB().then(() => {
      try {
        const tx = db.transaction(['products'], 'readonly');
        const store = tx.objectStore('products');
        const request = store.getAll();
        request.onsuccess = function(e) {
          const products = e.target.result || [];
          let isCollected = false;
          
          // 检查是否已采集（多种匹配方式）
          const imgSrcKey = msg.imgSrc.split('?')[0]; // 去除查询参数
          
          for (const product of products) {
            if (!product.img) continue;
            
            // 精确匹配
            if (product.img === msg.imgSrc) {
              isCollected = true;
              break;
            }
            
            // 去除查询参数匹配
            const productImgKey = product.img.split('?')[0];
            if (imgSrcKey === productImgKey) {
              isCollected = true;
              break;
            }
            
            // 文件名匹配
            const imgFileName = imgSrcKey.split('/').pop();
            const productFileName = productImgKey.split('/').pop();
            if (imgFileName && productFileName && imgFileName === productFileName) {
              isCollected = true;
              break;
            }
          }
          
          sendResponse({collected: isCollected});
        };
        request.onerror = function(e) {
          console.error('检查图片采集状态失败:', e);
          sendResponse({collected: false, error: '检查失败'});
        };
      } catch (e) {
        console.error('检查图片采集状态时出错:', e);
        sendResponse({collected: false, error: '检查处理失败'});
      }
    }).catch(e => {
      console.error('检查图片采集状态时数据库初始化失败:', e);
      sendResponse({collected: false, error: '数据库初始化失败'});
    });
    return true;
  }
  if (msg.action === 'getAllProducts') {
    initDB().then(() => {
      try {
        const tx = db.transaction(['products'], 'readonly');
        const store = tx.objectStore('products');
        const request = store.getAll();
        request.onsuccess = function(e) {
          const products = e.target.result || [];
          // 按采集时间从新到旧排序
          products.sort((a, b) => {
            // 如果两个项目都有时间字段，按时间降序排序
            if (a.time && b.time) {
              return new Date(b.time) - new Date(a.time);
            }
            // 如果只有a有时间字段，a排在前面
            if (a.time) return -1;
            // 如果只有b有时间字段，b排在前面
            if (b.time) return 1;
            // 如果都没有时间字段，保持原有顺序
            return 0;
          });
          sendResponse({products: products});
        };
        request.onerror = function(e) {
          console.error('获取所有商品失败:', e);
          sendResponse({products: [], error: '获取数据失败'});
        };
      } catch (e) {
        console.error('获取所有商品时出错:', e);
        sendResponse({products: [], error: '处理失败'});
      }
    }).catch(e => {
      console.error('获取所有商品时数据库初始化失败:', e);
      sendResponse({products: [], error: '数据库初始化失败'});
    });
    return true;
  }
  if (msg.action === 'batchSaveProducts' && msg.products) {
    initDB().then(() => {
      try {
        const tx = db.transaction(['products'], 'readwrite');
        const store = tx.objectStore('products');
        let savedCount = 0;
        let totalCount = msg.products.length;
        
        msg.products.forEach(product => {
          const request = store.put(product);
          request.onsuccess = () => {
            savedCount++;
            if (savedCount === totalCount) {
              console.log(`批量保存完成: ${savedCount} 个商品`);
              sendResponse({success: true, count: savedCount});
            }
          };
          request.onerror = (e) => {
            console.error('批量保存商品失败:', e);
            sendResponse({success: false, error: '保存失败'});
          };
        });
      } catch (e) {
        console.error('批量保存商品时出错:', e);
        sendResponse({success: false, error: e.message});
      }
    }).catch(e => {
      console.error('初始化数据库失败:', e);
      sendResponse({success: false, error: '数据库初始化失败'});
    });
    return true;
  }
  if (msg.action === 'checkMultipleProducts' && msg.productIds) {
    initDB().then(() => {
      try {
        const tx = db.transaction(['products'], 'readonly');
        const store = tx.objectStore('products');
        const uncollectedIds = [];
        let checkedCount = 0;
        
        msg.productIds.forEach(productId => {
          const request = store.get(productId);
          request.onsuccess = function(e) {
            if (!e.target.result) {
              // 商品不存在，添加到未采集列表
              uncollectedIds.push(productId);
            }
            checkedCount++;
            if (checkedCount === msg.productIds.length) {
              // 所有商品检查完成
              sendResponse({uncollectedIds: uncollectedIds});
            }
          };
          request.onerror = function(e) {
            console.error('检查单个商品失败:', e);
            // 出错时也要计数，避免卡住
            checkedCount++;
            if (checkedCount === msg.productIds.length) {
              sendResponse({uncollectedIds: uncollectedIds});
            }
          };
        });
      } catch (e) {
        console.error('检查多个商品时出错:', e);
        sendResponse({uncollectedIds: [], error: '检查处理失败'});
      }
    }).catch(e => {
      console.error('检查商品状态时数据库初始化失败:', e);
      sendResponse({uncollectedIds: [], error: '数据库初始化失败'});
    });
    return true;
  }
  if (msg.action === 'clearAllProducts') {
    initDB().then(() => {
      try {
        const tx = db.transaction(['products'], 'readwrite');
        const store = tx.objectStore('products');
        const request = store.clear();
        request.onsuccess = () => {
          console.log('所有商品数据已清除');
          sendResponse({success: true});
        };
        request.onerror = (e) => {
          console.error('清除数据失败:', e);
          sendResponse({success: false, error: '清除失败'});
        };
      } catch (e) {
        console.error('清除数据时出错:', e);
        sendResponse({success: false, error: e.message});
      }
    }).catch(e => {
      console.error('初始化数据库失败:', e);
      sendResponse({success: false, error: '数据库初始化失败'});
    });
    return true;
  }
  if (msg.action === 'getSavedProductCount') {
    initDB().then(() => {
      try {
        const tx = db.transaction(['products'], 'readonly');
        const store = tx.objectStore('products');
        const countRequest = store.count();
        countRequest.onsuccess = function(e) {
          sendResponse({count: e.target.result});
        };
        countRequest.onerror = function(e) {
          console.error('获取商品数量失败:', e);
          sendResponse({count: 0, error: '获取数量失败'});
        };
      } catch (e) {
        console.error('获取商品数量时出错:', e);
        sendResponse({count: 0, error: '处理失败'});
      }
    }).catch(e => {
      console.error('获取商品数量时数据库初始化失败:', e);
      sendResponse({count: 0, error: '数据库初始化失败'});
    });
    return true;
  }
  if (msg.action === 'getTodaySavedProductCount') {
    initDB().then(() => {
      try {
        const tx = db.transaction(['products'], 'readonly');
        const store = tx.objectStore('products');
        const req = store.getAll();
        req.onsuccess = function(e) {
          try {
            const products = e.target.result || [];
            const today = new Date().toISOString().slice(0, 10);
            const todayCount = products.filter(p => {
              return p.time && p.time.slice(0, 10) === today;
            }).length;
            sendResponse({count: todayCount});
          } catch (e) {
            console.error('处理今日商品数据时出错:', e);
            sendResponse({count: 0, error: '数据处理失败'});
          }
        };
        req.onerror = function(e) {
          console.error('获取今日商品数量失败:', e);
          sendResponse({count: 0, error: '获取数据失败'});
        };
      } catch (e) {
        console.error('获取今日商品数量时出错:', e);
        sendResponse({count: 0, error: '处理失败'});
      }
    }).catch(e => {
      console.error('获取今日商品数量时数据库初始化失败:', e);
      sendResponse({count: 0, error: '数据库初始化失败'});
    });
    return true;
  }
});

// 检查插件更新
async function checkPluginUpdates() {
  try {
    console.log('检查插件更新...');
    
    // 获取最新版本信息
    const latestVersionInfo = await getLatestVersionInfo();
    if (!latestVersionInfo) {
      console.log('未能获取版本信息');
      return;
    }
    
    // 获取当前插件版本
    const currentVersion = chrome.runtime.getManifest().version;
    console.log(`当前版本: ${currentVersion}, 最新版本: ${latestVersionInfo.version}`);
    
    // 比较版本号
    if (isNewerVersion(latestVersionInfo.version, currentVersion)) {
      // 显示更新通知
      showUpdateNotification(latestVersionInfo);
    } else {
      console.log('插件已是最新版本');
    }
    
    // 更新词库（无论是否有版本更新）
    await updateFilterWords();
    
  } catch (error) {
    console.error('检查更新时出错:', error);
  }
}

// 从GitHub Pages获取最新版本信息
async function getLatestVersionInfo() {
  try {
    const response = await fetch('https://aygtemu.github.io/temu-/version.json');
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('获取最新版本信息失败:', error);
    return null;
  }
}

// 比较版本号
function isNewerVersion(latestVersion, currentVersion) {
  // 解析版本号
  const latest = latestVersion.split('.').map(Number);
  const current = currentVersion.split('.').map(Number);
  
  // 比较每个部分
  for (let i = 0; i < Math.max(latest.length, current.length); i++) {
    const latestNum = latest[i] || 0;
    const currentNum = current[i] || 0;
    
    if (latestNum > currentNum) return true;
    if (latestNum < currentNum) return false;
  }
  
  return false; // 版本相同
}

// 显示更新通知
function showUpdateNotification(versionInfo) {
  // 创建通知选项
  const options = {
    type: 'basic',
    iconUrl: '/icons/icon128.png',
    title: 'temuSan 插件更新',
    message: `发现新版本 ${versionInfo.version}!\n点击前往更新。`,
    priority: 1
  };
  
  // 显示通知
  chrome.notifications.create('update-notification', options, (notificationId) => {
    // 监听通知点击事件
    chrome.notifications.onClicked.addListener((clickedId) => {
      if (clickedId === notificationId) {
        // 使用version.json中的downloadUrl或默认URL
        const downloadUrl = versionInfo.downloadUrl || 'https://aygtemu.github.io/temu-';
        chrome.tabs.create({ url: downloadUrl });
      }
    });
  });
}

// 更新过滤词库
async function updateFilterWords() {
  try {
    console.log('更新过滤词库...');
    
    // 从GitHub Pages获取过滤词
    const response = await fetch('https://aygtemu.github.io/temu-/filter_words.json');
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const filterData = await response.json();
    
    // 保存到本地存储
    await chrome.storage.local.set({
      prohibitedWords: filterData.prohibitedWords || [],
      filterWords: filterData.filterWords || [],
      lastWordsUpdate: new Date().toISOString()
    });
    
    console.log('过滤词库更新成功');
    return true;
  } catch (error) {
    console.error('更新过滤词库失败:', error);
    return false;
  }
}

// 检查服务器健康状态
async function checkServerHealth() {
  try {
    const response = await fetch('https://aygtemu.github.io/temu-/health.json', {
      method: 'GET',
      cache: 'no-cache',
      timeout: 5000 // 5秒超时
    });
    
    if (!response.ok) {
      throw new Error(`服务器响应错误: ${response.status}`);
    }
    
    const healthData = await response.json();
    return {
      healthy: true,
      lastChecked: new Date().toISOString(),
      serverInfo: healthData
    };
  } catch (error) {
    console.error('服务器健康检查失败:', error);
    return {
      healthy: false,
      lastChecked: new Date().toISOString(),
      error: error.message
    };
  }
}

// 初始化时检查激活状态
checkActivationStatus();

// 初始化时检查更新
checkPluginUpdates();

// 定期检查更新（每24小时）
setInterval(checkPluginUpdates, 24 * 60 * 60 * 1000);

// 监听存储变化，更新激活状态和版本信息
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === 'local') {
    if (changes.pluginActivated) {
      isActivated = changes.pluginActivated.newValue || false;
    }
    
    if (changes.pluginVersion) {
      isSingleVersion = (changes.pluginVersion.newValue === 'single');
      console.log('插件版本更新为:', isSingleVersion ? '单采版' : '批采版');
    }
    
    if (changes.expireDate) {
      expireDate = changes.expireDate.newValue ? new Date(changes.expireDate.newValue) : null;
    }
  }
});
