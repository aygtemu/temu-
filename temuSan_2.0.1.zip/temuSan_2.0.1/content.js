// TEMU商品采集插件 - 完全重写版本
(function() {
  'use strict';
  
  console.log('🚀 TEMU采集插件启动');
  console.log('当前页面URL:', window.location.href);
  console.log('DOM状态:', document.readyState);
  console.log('Body存在:', !!document.body);
  
  // 创建CSS样式表（简化版本，确保显示）
  function createStyleSheet() {
    if (document.getElementById('temu-collector-styles')) return;
    
    const style = document.createElement('style');
    style.id = 'temu-collector-styles';
    style.textContent = `
      .temu-collect-btn {
        position: absolute !important;
        top: 5px !important;
        right: 5px !important;
        width: 50px !important;
        height: 50px !important;
        background: #ff6700 !important;
        color: white !important;
        border: 2px solid white !important;
        border-radius: 50% !important;
        font-size: 11px !important;
        font-weight: bold !important;
        cursor: pointer !important;
        z-index: 999999 !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        box-shadow: 0 2px 8px rgba(0,0,0,0.4) !important;
        font-family: Arial, sans-serif !important;
        user-select: none !important;
        pointer-events: auto !important;
        transition: all 0.3s ease !important;
      }
      
      .temu-collect-btn:hover {
        transform: scale(1.1) !important;
        box-shadow: 0 4px 16px rgba(255,103,0,0.6) !important;
        background: #ff8533 !important;
      }
      
      .temu-collect-btn.collected {
         background: #28a745 !important;
         cursor: default !important;
         color: white !important;
         pointer-events: none !important;
      }
      
      .temu-collect-btn.collected:hover {
         transform: scale(1.05) !important;
         box-shadow: 0 3px 12px rgba(40,167,69,0.5) !important;
         background: #28a745 !important;
         color: white !important;
      }
      
      .temu-collect-btn.failed {
         background: #dc3545 !important;
         color: white !important;
         cursor: pointer !important;
      }
    `;
    
    document.head.appendChild(style);
    console.log('✅ CSS样式表已创建');
  }

  // 全局变量
  let collectButtons = [];
  let isInitialized = false;
  let isRecording = false;
  let viewedImages = new Set();
  let collectedImages = new Set();
  let recordingStartTime = null;
  let preCollectedData = new Map(); // 预采集数据缓存
  let isSingleVersion = false; // 跟踪是否为单采版，初始化为false，稍后会从background更新
  let isPluginExpired = false; // 插件是否已过期
  let isActivated = false; // 插件是否已激活，初始化为false，稍后会从background更新
  
  // 获取插件版本信息、过期状态和激活状态
  getPluginStatus();
  
  function getPluginStatus() {
    if (typeof chrome !== 'undefined' && chrome.runtime) {
      try {
        // 获取版本信息
        chrome.runtime.sendMessage({ action: 'getPluginVersion' }, (response) => {
          // 检查是否有错误发生
          if (chrome.runtime.lastError) {
            // 忽略扩展上下文失效的错误
            if (!chrome.runtime.lastError.message.includes('Extension context invalidated')) {
              console.warn('⚠️ 获取版本信息失败:', chrome.runtime.lastError.message);
            }
            return;
          }
          
          if (response) {
            isSingleVersion = response.isSingleVersion || false;
            console.log('🔍 插件版本状态已更新:', isSingleVersion ? '单采版' : '批采版');
            // 立即调用一次updateStatusPanel以确保计数显示正确
            updateStatusPanel();
            
            // 不再自动重新创建面板，只更新现有面板的内容
          }
        });
        
        // 检查插件是否过期
        chrome.runtime.sendMessage({ action: 'checkPluginExpiration' }, (response) => {
          // 检查是否有错误发生
          if (chrome.runtime.lastError) {
            // 忽略扩展上下文失效的错误
            if (!chrome.runtime.lastError.message.includes('Extension context invalidated')) {
              console.warn('⚠️ 检查插件过期状态失败:', chrome.runtime.lastError.message);
            }
            return;
          }
          
          if (response) {
            const wasExpired = isPluginExpired;
            isPluginExpired = response.isExpired || false;
            console.log('🔍 插件过期状态:', isPluginExpired ? '已过期' : '未过期');
            
            // 如果插件刚过期，销毁已创建的面板
            if (isPluginExpired && isInitialized && !wasExpired) {
              destroyStatusPanel();
              isInitialized = false;
              console.log('⚠️ 插件已过期，已销毁状态面板');
            }
            
            // 如果插件从过期状态恢复（重新激活），重新初始化
            if (!isPluginExpired && wasExpired && !isInitialized) {
              console.log('✅ 插件已重新激活，准备重新初始化');
              // 延迟一点时间确保状态同步
              setTimeout(() => {
                initializeButtonCreation();
              }, 1000);
            }
          }
        });
        
        // 检查插件是否激活
        chrome.runtime.sendMessage({ action: 'checkPluginActivation' }, (response) => {
          // 检查是否有错误发生
          if (chrome.runtime.lastError) {
            // 忽略扩展上下文失效的错误
            if (!chrome.runtime.lastError.message.includes('Extension context invalidated')) {
              console.warn('⚠️ 检查插件激活状态失败:', chrome.runtime.lastError.message);
            }
            return;
          }
          
          if (response) {
            const wasActivated = isActivated;
            isActivated = response.isActivated || false;
            console.log('🔍 插件激活状态:', isActivated ? '已激活' : '未激活');
            
            // 如果插件刚激活，重新初始化
            if (isActivated && !wasActivated && !isInitialized && !isPluginExpired) {
              console.log('✅ 插件已激活，准备初始化');
              // 延迟一点时间确保状态同步
              setTimeout(() => {
                initializeButtonCreation();
              }, 1000);
            }
            
            // 如果插件从激活状态变为未激活，销毁已创建的面板
            if (!isActivated && wasActivated && isInitialized) {
              destroyStatusPanel();
              isInitialized = false;
              console.log('⚠️ 插件未激活，已销毁状态面板');
            }
          }
        });
      } catch (error) {
        // 忽略扩展上下文失效的错误，这在扩展被禁用、卸载或更新时是正常的
        if (!error.toString().includes('Extension context invalidated')) {
          console.warn('⚠️ 获取插件状态失败:', error);
        }
      }
    }
  }
  
  // 定期检查插件状态
  let statusCheckInterval = setInterval(() => {
    try {
      // 只检查插件状态，不会创建新面板
      getPluginStatus();
    } catch (error) {
      // 如果是扩展上下文失效错误，则清除定时器
      if (error.toString().includes('Extension context invalidated')) {
        console.log('ℹ️ 扩展上下文已失效，停止定期检查');
        clearInterval(statusCheckInterval);
      } else {
        console.warn('⚠️ 定期检查插件状态失败:', error);
      }
    }
  }, 30000); // 每30秒检查一次

  // 配置
  const CONFIG = {
    buttonSize: 50,
    buttonOffset: { x: -55, y: 5 },
    updateInterval: 5000,
    scrollUpdateDelay: 16,
    maxButtonsPerFrame: 50,
    viewportBuffer: 100
  };

  // 查找商品卡图片
  function findProductImages(elements = [document]) {
    const selectors = [
      'img[src*="kwcdn"][src*="goods"]',
      '[data-js-main-img="true"]',
      '[class*="_3ZME5MBZ"] img',
      '.goods-img-external img',
      '._1GE1BzXo img'
    ];
    
    const imagesByProduct = new Map();
    
    try {
      let allImages = [];
      elements.forEach(element => {
        if (typeof element.querySelectorAll !== 'function') return;
        // Find images within the element
        const foundImages = element.querySelectorAll(selectors.join(','));
        allImages.push(...foundImages);

        // Also check if the element itself is a matching image
        if (element.matches && element.matches(selectors.join(','))) {
          allImages.push(element);
        }
      });

      // Remove duplicates
      allImages = [...new Set(allImages)];

      if (!allImages || allImages.length === 0) {
        return [];
      }
      
      for (const img of allImages) {
        try {
          if (!img.src || !img.src.includes('kwcdn') || 
              img.naturalWidth <= 200 || img.naturalHeight <= 200) {
            continue;
          }
          
          const productCard = img.closest('[role="button"], [class*="_3ZME5MBZ"], .goods-img-external');
          if (!productCard) continue;
          
          const rect = productCard.getBoundingClientRect();
          const productId = `${Math.round(rect.left)}_${Math.round(rect.top)}`;
          
          const existingImg = imagesByProduct.get(productId);
          if (!existingImg || getImageQualityScore(img) > getImageQualityScore(existingImg)) {
            imagesByProduct.set(productId, img);
          }
        } catch (imgError) {
          console.warn('处理单个图片时出错:', imgError);
          continue;
        }
      }
    } catch (error) {
      console.warn('查找商品图片时出错:', error);
      return [];
    }
    
    const result = Array.from(imagesByProduct.values());
    
    if (result.length !== window.lastImageCount) {
      console.log(`📸 找到图片: ${result.length} 个`);
      window.lastImageCount = result.length;
    }
    
    return result;
  }

  // 图片质量评分
  function getImageQualityScore(img) {
    let score = 0;
    
    // 基础分数：图片尺寸
    score += Math.min(img.naturalWidth * img.naturalHeight / 10000, 100);
    
    // URL参数评分
    const url = img.src;
    if (url.includes('w/400') || url.includes('w/500')) score += 20;
    if (url.includes('q/80') || url.includes('q/90')) score += 15;
    if (url.includes('w/150') || url.includes('w/200')) score -= 30;
    if (url.includes('q/50') || url.includes('q/60')) score -= 20;
    
    // 特殊属性加分
    if (img.getAttribute('data-js-main-img')) score += 30;
    if (img.closest('[class*="main"]')) score += 10;
    
    return Math.max(0, score);
  }

  // 预采集商品信息（增强版标题提取）
  function preCollectProductInfo(img, index) {
    try {
      const imgSrc = img.src;
      
      if (preCollectedData.has(imgSrc)) {
        return;
      }
      
      let title = '商品';
      let imgAlt = '';
      
      const productCard = img.closest([
        '[role="button"]',
        '[class*="_3ZME5MBZ"]', 
        '.goods-img-external',
        '[class*="product"]',
        '[class*="item"]',
        '[class*="card"]'
      ].join(', '));
      
      if (productCard) {
        console.log('🔍 预采集 - 开始提取商品标题...');
        
        // 🚀 直接使用备用方案（快速简单）
        try {
          console.log('🚀 使用快速备用方案提取标题...');
          
          // 直接使用图片alt属性（最快最简单）
          if (img.alt && img.alt.trim().length > 0) {
            title = img.alt.trim();
            console.log('✅ 直接使用alt属性:', title);
          }
          // 备用：使用title属性
          else if (img.title && img.title.trim().length > 0) {
            title = img.title.trim();
            console.log('✅ 使用title属性:', title);
          }
          // 最后备用：从URL提取
          else if (img.src) {
            const urlParts = img.src.split('/');
            const filename = urlParts[urlParts.length - 1];
            if (filename && filename.length > 5) {
              const nameWithoutExt = filename.replace(/\.[^.]+$/, '').replace(/[_-]/g, ' ');
              if (nameWithoutExt.length > 3) {
                title = nameWithoutExt;
                console.log('✅ 使用文件名:', title);
              }
            }
          }
          
        } catch (error) {
          console.error('❌ 快速提取出错:', error);
          if (img.alt) {
            title = img.alt;
          }
        }
      } else {
        console.log('❌ 预采集 - 未找到商品容器');
      }
      
      // 使用xx.js的图片提取逻辑
      const imageUrl = productCard ? extractBestImage(productCard) : '';
      
      if (img.alt && img.alt.length > 5) {
        imgAlt = img.alt;
      } else if (img.title && img.title.length > 5) {
        imgAlt = img.title;
      }
      
      const preData = {
        id: `pre_${Date.now()}_${index}`,
        title: title, // 移除 || '商品' 的默认值逻辑
        img: imgSrc,
        imgAlt: imgAlt,
        url: window.location.href,
        timestamp: Date.now(),
        index: index
      };
      
      console.log('📦 预采集完成 - 商品数据:', preData);
      
      preCollectedData.set(imgSrc, preData);
      
    } catch (error) {
      console.error('预采集失败:', error);
    }
  }

  // 🎯 简化版商品标题提取函数（直接文本分析）
  function extractProductTitle(container) {
    try {
      console.log('🔍 开始提取标题...');
      console.log('📦 容器信息:', container);
      console.log('📦 容器类名:', container.className);
      console.log('📦 容器内容预览:', container.textContent?.substring(0, 200));
      
      // 🎯 策略1: 直接分析容器内的所有文本
      const allText = container.textContent || '';
      console.log('📝 容器完整文本:', allText);
      
      if (allText.trim()) {
        // 按行分割文本
        const lines = allText.split('\n').map(line => line.trim()).filter(line => line.length > 0);
        console.log('📄 文本行数:', lines.length);
        
        for (let i = 0; i < lines.length; i++) {
          const line = lines[i];
          console.log(`📝 第${i+1}行: "${line}" (长度: ${line.length})`);
          
          // 🎯 使用最宽松的验证
          if (isValidTitleLoose(line)) {
            console.log(`✅ 找到有效标题: "${line}"`);
            return line;
          }
        }
      }
      
      // 🎯 策略2: 遍历所有子元素的文本
      console.log('🔍 遍历子元素文本...');
      const allElements = container.querySelectorAll('*');
      console.log(`📦 找到 ${allElements.length} 个子元素`);
      
      for (let i = 0; i < Math.min(allElements.length, 50); i++) { // 限制检查前50个元素
        const element = allElements[i];
        const text = element.textContent?.trim() || '';
        
        if (text && text.length > 5 && text.length < 300) {
          console.log(`🔍 元素文本: "${text}" (标签: ${element.tagName})`);
          
          if (isValidTitleLoose(text)) {
            console.log(`✅ 找到有效标题: "${text}"`);
            return text;
          }
        }
      }
      
      console.log('❌ 未找到有效标题');
      return '';
    } catch (error) {
      console.error('提取标题时出错:', error);
      return '';
    }
  }
  
  // 🎯 严格的标题验证（基于xx.js）
  function isValidTitleStrict(text) {
    if (!text || typeof text !== 'string') {
      console.log('❌ 验证失败: 文本为空或非字符串');
      return false;
    }
    
    const trimmed = text.trim();
    console.log(`🔍 验证标题: "${trimmed}" (长度: ${trimmed.length})`);
    
    // 长度检查
    if (trimmed.length < 5 || trimmed.length > 500) {
      console.log(`❌ 验证失败: 长度不符合要求 (${trimmed.length})`);
      return false;
    }
    
    // 🚫 排除常见的无效内容
    const invalidPatterns = [
      // 价格相关
      /^[\d\s\$¥€£.,-]+$/,
      /^\$[\d.,\s]+$/,
      /^¥[\d.,\s]+$/,
      /^[\d.,$¥€£\s,-]+$/,
      
      // 按钮和操作文本
      /^(buy now|add to cart|shop now|购买|加入购物车|立即购买|立即下单)$/i,
      /^(search|category|filter|sort|搜索|分类|筛选|排序)$/i,
      /^(loading|error|请稍候|加载中|出错了)$/i,
      /^(more|see more|查看更多|显示更多|load more|加载更多)$/i,
      
      // Local标签和店铺相关
      /^local$/i,
      /^(store|shop|seller|brand|店铺|商店|卖家|品牌)$/i,
      /^(local\s+|本地\s*)/i,
      
      // 常见标签和徽章
      /^(new|hot|sale|推荐|精选|热卖|新品|促销)$/i,
      /^(free shipping|包邮|免运费)$/i,
      /^(in stock|现货|有库存)$/i,
      
      // 数量和规格
      /^(qty|quantity|数量)[\s:]*\d+$/i,
      /^size[\s:]/i,
      /^color[\s:]/i,
      
      // 社交和评价
      /^(follow|like|share|关注|点赞|分享)$/i,
      /^(review|rating|评价|评分)$/i,
      
      // 导航和页面元素
      /^(home|back|next|prev|首页|返回|下一页|上一页)$/i,
      /^(menu|导航|菜单)$/i
    ];
    
    // 检查是否匹配无效模式
    for (const pattern of invalidPatterns) {
      if (pattern.test(trimmed)) {
        console.log(`❌ 验证失败: 匹配无效模式 ${pattern}`);
        return false;
      }
    }
    
    // 检查是否包含Local标签（更严格）
    if (/\blocal\b/i.test(trimmed) && trimmed.length < 20) {
      console.log('❌ 验证失败: 包含Local标签且长度过短');
      return false;
    }
    
    // 检查是否主要是标点符号或特殊字符
    const alphanumericCount = (trimmed.match(/[a-zA-Z0-9\u4e00-\u9fa5]/g) || []).length;
    if (alphanumericCount < trimmed.length * 0.6) {
      console.log('❌ 验证失败: 字母数字字符比例过低');
      return false;
    }
    
    // 检查是否是重复字符
    const uniqueChars = new Set(trimmed.toLowerCase().replace(/\s/g, ''));
    if (uniqueChars.size < 3) {
      console.log('❌ 验证失败: 唯一字符数过少');
      return false;
    }
    
    console.log('✅ 标题验证通过');
    return true;
  }
  
  // 🎯 简化版智能文本分析
  function extractTitleByAnalysisSimple(container) {
    try {
      console.log('🤖 开始智能文本分析...');
      
      // 获取容器内所有文本节点
      const textNodes = [];
      const walker = document.createTreeWalker(
        container,
        NodeFilter.SHOW_TEXT,
        {
          acceptNode: function(node) {
            const text = node.textContent.trim();
            if (text.length > 10 && text.length < 200) {
              // 排除明显的非标题元素
              const parent = node.parentElement;
              if (parent && !parent.matches('button, input, select, script, style, .price, [class*="price"], [class*="local"]')) {
                return NodeFilter.FILTER_ACCEPT;
              }
            }
            return NodeFilter.FILTER_REJECT;
          }
        }
      );
      
      let node;
      while (node = walker.nextNode()) {
        textNodes.push(node.textContent.trim());
      }
      
      console.log(`🔍 智能分析找到 ${textNodes.length} 个文本节点`);
      
      // 按文本长度排序，优先选择中等长度的文本
      const candidates = textNodes
        .filter(text => isValidTitleStrict(text))
        .sort((a, b) => {
          // 优先选择长度在20-100之间的文本
          const aScore = getTitleScoreSimple(a);
          const bScore = getTitleScoreSimple(b);
          return bScore - aScore;
        });
      
      console.log(`🔍 智能分析有效候选: ${candidates.length} 个`);
      
      return candidates[0] || null;
    } catch (error) {
      console.error('智能文本分析失败:', error);
      return null;
    }
  }
  
  // 🎯 简化版标题评分算法
  function getTitleScoreSimple(text) {
    let score = 0;
    const length = text.length;
    
    // 长度评分（20-80字符最佳）
    if (length >= 20 && length <= 80) {
      score += 50;
    } else if (length >= 10 && length <= 150) {
      score += 30;
    } else {
      score += 10;
    }
    
    // 包含产品关键词加分
    const productKeywords = [
      'shirt', 'dress', 'pants', 'shoes', 'bag', 'watch', 'phone', 'case',
      '衬衫', '连衣裙', '裤子', '鞋子', '包', '手表', '手机', '保护套',
      'men', 'women', 'kids', 'cotton', 'leather'
    ];
    
    const hasProductKeywords = productKeywords.some(keyword => 
      text.toLowerCase().includes(keyword.toLowerCase())
    );
    if (hasProductKeywords) {
      score += 20;
    }
    
    return score;
  }

  // 🎯 智能标题验证方法（增强调试版本）
  function isValidTitle(text) {
    console.log(`🔍 验证标题: "${text}"`);
    
    if (!text || typeof text !== 'string') {
      console.log('❌ 验证失败: 文本为空或非字符串');
      return false;
    }
    
    const trimmed = text.trim();
    console.log(`🔍 去空格后: "${trimmed}" (长度: ${trimmed.length})`);
    
    // 🎯 基础长度检查
    if (trimmed.length < 3 || trimmed.length > 500) {
      console.log(`❌ 验证失败: 长度不符合要求 (${trimmed.length})`);
      return false;
    }
    
    // 🎯 智能商品标题识别
    const productIndicators = [
      // 商品相关关键词
      /\b(shirt|dress|pants|shoes|bag|watch|phone|case|衬衫|连衣裙|裤子|鞋子|包|手表|手机|保护套)\b/i,
      /\b(men|women|kids|male|female|boy|girl|男|女|儿童|童装)\b/i,
      /\b(cotton|leather|silk|wool|plastic|metal|棉|皮革|丝绸|羊毛|塑料|金属)\b/i,
      /\b(size|color|style|design|pattern|尺寸|颜色|款式|设计|图案)\b/i,
      /\b(vintage|classic|modern|casual|formal|复古|经典|现代|休闲|正式)\b/i,
      // 品牌和描述性词汇
      /\b(premium|luxury|quality|brand|high|low|优质|奢华|品质|品牌|高|低)\b/i,
      // 商品特征
      /\b(new|latest|best|top|hot|popular|新|最新|最好|顶级|热门|流行)\b/i
    ];
    
    const hasProductIndicators = productIndicators.some(pattern => pattern.test(trimmed));
    
    // 🚫 排除明显无效内容
    const invalidPatterns = [
      // 价格相关
      /^[\d\s\$¥€£.,-]+$/,
      /^\$[\d.,\s]+$/,
      /^¥[\d.,\s]+$/,
      /^[\d.,$¥€£\s,-]+$/,
      
      // 按钮和操作文本
      /^(buy now|add to cart|shop now|购买|加入购物车|立即购买|立即下单)$/i,
      /^(search|category|filter|sort|搜索|分类|筛选|排序)$/i,
      /^(loading|error|请稍候|加载中|出错了)$/i,
      /^(more|see more|查看更多|显示更多|load more|加载更多)$/i,
      
      // 🎯 Local标签和店铺相关（但允许包含商品指示词的情况）
      /^local$/i,
      /^(store|shop|seller|brand|店铺|商店|卖家|品牌)$/i,
      
      // 🎯 纯标签和徽章
      /^(new|hot|sale|推荐|精选|热卖|新品|促销)$/i,
      /^(free shipping|包邮|免运费)$/i,
      /^(in stock|现货|有库存)$/i,
      
      // 🎯 数量和规格（单独出现时）
      /^(qty|quantity|数量)[\s:]*\d+$/i,
      /^size[\s:][^a-zA-Z\u4e00-\u9fa5]*$/i,
      /^color[\s:][^a-zA-Z\u4e00-\u9fa5]*$/i,
      
      // 社交和评价
      /^(follow|like|share|关注|点赞|分享)$/i,
      /^(review|rating|评价|评分)$/i,
      
      // 导航和页面元素
      /^(home|back|next|prev|首页|返回|下一页|上一页)$/i,
      /^(menu|导航|菜单)$/i
    ];
    
    // 检查是否匹配无效模式
    for (const pattern of invalidPatterns) {
      if (pattern.test(trimmed)) {
        // 🎯 如果包含商品指示词，可能是有效标题
        if (hasProductIndicators && trimmed.length > 10) {
          console.log(`⚠️ 包含无效模式但有商品指示词，继续验证: ${pattern}`);
          break;
        }
        console.log(`❌ 验证失败: 匹配无效模式 ${pattern}`);
        return false;
      }
    }
    
    // 🎯 检查是否包含Local标签（更宽松）
    if (/\blocal\b/i.test(trimmed)) {
      if (trimmed.length < 15 && !hasProductIndicators) {
        console.log('❌ 验证失败: 包含Local标签且无商品指示词');
        return false;
      }
    }
    
    // 🎯 字符组成检查（更宽松）
    const alphanumericCount = (trimmed.match(/[a-zA-Z0-9\u4e00-\u9fa5]/g) || []).length;
    const alphanumericRatio = alphanumericCount / trimmed.length;
    console.log(`🔍 字母数字比例: ${alphanumericRatio.toFixed(2)} (${alphanumericCount}/${trimmed.length})`);
    
    // 🎯 如果有商品指示词，放宽字符比例要求
    const minRatio = hasProductIndicators ? 0.3 : 0.4;
    if (alphanumericRatio < minRatio) {
      console.log(`❌ 验证失败: 字母数字字符比例过低 (要求: ${minRatio})`);
      return false;
    }
    
    // 🎯 唯一字符检查
    const uniqueChars = new Set(trimmed.toLowerCase().replace(/\s/g, ''));
    console.log(`🔍 唯一字符数: ${uniqueChars.size}`);
    
    if (uniqueChars.size < 2) {
      console.log('❌ 验证失败: 唯一字符数过少');
      return false;
    }
    
    // 🎯 商品指示词加分
    if (hasProductIndicators) {
      console.log('✅ 包含商品指示词，提高通过概率');
    }
    
    console.log('✅ 标题验证通过');
    return true;
  }

  // 🎯 智能文本分析提取标题（完全采用xx.js的实现）
  function extractTitleByAnalysis(container) {
    try {
      // 获取容器内所有文本节点
      const textNodes = [];
      const walker = document.createTreeWalker(
        container,
        NodeFilter.SHOW_TEXT,
        {
          acceptNode: function(node) {
            const text = node.textContent.trim();
            if (text.length > 10 && text.length < 200) {
              // 排除明显的非标题元素
              const parent = node.parentElement;
              if (parent && !parent.matches('button, input, select, script, style, .price, [class*="price"], [class*="local"]')) {
                return NodeFilter.FILTER_ACCEPT;
              }
            }
            return NodeFilter.FILTER_REJECT;
          }
        }
      );
      
      let node;
      while (node = walker.nextNode()) {
        textNodes.push(node.textContent.trim());
      }
      
      // 按文本长度排序，优先选择中等长度的文本
      const candidates = textNodes
        .filter(text => isValidTitle(text))
        .sort((a, b) => {
          // 优先选择长度在20-100之间的文本
          const aScore = getTitleScore(a);
          const bScore = getTitleScore(b);
          return bScore - aScore;
        });
      
      return candidates[0] || null;
    } catch (error) {
      console.error('智能文本分析失败:', error);
      return null;
    }
  }

  // 🎯 标题评分算法（完全采用xx.js的实现）
  function getTitleScore(text) {
    let score = 0;
    const length = text.length;
    
    // 长度评分（20-80字符最佳）
    if (length >= 20 && length <= 80) {
      score += 50;
    } else if (length >= 10 && length <= 150) {
      score += 30;
    } else {
      score += 10;
    }
    
    // 包含产品关键词加分
    const productKeywords = [
      'shirt', 'dress', 'pants', 'shoes', 'bag', 'watch', 'phone', 'case',
      '衬衫', '连衣裙', '裤子', '鞋子', '包', '手表', '手机', '保护套',
      'men', 'women', 'kids', 'cotton', 'leather', 'wireless',
      '男', '女', '儿童', '棉', '皮革', '无线'
    ];
    
    const hasProductKeywords = productKeywords.some(keyword => 
      text.toLowerCase().includes(keyword.toLowerCase())
    );
    if (hasProductKeywords) {
      score += 20;
    }
    
    // 包含品牌或描述性词汇加分
    if (/\b(vintage|classic|premium|luxury|casual|formal|sport)\b/i.test(text)) {
      score += 10;
    }
    
    return score;
  }

  // 🎯 图片提取函数（完全采用xx.js的实现）
  function extractBestImage(container) {
    try {
      // 🔧 添加容器验证
      if (!container || !container.querySelectorAll) {
        console.warn('无效的容器元素');
        return '';
      }
      
      const images = container.querySelectorAll('img');
      if (!images || images.length === 0) {
        return '';
      }
      
      let bestImage = null;
      let maxSize = 0;
      
      for (const img of images) {
        try {
          const src = img.src || img.getAttribute('data-src') || 
                     img.getAttribute('data-original') || img.getAttribute('srcset');
          
          if (src && src.length > 10) {
            const width = img.naturalWidth || img.width || parseInt(img.getAttribute('width')) || 100;
            const height = img.naturalHeight || img.height || parseInt(img.getAttribute('height')) || 100;
            const size = width * height;
            
            if (size > maxSize) {
              maxSize = size;
              bestImage = src;
            }
          }
        } catch (imgError) {
          console.warn('处理单个图片时出错:', imgError);
          continue;
        }
      }
      
      return bestImage || '';
    } catch (error) {
      console.warn('提取图片时出错:', error);
      return '';
    }
  }

  // 快速获取商品信息（从缓存获取）
  function getProductInfoFast(img) {
    const cached = preCollectedData.get(img.src);
    if (cached) {
      console.log('📋 快速获取 - 使用缓存数据:', cached.title);
      return {
        title: cached.title,
        imgSrc: cached.img,
        url: cached.url
      };
    }
    
    // 如果没有缓存，尝试实时提取标题
    console.log('🔍 快速获取 - 缓存未命中，尝试实时提取标题...');
    let title = '商品';
    
    const productCard = img.closest([
      '[role="button"]',
      '[class*="_3ZME5MBZ"]', 
      '.goods-img-external',
      '[class*="product"]',
      '[class*="item"]',
      '[class*="card"]'
    ].join(', '));
    
    if (productCard) {
      try {
        const containerText = productCard.textContent || '';
        console.log('📝 快速获取 - 容器文本:', containerText.substring(0, 300));
        
        if (containerText.trim()) {
          const words = containerText.split(/[\s\n\r]+/).filter(word => {
            const w = word.trim();
            return w.length > 3 && 
                   !/^[\d\$¥€£.,\-]+$/.test(w) && 
                   !/^(local|store|shop|new|hot|sale)$/i.test(w) &&
                   /[a-zA-Z\u4e00-\u9fa5]/.test(w);
          });
          
          if (words.length > 0) {
            const extractedTitle = words.slice(0, Math.min(6, words.length)).join(' ');
            if (extractedTitle && extractedTitle.length > 5) {
              title = extractedTitle;
              console.log('✅ 快速获取 - 实时提取成功:', title);
            }
          }
        }
      } catch (error) {
        console.error('❌ 快速获取 - 提取过程出错:', error);
      }
    } else {
      console.log('❌ 快速获取 - 未找到商品容器');
    }
    
    return {
      title: title,
      imgSrc: img.src,
      url: window.location.href
    };
  }

  // 创建采集按钮（预采集版本）
  function createCollectButtonFast(img, index, productCard = null) {
    try {
      if (img.temuCollectButton) {
        return img.temuCollectButton;
      }
      
      // 检查是否已采集（使用更严格的匹配）
      let isAlreadyCollected = collectedImages.has(img.src);
      
      // 如果未标记为已采集，进一步检查数据库
      if (!isAlreadyCollected && typeof chrome !== 'undefined' && chrome.runtime) {
        // 从URL中提取关键部分进行匹配
        const imgSrcKey = img.src.split('?')[0]; // 去除查询参数
        for (const collectedSrc of collectedImages) {
          const collectedSrcKey = collectedSrc.split('?')[0];
          if (imgSrcKey === collectedSrcKey) {
            isAlreadyCollected = true;
            break;
          }
          
          // 文件名匹配
          const imgFileName = imgSrcKey.split('/').pop();
          const collectedFileName = collectedSrcKey.split('/').pop();
          if (imgFileName && collectedFileName && imgFileName === collectedFileName) {
            isAlreadyCollected = true;
            break;
          }
        }
      }
      
      const button = document.createElement('div');
      button.className = isAlreadyCollected ? 'temu-collect-btn collected' : 'temu-collect-btn';
      button.innerHTML = isAlreadyCollected ? '已采集' : '采集';
      button.dataset.index = index;
      button.dataset.imgSrc = img.src;
      
      button.style.position = 'absolute';
      button.style.top = '5px';
      button.style.right = '5px';
      button.style.zIndex = '999999';
      
      // 预采集商品信息（同步执行）
      preCollectProductInfo(img, index);
      
      if (!isAlreadyCollected) {
        // 增强点击事件绑定的可靠性
        const handleClick = async (e) => {
          e.preventDefault();
          e.stopPropagation();
          console.log('🎯 采集按钮点击事件触发，尝试执行采集操作');
          try {
            await handleCollectFast(button, img, index);
          } catch (error) {
            console.error('采集按钮点击处理异常:', error);
            // 提供错误反馈
            button.innerHTML = '点击错误';
            button.style.background = '#dc3545 !important';
            // 3秒后恢复按钮状态
            setTimeout(() => {
              if (!collectedImages.has(img.src)) {
                button.innerHTML = '采集';
                button.style.background = '';
              }
            }, 3000);
          }
        };
        
        button.onclick = handleClick;
        // 添加触摸事件支持，确保移动设备上也能正常工作
        button.ontouchend = handleClick;
      }
      
      // 找到商品卡容器并添加按钮
      let buttonAdded = false;
      
      try {
        // 如果传入了productCard，则优先使用它
        if (productCard && !buttonAdded) {
          productCard.style.position = 'relative';
          productCard.appendChild(button);
          buttonAdded = true;
        } else {
          // 否则使用选择器逻辑查找容器
          const selectors = [
            '[role="button"]',
            '[class*="_3ZME5MBZ"]',
            '.goods-img-external',
            '[class*="product"]',
            '[class*="item"]',
            '[class*="card"]'
          ];
          
          for (const selector of selectors) {
            const container = img.closest(selector);
            if (container && !buttonAdded) {
              container.style.position = 'relative';
              container.appendChild(button);
              buttonAdded = true;
              break;
            }
          }
          
          if (!buttonAdded) {
            const parent = img.parentElement;
            if (parent) {
              parent.style.position = 'relative';
              parent.appendChild(button);
              buttonAdded = true;
            }
          }
        }
      } catch (error) {
        console.error('添加按钮失败:', error);
      }
      
      if (buttonAdded) {
        img.temuCollectButton = button;
        return button;
      }
      
    } catch (error) {
      console.error('创建按钮失败:', error);
    }
    
    return null;
  }

  // 快速采集处理（预采集版本） - 增强版
  async function handleCollectFast(button, img, index) {
    console.log('🎯 单点采集触发，当前batchSuccessCount:', batchSuccessCount);
    
    // 检查图片和按钮是否有效
    if (!img || !button || !document.contains(img) || !document.contains(button)) {
      console.error('❌ 采集失败: 图片或按钮元素无效或已从DOM中移除');
      if (button) {
        button.innerHTML = '元素无效';
        button.style.background = '#dc3545 !important';
        setTimeout(() => {
          button.innerHTML = '采集';
          button.style.background = '';
        }, 2000);
      }
      return;
    }
    
    // 检查是否已采集
    if (collectedImages.has(img.src)) {
      console.log('⚠️ 商品已采集，跳过重复采集');
      if (button && !button.classList.contains('collected')) {
        button.innerHTML = '已采集';
        button.className = 'temu-collect-btn collected';
        button.onclick = null;
        button.ontouchend = null;
        // 强制应用已采集样式
        button.style.background = '#28a745 !important';
        button.style.color = 'white !important';
        button.style.cursor = 'default !important';
        button.style.pointerEvents = 'none !important';
      }
      return;
    }
    
    // 更新按钮状态为采集中
    button.innerHTML = '采集中';
    button.style.background = '#ffc107 !important'; // 使用黄色表示处理中
    
    try {
      const cachedData = preCollectedData.get(img.src);
      const productInfo = cachedData || {
        title: img.alt || img.title || '商品',
        img: img.src,
        url: window.location.href
      };
      
      // 预先标记为已采集，防止重复点击
      collectedImages.add(img.src);
      
      const galleryItem = {
        id: cachedData ? cachedData.id : `single_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        src: img.src,
        title: productInfo.title,
        sourceUrl: productInfo.url || window.location.href,
        addedAt: cachedData ? cachedData.timestamp : Date.now(),
        type: 'collected',
        category: '单点采集',
        status: 'collected'
      };
    
        // 🔧 改进的扩展通信处理 - 增强错误恢复能力
        if (typeof chrome !== 'undefined' && chrome.runtime) {
          try {
            // 检查扩展上下文是否有效
            if (chrome.runtime.id) {
              const collectData = {
                id: galleryItem.id,
                title: galleryItem.title,
                img: galleryItem.src,
                url: galleryItem.sourceUrl,
                timestamp: galleryItem.addedAt,
                method: 'single'
              };
              
              console.log('📤 发送单点采集数据:', collectData);
              
              // 使用Promise.race添加超时处理，防止通信阻塞
              const timeoutPromise = new Promise((_, reject) => 
                setTimeout(() => reject(new Error('通信超时')), 3000)
              );
              
              const messagePromise = new Promise((resolve, reject) => {
                chrome.runtime.sendMessage({
                  action: 'collectProduct',
                  data: collectData
                }).then(response => {
                  resolve(response);
                }).catch(error => {
                  reject(error);
                });
              });
              
              try {
                const response = await Promise.race([messagePromise, timeoutPromise]);
                if (response && response.success !== false) {
                  console.log('✅ 单点采集数据已保存到IndexedDB');
                  // 更新成功采集计数并刷新UI显示
                  batchSuccessCount++;
                  console.log('📈 成功采集计数已更新:', batchSuccessCount);
                  updateStatusPanel();
                } else {
                  console.error('单点采集保存失败:', response?.error || '未知错误');
                  // 即使保存失败，也保持按钮为已采集状态，避免重复点击
                }
              } catch (error) {
                console.error('发送采集消息失败或超时:', error);
                if (error.message && error.message.includes('Extension context invalidated')) {
                  console.warn('⚠️ 扩展上下文已失效，请刷新页面或重新加载扩展');
                  button.innerHTML = '需刷新';
                  button.style.background = '#ffa500 !important';
                  button.title = '扩展需要刷新，请重新加载页面';
                } else if (error.message === '通信超时') {
                  console.warn('⚠️ 采集通信超时，数据可能已保存');
                  button.innerHTML = '超时';
                  button.style.background = '#ffc107 !important';
                  setTimeout(() => {
                    button.innerHTML = '已采集';
                    button.style.background = '#28a745 !important';
                  }, 1500);
                } else {
                  console.error('扩展通信异常:', error);
                  // 提供用户反馈但保持已采集状态
                  button.innerHTML = '通信异常';
                  button.style.background = '#ff6b6b !important';
                }
              }
            } else {
              console.warn('⚠️ 扩展上下文无效，无法保存数据');
              button.innerHTML = '需刷新';
              button.style.background = '#ffa500 !important';
              button.title = '扩展需要刷新，请重新加载页面';
            }
          } catch (error) {
            console.error('扩展API调用异常:', error);
            // 即使API调用失败，也保持已采集状态，避免重复点击
          }
        } else {
          console.warn('⚠️ Chrome扩展API不可用');
          button.innerHTML = 'API不可用';
          button.style.background = '#6c757d !important';
        }
      
      // 最后统一更新按钮状态为已采集，确保用户体验一致性
      if (document.contains(button) && !button.classList.contains('collected')) {
        button.innerHTML = '已采集';
        button.className = 'temu-collect-btn collected';
        button.onclick = null;
        button.ontouchend = null;
        // 强制应用已采集样式
        button.style.background = '#28a745 !important';
        button.style.color = 'white !important';
        button.style.cursor = 'default !important';
        button.style.pointerEvents = 'none !important';
      }
    } catch (error) {
      console.error('整个采集过程发生未捕获异常:', error);
      // 确保在任何情况下都能更新按钮状态
      if (button && document.contains(button)) {
        button.innerHTML = '采集失败';
        button.style.background = '#dc3545 !important';
        button.title = '采集失败: ' + (error.message || '未知错误');
        // 从已采集集合中移除，允许用户重试
        if (collectedImages.has(img.src)) {
          collectedImages.delete(img.src);
        }
        // 2秒后恢复按钮状态
        setTimeout(() => {
          if (button && document.contains(button) && !collectedImages.has(img.src)) {
            button.innerHTML = '采集';
            button.style.background = '';
            // 重新绑定点击事件
            const handleClick = async (e) => {
              e.preventDefault();
              e.stopPropagation();
              await handleCollectFast(button, img, index);
            };
            button.onclick = handleClick;
            button.ontouchend = handleClick;
          }
        }, 2000);
      }
    }
  }

  // 创建状态面板
  function createStatusPanel() {
    // 先检查是否已存在面板，如果有则先移除
    const existingPanel = document.getElementById('temu-status-panel');
    if (existingPanel) {
      console.log('⚠️ 检测到已存在的面板，先移除它');
      try {
        existingPanel.remove();
      } catch (error) {
        console.error('移除旧面板失败:', error);
      }
    }

    const panel = document.createElement('div');
    panel.id = 'temu-status-panel';
    panel.style.cssText = `
      position: fixed;
      top: 50%;
      right: 20px;
      transform: translateY(-50%);
      background: rgba(0, 0, 0, 0.9);
      color: white;
      padding: 15px;
      border-radius: 8px;
      font-size: 14px;
      z-index: 999998;
      font-family: Arial, sans-serif;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
      max-width: 280px;
      line-height: 1.4;
    `;
    
    // 默认使用单采版UI，确保成功采集统计始终显示
    console.log('🎨 创建默认单采版UI');
    panel.innerHTML = `
      <div style="font-weight: bold; margin-bottom: 10px; color: #ff6700;">🔥 TEMU采集器（单采版）</div>
      <div style="margin-bottom: 8px;">📊 采集统计：</div>
      <div style="margin-bottom: 10px;">✅ 成功采集: <span id="success-count">0</span> 个</div>
      <div style="font-size: 12px; color: #ccc;">
        ⌨️ 快捷键：<br>
        • 悬停商品卡时按 <strong style="color: #ff6700;">A</strong> 键单点采集
      </div>
    `;
    
    // 先添加到页面，确保UI能立即显示
    document.body.appendChild(panel);
    
    // 立即更新成功采集数量
    updateStatusPanel();
    
    // 然后获取实际版本信息进行可能的更新
    if (typeof chrome !== 'undefined' && chrome.runtime) {
      chrome.runtime.sendMessage({ action: 'getPluginVersion' }, (response) => {
        const isSingleVersion = response && response.isSingleVersion;
        
        if (isSingleVersion) {
            console.log('🔍 检测到单采版，显示简化UI并启用成功采集统计');
            // 单采版：显示单点采集相关内容和成功采集统计
            panel.innerHTML = `
              <div style="font-weight: bold; margin-bottom: 10px; color: #ff6700;">🔥 TEMU采集器（单采版）</div>
              <div style="margin-bottom: 8px;">📊 采集统计：</div>
              <div style="margin-bottom: 10px;">✅ 成功采集: <span id="success-count">0</span> 个</div>
              <div style="font-size: 12px; color: #ccc;">
                ⌨️ 快捷键：<br>
                • 悬停商品卡时按 <strong style="color: #ff6700;">A</strong> 键单点采集
              </div>
            `;
          } else {
            console.log('🔍 检测到批采版，显示完整功能UI');
            // 批采版：显示完整功能
            panel.innerHTML = `
            <div style="font-weight: bold; margin-bottom: 10px; color: #ff6700;">🔥 TEMU采集器</div>
            <div style="margin-bottom: 8px;">📊 批量采集统计：</div>
            <div style="margin-bottom: 5px;">✅ 成功采集: <span id="success-count">0</span> 个</div>
            <div style="margin-bottom: 5px;">👁️ 已浏览: <span id="viewed-count">0</span> 个</div>
            <div style="margin-bottom: 10px; padding: 8px 0; border-top: 1px solid #333;">
              <button id="record-btn" style="
                background: #ff6700;
                color: white;
                border: none;
                padding: 6px 12px;
                border-radius: 4px;
                cursor: pointer;
                font-size: 12px;
                margin-right: 8px;
              ">开始记录</button>
              <button id="save-btn" style="
                  background: #28a745;
                  color: white;
                  border: none;
                  padding: 6px 12px;
                  border-radius: 4px;
                  cursor: pointer;
                  font-size: 12px;
                  opacity: 0.5;
                " disabled>批量采集</button>
            </div>
            <div style="font-size: 12px; color: #ccc;">
              ⌨️ 快捷键：<br>
              • 按 <strong style="color: #ff6700;">S</strong> 键批量采集<br>
              • 悬停商品卡时按 <strong style="color: #ff6700;">A</strong> 键单点采集
            </div>
          `;
        }
        
        // 如果是批采版，更新UI
        if (!isSingleVersion) {
          console.log('🔄 更新为批采版UI');
          panel.innerHTML = `
            <div style="font-weight: bold; margin-bottom: 10px; color: #ff6700;">🔥 TEMU采集器</div>
            <div style="margin-bottom: 8px;">📊 批量采集统计：</div>
            <div style="margin-bottom: 5px;">✅ 成功采集: <span id="success-count">0</span> 个</div>
            <div style="margin-bottom: 5px;">👁️ 已浏览: <span id="viewed-count">0</span> 个</div>
            <div style="margin-bottom: 10px; padding: 8px 0; border-top: 1px solid #333;">
              <button id="record-btn" style="
                background: #ff6700;
                color: white;
                border: none;
                padding: 6px 12px;
                border-radius: 4px;
                cursor: pointer;
                font-size: 12px;
                margin-right: 8px;
              ">开始记录</button>
              <button id="save-btn" style="
                  background: #28a745;
                  color: white;
                  border: none;
                  padding: 6px 12px;
                  border-radius: 4px;
                  cursor: pointer;
                  font-size: 12px;
                  opacity: 0.5;
                " disabled>批量采集</button>
            </div>
            <div style="font-size: 12px; color: #ccc;">
              ⌨️ 快捷键：<br>
              • 按 <strong style="color: #ff6700;">S</strong> 键批量采集<br>
              • 悬停商品卡时按 <strong style="color: #ff6700;">A</strong> 键单点采集
            </div>
          `;
          // 初始化批量采集相关事件
          initPanelEvents();
        }
        
        // 更新透明度
        setTimeout(() => {
          panel.style.opacity = '0.8';
        }, 3000);
      });
    } else {
      // 如果无法获取版本信息，默认显示批采版
      panel.innerHTML = `
        <div style="font-weight: bold; margin-bottom: 10px; color: #ff6700;">🔥 TEMU采集器</div>
        <div style="margin-bottom: 8px;">📊 批量采集统计：</div>
        <div style="margin-bottom: 5px;">✅ 成功采集: <span id="success-count">0</span> 个</div>
        <div style="margin-bottom: 5px;">👁️ 已浏览: <span id="viewed-count">0</span> 个</div>
        <div style="margin-bottom: 10px; padding: 8px 0; border-top: 1px solid #333;">
          <button id="record-btn" style="
            background: #ff6700;
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            margin-right: 8px;
          ">开始记录</button>
          <button id="save-btn" style="
              background: #28a745;
              color: white;
              border: none;
              padding: 6px 12px;
              border-radius: 4px;
              cursor: pointer;
              font-size: 12px;
              opacity: 0.5;
            " disabled>批量采集</button>
        </div>
        <div style="font-size: 12px; color: #ccc;">
          ⌨️ 快捷键：<br>
          • 按 <strong style="color: #ff6700;">S</strong> 键批量采集<br>
          • 悬停商品卡时按 <strong style="color: #ff6700;">A</strong> 键单点采集
        </div>
      `;
      
      document.body.appendChild(panel);
      initPanelEvents();
      
      setTimeout(() => {
        panel.style.opacity = '0.8';
      }, 3000);
    }
    
    // 提取面板事件初始化到函数中
    function initPanelEvents() {
      setTimeout(() => {
        const recordBtn = document.getElementById('record-btn');
        const saveBtn = document.getElementById('save-btn');
        
        if (recordBtn) {
          recordBtn.addEventListener('click', toggleRecording);
        }
        
        if (saveBtn) {
           saveBtn.addEventListener('click', async () => {
             try {
               await batchCollectImages();
             } catch (error) {
               console.error('批量采集按钮点击错误:', error);
             }
           });
         }
      }, 100);
    }
    
    setTimeout(() => {
      const recordBtn = document.getElementById('record-btn');
      const saveBtn = document.getElementById('save-btn');
      
      if (recordBtn) {
        recordBtn.addEventListener('click', toggleRecording);
      }
      
      if (saveBtn) {
         saveBtn.addEventListener('click', async () => {
           try {
             await batchCollectImages();
           } catch (error) {
             console.error('批量采集按钮点击错误:', error);
           }
         });
       }
    }, 100);
    
    setTimeout(() => {
      panel.style.opacity = '0.8';
    }, 3000);
    
    return panel;
  }

  // 全局统计变量
  
  // 销毁状态面板函数（代码中引用但之前未定义）
  function destroyStatusPanel() {
    try {
      const panel = document.getElementById('temu-status-panel');
      if (panel && document.body.contains(panel)) {
        panel.remove();
        console.log('✅ 状态面板已销毁');
      }
    } catch (error) {
      console.error('销毁状态面板失败:', error);
    }
  }
  let batchSuccessCount = 0;
  let batchFailCount = 0;
  
  // 从画廊加载已采集的图片数据
  async function loadCollectedImagesFromGallery() {
    try {
      // 直接从IndexedDB获取所有已采集的商品
      if (typeof chrome !== 'undefined' && chrome.runtime) {
        return new Promise((resolve) => {
          chrome.runtime.sendMessage({
            action: 'getAllProducts'
          }, (response) => {
            if (response && response.products) {
              const collectedSrcs = new Set();
              response.products.forEach(item => {
                if (item.img) {
                  collectedSrcs.add(item.img);
                }
              });
              console.log(`📚 从IndexedDB加载了 ${collectedSrcs.size} 个已采集图片`);
              resolve(collectedSrcs);
            } else {
              // 备用方案：从localStorage加载
              const existingData = JSON.parse(localStorage.getItem('temuGalleryItems') || '[]');
              const collectedSrcs = new Set();
              
              existingData.forEach(item => {
                if (item.src) {
                  collectedSrcs.add(item.src);
                }
              });
              
              console.log(`📚 从localStorage加载了 ${collectedSrcs.size} 个已采集图片`);
              resolve(collectedSrcs);
            }
          });
        });
      } else {
        const existingData = JSON.parse(localStorage.getItem('temuGalleryItems') || '[]');
        const collectedSrcs = new Set();
        
        existingData.forEach(item => {
          if (item.src) {
            collectedSrcs.add(item.src);
          }
        });
        
        console.log(`📚 从localStorage加载了 ${collectedSrcs.size} 个已采集图片`);
        return collectedSrcs;
      }
    } catch (error) {
      console.error('加载已采集图片失败:', error);
      return new Set();
    }
  }

  // 更新状态面板
  function updateStatusPanel() {
    const successCountEl = document.getElementById('success-count');
    console.log('🔄 更新状态面板 - batchSuccessCount:', batchSuccessCount, '找到元素:', !!successCountEl);
    const viewedCountEl = document.getElementById('viewed-count');
    
    if (successCountEl) {
      successCountEl.textContent = batchSuccessCount;
    }
    
    if (viewedCountEl) {
      viewedCountEl.textContent = viewedImages.size;
    }
  }

  // 切换记录状态
  function toggleRecording() {
    const recordBtn = document.getElementById('record-btn');
    const saveBtn = document.getElementById('save-btn');
    
    if (!isRecording) {
      isRecording = true;
      recordingStartTime = Date.now();
      
      if (recordBtn) {
        recordBtn.textContent = '停止记录';
        recordBtn.style.background = '#28a745';
      }
      
      if (saveBtn) {
        saveBtn.style.opacity = '1';
        saveBtn.disabled = false;
      }
      
      console.log('🎬 开始记录浏览图片（累加模式）');
      startImageTracking(); // REVERT: Start scroll and interval tracking
    } else {
      isRecording = false;
      
      if (recordBtn) {
        recordBtn.textContent = '开始记录';
        recordBtn.style.background = '#ff6700';
      }
      
      console.log(`🛑 停止记录，共记录了 ${viewedImages.size} 个图片`);
      stopImageTracking(); // REVERT: Stop scroll and interval tracking
    }
    
    updateStatusPanel();
  }

  // REVERT: Add back the image tracking functions
  // 开始图片追踪
  function startImageTracking() {
    window.addEventListener('scroll', checkVisibleImages, { passive: true });
    checkVisibleImages(); // Initial check
    window.imageTrackingInterval = setInterval(checkVisibleImages, 1000);
  }
  
  // 停止图片追踪
  function stopImageTracking() {
    window.removeEventListener('scroll', checkVisibleImages);
    if (window.imageTrackingInterval) {
      clearInterval(window.imageTrackingInterval);
      window.imageTrackingInterval = null;
    }
  }
  
  // 检查可见图片
  function checkVisibleImages() {
    if (!isRecording) return;
    
    const images = findProductImages(); // Use the global find function
    
    images.forEach(img => {
      const rect = img.getBoundingClientRect();
      const isVisible = rect.top >= 0 && rect.bottom <= window.innerHeight;
      
      if (isVisible && !viewedImages.has(img.src)) {
        console.log('👁️ New image in view:', img.src);
        viewedImages.add(img.src);
        updateStatusPanel();
      }
    });
  }

  // ==================================================================================
  // 自动创建按钮 (始终运行)
  // ==================================================================================
  let isProcessingNode = false;
  let nodesToProcessQueue = [];
  let animationFrameId = null;

  function processButtonQueue() {
    if (nodesToProcessQueue.length === 0) {
      animationFrameId = null;
      return;
    }

    isProcessingNode = true;
    const nodes = nodesToProcessQueue.shift(); // Process one batch of nodes

    try {
      const images = findProductImages(nodes);
      if (images.length > 0) {
        images.forEach((img, index) => {
          try {
            const productCard = img.closest('[role="button"], [class*="_3ZME5MBZ"], .goods-img-external');
            if (productCard && !productCard.querySelector('.temu-collect-btn')) {
              // 传递productCard参数，确保按钮创建过程中能正确引用
              createCollectButtonFast(img, index, productCard);
            }
          } catch (error) {
            console.error('为单个图片创建采集按钮时出错:', error);
            // 继续处理下一个图片，不中断整个队列
          }
        });
      }
    } catch (error) {
      console.error('处理按钮队列时出错:', error);
    } finally {
      isProcessingNode = false;
      // Continue processing the queue in the next frame if needed
      if (nodesToProcessQueue.length > 0) {
        animationFrameId = requestAnimationFrame(processButtonQueue);
      } else {
        animationFrameId = null;
      }
    }
  }

  function addCollectButtonsToNodes(elements) {
    if (!elements || elements.length === 0) return;
    nodesToProcessQueue.push(elements);
    if (!animationFrameId) {
      animationFrameId = requestAnimationFrame(processButtonQueue);
    }
  }

  const buttonCreationObserver = new MutationObserver((mutationsList) => {
    let addedNodes = [];
    for (const mutation of mutationsList) {
      if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
        for (const node of mutation.addedNodes) {
          if (node.nodeType === Node.ELEMENT_NODE && !node.closest('#status-panel-container, .temu-collect-btn')) {
            addedNodes.push(node);
          }
        }
      }
    }
    if (addedNodes.length > 0) {
      addCollectButtonsToNodes(addedNodes);
    }
  });

  function initializeButtonCreation() {
    console.log('🚀 Initializing automatic button creation...');
    addCollectButtonsToNodes([document.body]);
    buttonCreationObserver.observe(document.body, { childList: true, subtree: true });
    console.log('✅ Automatic button creation is now active.');
  }

  // ==================================================================================


  // 批量采集浏览过但未采集的图片
  async function batchCollectImages() {
    try {
      console.log('🔄 开始批量采集...');
      console.log('当前浏览图片数量:', viewedImages.size);
      console.log('已采集图片数量:', collectedImages.size);
      
      if (viewedImages.size === 0) {
        alert('没有记录到浏览过的图片！请先点击"开始记录"并浏览一些商品图片。');
        return;
      }
      
      const uncollectedImages = Array.from(viewedImages).filter(src => !collectedImages.has(src));
      
      console.log('未采集的浏览图片数量:', uncollectedImages.length);
      
      if (uncollectedImages.length === 0) {
         alert('所有浏览过的图片都已采集，没有新图片需要批量采集！');
         return;
       }
      
      const currentTime = Date.now();
      let successCount = 0;
      let failCount = 0;
      
      console.log('🚀 开始批量采集', uncollectedImages.length, '个图片...');
      
      const batchPromises = uncollectedImages.map(async (src, i) => {
        try {
          const cachedData = preCollectedData.get(src);
          let productTitle = cachedData ? cachedData.title : `批量采集 ${i + 1}`;
          let imgAlt = cachedData ? cachedData.imgAlt : '';
          
          if (!cachedData) {
            try {
              let imgElement = document.querySelector(`img[src="${src}"]`);
              
              if (!imgElement) {
                const allImages = document.querySelectorAll('img');
                for (const img of allImages) {
                  if (img.src === src) {
                    imgElement = img;
                    break;
                  }
                }
              }
              
              if (imgElement) {
                if (imgElement.alt && imgElement.alt.length > 5) {
                  imgAlt = imgElement.alt;
                }
                
                const productCard = imgElement.closest('[role="button"], [class*="_3ZME5MBZ"], .goods-img-external');
                if (productCard) {
                  const titleEl = productCard.querySelector('h1, h2, h3, [class*="title"]');
                  if (titleEl && titleEl.textContent.trim().length > 10) {
                    productTitle = titleEl.textContent.trim();
                  }
                }
              }
            } catch (error) {
              console.warn('简单获取商品信息失败:', error);
            }
          }
          
          const collectData = {
            id: `batch_${currentTime}_${i}`,
            title: productTitle,
            img: src,
            imgAlt: imgAlt,
            url: window.location.href,
            timestamp: currentTime,
            method: 'batch'
          };
          
          let collectSuccess = false;
          
          if (typeof chrome !== 'undefined' && chrome.runtime) {
            try {
              const response = await chrome.runtime.sendMessage({
                action: 'collectProduct',
                data: collectData
              });
              collectSuccess = response && response.success !== false;
            } catch (error) {
              console.warn(`批量采集第${i+1}个图片扩展通信失败:`, error);
              collectSuccess = true;
            }
          } else {
            collectSuccess = true;
          }
          
          if (collectSuccess) {
            const galleryItem = {
              id: collectData.id,
              src: collectData.img,
              title: collectData.title,
              sourceUrl: collectData.url,
              addedAt: collectData.timestamp,
              type: 'collected',
              category: '批量采集',
              status: 'batch_collected'
            };
            
            collectedImages.add(src);
            
            // 🎯 改进的按钮状态更新逻辑
            console.log(`🔍 查找图片 ${src} 对应的按钮...`);
            
            // 方法1: 通过DOM查找所有相关按钮
            const allButtons = document.querySelectorAll('.temu-collect-btn:not(.collected)');
            console.log(`📋 找到 ${allButtons.length} 个未采集的按钮`);
            
            let updatedButtons = 0;
            
            // 遍历所有按钮，通过dataset.imgSrc匹配
            allButtons.forEach(button => {
              const buttonImgSrc = button.dataset.imgSrc;
              if (buttonImgSrc) {
                // 精确匹配
                if (buttonImgSrc === src) {
                  updateButtonToCollected(button);
                  updatedButtons++;
                  console.log(`✅ 精确匹配更新按钮: ${src}`);
                  return;
                }
                
                // 参数忽略匹配
                const cleanSrc = src.split('?')[0];
                const cleanButtonSrc = buttonImgSrc.split('?')[0];
                if (cleanSrc === cleanButtonSrc) {
                  updateButtonToCollected(button);
                  updatedButtons++;
                  console.log(`✅ 参数忽略匹配更新按钮: ${cleanSrc}`);
                  return;
                }
                
                // 文件名匹配
                const srcFileName = cleanSrc.split('/').pop();
                const buttonFileName = cleanButtonSrc.split('/').pop();
                if (srcFileName && buttonFileName && srcFileName === buttonFileName && srcFileName.length > 8) {
                  updateButtonToCollected(button);
                  updatedButtons++;
                  console.log(`✅ 文件名匹配更新按钮: ${srcFileName}`);
                  return;
                }
              }
            });
            
            // 方法2: 通过collectButtons数组查找（备用）
            if (updatedButtons === 0) {
              const correspondingButton = collectButtons.find(buttonData => {
                if (!buttonData.img || !buttonData.img.src) return false;
                
                // 精确匹配
                if (buttonData.img.src === src) return true;
                
                // 参数忽略匹配
                const cleanSrc = src.split('?')[0];
                const cleanImgSrc = buttonData.img.src.split('?')[0];
                if (cleanSrc === cleanImgSrc) return true;
                
                // 文件名匹配
                const srcFileName = cleanSrc.split('/').pop();
                const imgFileName = cleanImgSrc.split('/').pop();
                return srcFileName && imgFileName && srcFileName === imgFileName && srcFileName.length > 8;
              });
              
              if (correspondingButton && correspondingButton.button) {
                updateButtonToCollected(correspondingButton.button);
                updatedButtons++;
                console.log(`✅ 通过数组匹配更新按钮`);
              }
            }
            
            console.log(`📊 批量采集第${i+1}个: 更新了 ${updatedButtons} 个按钮状态`);
            
            // 按钮状态更新函数
            function updateButtonToCollected(button) {
              button.innerHTML = '已采集';
              button.className = 'temu-collect-btn collected';
              button.onclick = null;
              
              // 强制应用已采集样式
              button.style.background = '#28a745 !important';
              button.style.color = 'white !important';
              button.style.cursor = 'default !important';
              button.style.pointerEvents = 'none !important';
            }
            
            return { success: true, index: i + 1, src: src };
          } else {
            return { success: false, index: i + 1, src: src };
          }
          
        } catch (error) {
          console.error(`批量采集第${i+1}个图片失败:`, error);
          return { success: false, index: i + 1, error };
        }
      });
      
      const results = await Promise.all(batchPromises);
      
      results.forEach(result => {
        if (result.success) {
          successCount++;
          batchSuccessCount++;
        } else {
          failCount++;
          batchFailCount++;
        }
      });
      
      console.log(`🎉 批量采集完成！成功: ${successCount} 个，失败: ${failCount} 个`);
      
      updateStatusPanel();
      
      if (typeof chrome !== 'undefined' && chrome.runtime) {
        chrome.runtime.sendMessage({
          action: 'galleryUpdated',
          newItemsCount: successCount,
          type: 'batch_collected'
        }).catch(err => console.warn('通知画廊更新失败:', err));
      }
      
      if (successCount > 0) {
        console.log(`✅ 批量采集完成！成功采集: ${successCount} 个图片，失败: ${failCount} 个图片，已排除: ${collectedImages.size} 个已采集的图片`);
      } else {
        console.log(`❌ 批量采集失败！所有 ${uncollectedImages.length} 个图片都采集失败`);
      }
      
    } catch (error) {
       console.error('❌ 批量采集时发生错误:', error);
       alert(`批量采集失败：${error.message}`);
     }
  }

  // 清理无效按钮
  function cleanupButtons() {
    const validButtons = [];
    const toRemove = [];
    
    collectButtons.forEach(buttonData => {
      if (!buttonData.button.parentNode || !document.contains(buttonData.img)) {
        toRemove.push(buttonData);
      } else {
        validButtons.push(buttonData);
      }
    });
    
    toRemove.forEach(buttonData => {
      if (buttonData.button.parentNode) {
        buttonData.button.parentNode.removeChild(buttonData.button);
      }
      if (buttonData.img.temuCollectButton) {
        delete buttonData.img.temuCollectButton;
      }
    });
    
    collectButtons = validButtons;
    
    if (toRemove.length > 0) {
      console.log(`🧹 清理了 ${toRemove.length} 个按钮，剩余 ${collectButtons.length} 个`);
    }
  }

  // 设置页面变化监听
  function setupMutationObserverInstant() {
    let mutationTimer = null;
    
    const observer = new MutationObserver(() => {
      try {
        if (mutationTimer) {
          clearTimeout(mutationTimer);
        }
        
        mutationTimer = setTimeout(() => {
          try {
            if (!document.hidden && document.visibilityState === 'visible') {
              const needNewButtons = findProductImages().filter(img => 
                !img.temuCollectButton && document.contains(img)
              ).length;
              
              if (needNewButtons > 0) {
                console.log(`🔄 页面变化，立即创建 ${needNewButtons} 个新按钮`);
                createAllButtonsInstant();
              }
            }
          } catch (error) {
            console.error('MutationObserver 处理错误:', error);
            try {
              createAllButtonsInstant();
            } catch (e) {
              console.error('创建按钮失败:', e);
            }
          }
        }, 50);
      } catch (error) {
        console.error('MutationObserver 回调错误:', error);
      }
    });
    
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  // 立即创建所有按钮
  function createAllButtonsInstant() {
    try {
      let images = findProductImages();
      
      if (images.length === 0) {
        images = document.querySelectorAll('img[src*="static.kwcdn.com"], img[src*="img.kwcdn.com"], img[src*="temu.com"]');
      }
      
      const imagesToProcess = Array.from(images).filter(img => 
        !img.temuCollectButton && document.contains(img) && img.src && img.offsetWidth > 50
      );
      
      if (imagesToProcess.length === 0) return;
      
      imagesToProcess.forEach((img, index) => {
        try {
          const button = createCollectButtonFast(img, index);
          if (button) {
            collectButtons.push({ button, img, index });
          }
        } catch (error) {
          console.error('创建按钮失败:', error);
        }
      });
      
    } catch (error) {
      console.error('批量创建按钮失败:', error);
    }
  }

  // 初始化（兼容性增强版本）
  async function initialize() {
    // 检查插件是否过期
    if (isPluginExpired) {
      console.log('⚠️ 插件已过期，无法初始化');
      return;
    }
    
    // 检查插件是否激活
    if (!isActivated) {
      console.log('⚠️ 插件未激活，无法初始化');
      return;
    }
    
    try {
      if (!document || !document.body) {
        throw new Error('DOM未准备好');
      }
      
      if (!window.location.href.includes('temu.com')) {
        throw new Error('不在TEMU页面');
      }
      
      // 如果已经初始化，只更新必要的内容，不重新创建面板
      if (isInitialized) {
        console.log('✅ 插件已初始化，只更新必要内容');
        
        // 加载最新的已采集图片数据
        const galleryCollectedImages = await loadCollectedImagesFromGallery();
        galleryCollectedImages.forEach(src => collectedImages.add(src));
        
        // 更新统计信息
        updateStatusPanel();
        
        // 确保所有可见图片都有采集按钮
        createAllButtonsInstant();
        
        return;
      }
      
      createStyleSheet();
    
      const galleryCollectedImages = await loadCollectedImagesFromGallery();
      galleryCollectedImages.forEach(src => collectedImages.add(src));
    
      console.log('📋 开始创建状态面板...');
      createStatusPanel();
      console.log('📋 状态面板创建完成');
    
      console.log('🔘 开始创建采集按钮...');
      createAllButtonsInstant();
      console.log('🔘 采集按钮创建完成');
    
      setupMutationObserverInstant();
      
      // 添加键盘快捷键监听
      setupKeyboardShortcuts();
    
      let updateCounter = 0;
      setInterval(() => {
        try {
          // 检查插件是否过期
          if (isPluginExpired) {
            console.log('⚠️ 插件已过期，停止更新');
            return;
          }
          
          // 检查插件是否激活
          if (!isActivated) {
            console.log('⚠️ 插件未激活，停止更新');
            return;
          }
          
          if (!document.hidden && document.visibilityState === 'visible') {
            updateCounter++;
          
            if (updateCounter % 15 === 0) {
              cleanupButtons();
            }
          
            if (updateCounter % 10 === 0) {
              const needNewButtons = findProductImages().filter(img => 
                !img.temuCollectButton && document.contains(img)
              ).length;
            
              if (needNewButtons > 0) {
                createAllButtonsInstant();
              }
            }
          
            if (updateCounter % 5 === 0) {
              updateStatusPanel();
            }
          }
        } catch (error) {
          console.error('维护任务失败:', error);
        }
      }, 3000);
    
      isInitialized = true;
      
    } catch (error) {
      console.error('初始化失败:', error);
      
      setTimeout(() => {
        try {
          // 检查插件是否过期
          if (isPluginExpired) {
            console.log('⚠️ 插件已过期，无法恢复');
            return;
          }
          
          // 检查插件是否激活
          if (!isActivated) {
            console.log('⚠️ 插件未激活，无法恢复');
            return;
          }
          
          createStyleSheet();
          createAllButtonsInstant();
        } catch (e) {
          console.error('恢复失败:', e);
        }
      }, 2000);
    }
  }

  // 设置键盘快捷键
  function setupKeyboardShortcuts() {
    // 全局变量：当前悬停的商品卡和对应的图片
    let currentHoveredCard = null;
    let currentHoveredImage = null;
    
    // 鼠标悬停检测
    document.addEventListener('mouseover', function(e) {
      // 查找最近的商品卡容器
      const productCard = e.target.closest([
        '[role="button"]',
        '[class*="_3ZME5MBZ"]', 
        '.goods-img-external',
        '[class*="product"]',
        '[class*="item"]',
        '[class*="card"]'
      ].join(', '));
      
      if (productCard) {
        // 🎯 使用与点击按钮相同的图片质量评分逻辑
        const allImages = productCard.querySelectorAll('img[src*="kwcdn"], img[src*="temu.com"]');
        let bestImage = null;
        let bestScore = 0;
        
        for (const img of allImages) {
          if (img.src && img.offsetWidth > 50 && img.naturalWidth > 200 && img.naturalHeight > 200) {
            const score = getImageQualityScore(img);
            if (score > bestScore) {
              bestScore = score;
              bestImage = img;
            }
          }
        }
        
        if (bestImage) {
          currentHoveredCard = productCard;
          currentHoveredImage = bestImage;
          
          // 添加悬停视觉提示
          productCard.style.outline = '2px solid #ff6700';
          productCard.style.outlineOffset = '2px';
          
          console.log(`🎯 悬停检测到最佳图片: ${bestImage.src}, 质量评分: ${bestScore}`);
        }
      }
    });
    
    // 鼠标离开检测
    document.addEventListener('mouseout', function(e) {
      if (currentHoveredCard && !currentHoveredCard.contains(e.relatedTarget)) {
        // 移除悬停视觉提示
        currentHoveredCard.style.outline = '';
        currentHoveredCard.style.outlineOffset = '';
        currentHoveredCard = null;
        currentHoveredImage = null;
      }
    });
    
    document.addEventListener('keydown', function(e) {
      // 排除输入框、文本域等元素
      if (document.activeElement && ['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement.tagName)) {
        return;
      }
      
      // 检查是否按下了S或s键（批量采集）
      if (e.key === 'S' || e.key === 's') {
        e.preventDefault();
        
        if (isSingleVersion) {
          console.log('🎹 检测到快捷键 S/s，但当前为单采版，不执行批量采集');
          return;
        }
        
        console.log('🎹 检测到快捷键 S/s，触发批量采集');
        
        // 触发批量采集
        batchCollectImages().catch(error => {
          console.error('快捷键触发批量采集失败:', error);
        });
      }
      
      // 检查是否按下了A或a键（单点采集）
      if ((e.key === 'A' || e.key === 'a') && currentHoveredImage && currentHoveredCard) {
        e.preventDefault();
        console.log('🎹 检测到快捷键 A/a，触发单点采集');
        console.log(`🎯 将采集图片: ${currentHoveredImage.src}`);
        
        // 🎯 使用extractBestImage函数获取最佳图片URL（与点击按钮采集一致）
        const bestImageUrl = extractBestImage(currentHoveredCard);
        const finalImage = bestImageUrl ? 
          (document.querySelector(`img[src="${bestImageUrl}"]`) || currentHoveredImage) : 
          currentHoveredImage;
        
        console.log(`🎯 最终采集图片: ${finalImage.src}`);
        
        // 查找或创建采集按钮
        let collectButton = finalImage.temuCollectButton;
        if (!collectButton) {
          // 如果按钮不存在，创建一个
          collectButton = createCollectButtonFast(finalImage, 0);
        }
        
        if (collectButton && !collectButton.classList.contains('collected')) {
          // 触发单点采集
          handleCollectFast(collectButton, finalImage, 0).catch(error => {
            console.error('快捷键触发单点采集失败:', error);
          });
        } else if (collectButton && collectButton.classList.contains('collected')) {
          console.log('⚠️ 该商品已经采集过了');
        }
      }
    });
    
    console.log('⌨️ 键盘快捷键已设置：');
    console.log('  - 按 S 或 s 键进行批量采集');
    console.log('  - 鼠标悬停商品卡时按 A 或 a 键进行单点采集');
  }

  // 启动（兼容性增强）
  function start() {
    try {
      if (typeof document === 'undefined' || !document.body) {
        console.log('⏳ 等待DOM准备...');
        setTimeout(start, 100);
        return;
      }
      
      if (!window.location.href.includes('temu.com')) {
        console.log('❌ 不在TEMU页面，跳过初始化');
        return;
      }
      
      console.log('🎯 开始初始化采集系统...');
      console.log('isInitialized状态:', isInitialized);
      console.log('页面URL检查:', window.location.href.includes('temu.com'));
      console.log('DOM body检查:', !!document.body);
      
      const initStrategies = [
        () => {
          setTimeout(async () => {
            try {
              if (!isInitialized) {
                await initialize();
              }
            } catch (error) {
              console.error('策略1初始化失败:', error);
            }
          }, 50);
        },
        
        () => {
          if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', async () => {
              try {
                if (!isInitialized) {
                  await initialize();
                }
              } catch (error) {
                console.error('策略2初始化失败:', error);
              }
            });
          }
        },
        
        () => {
          setTimeout(async () => {
            try {
              if (!isInitialized) {
                console.log('🔄 延迟重试初始化...');
                await initialize();
              }
            } catch (error) {
              console.error('策略3初始化失败:', error);
            }
          }, 1000);
        }
      ];
      
      initStrategies.forEach(strategy => {
        try {
          strategy();
        } catch (error) {
          console.error('启动策略执行失败:', error);
        }
      });
      
    } catch (error) {
      console.error('启动函数失败:', error);
      setTimeout(() => {
        try {
          start();
        } catch (e) {
          console.error('重试启动失败:', e);
        }
      }, 2000);
    }
  }
  
  // 开始执行
  initializeButtonCreation();
  start();
  
})();
