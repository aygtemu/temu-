// popup.js 新架构：IndexedDB图片存储+全屏筛选UI基础

// 检查插件激活状态和版本
function checkPluginActivation() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['pluginActivated', 'pluginVersion', 'activatedMachineCode', 'activationDate', 'expireDate'], (result) => {
      let isActivated = result.pluginActivated || false;
      const version = result.pluginVersion || 'single'; // 默认单采版
      const activatedMachineCode = result.activatedMachineCode || '';
      const activationDate = result.activationDate || '';
      const expireDate = result.expireDate || null;
      
      // 检查是否已过期
      if (isActivated && expireDate) {
        const expiry = new Date(expireDate);
        const now = new Date();
        if (now > expiry) {
          // 已过期，设置为未激活状态
          isActivated = false;
          // 更新存储中的激活状态
          chrome.storage.local.set({ pluginActivated: false }, () => {
            console.log('插件已过期，自动设置为未激活状态');
          });
        }
      }
      
      resolve({ isActivated, version, activatedMachineCode, activationDate });
    });
  });
}

// 根据版本设置UI
function setupUIByVersion(version) {
  console.log('当前插件版本:', version);
  
  // 如果是单采版，隐藏批量采集按钮
  if (version === 'single') {
    const batchCollectBtn = document.getElementById('batch-collect');
    if (batchCollectBtn) {
      batchCollectBtn.style.display = 'none';
      console.log('已隐藏批量采集按钮（单采版）');
    }
  }
}

// 如果未激活，显示激活提示
function showActivationPrompt() {
  const mainContainer = document.createElement('div');
  mainContainer.style = 'text-align: center; padding: 20px;';
  mainContainer.innerHTML = `
    <h3 style="color: #ff6700;">插件未激活</h3>
    <p style="margin: 15px 0;">请先激活插件后使用完整功能</p>
    <button id="go-to-activation" class="btn" style="background: #28a745;">去激活</button>
  `;
  
  // 清空body并添加激活提示
  document.body.innerHTML = '';
  document.body.appendChild(mainContainer);
  
  // 绑定去激活按钮事件
  document.getElementById('go-to-activation').addEventListener('click', () => {
    window.location.href = 'activation.html';
  });
}

// IndexedDB初始化（图片二进制存储预留）
let db;
function initDB() {
  // 与background/gallery保持一致：先无版本打开，缺仓库时条件升级
  return new Promise((resolve, reject) => {
    try {
      const openReq = indexedDB.open('temu_collector');

      openReq.onupgradeneeded = (e) => {
        try {
          const upgradeDb = e.target.result;
          if (!upgradeDb.objectStoreNames.contains('products')) {
            upgradeDb.createObjectStore('products', { keyPath: 'id' });
          }
          if (!upgradeDb.objectStoreNames.contains('recycle_bin')) {
            const recycleStore = upgradeDb.createObjectStore('recycle_bin', { keyPath: 'id' });
            recycleStore.createIndex('deletedAt', 'deletedAt', { unique: false });
          }
        } catch (error) {
          console.error('数据库升级失败:', error);
          reject(error);
        }
      };

      openReq.onsuccess = (e) => {
        try {
          db = e.target.result;
          const hasProducts = db.objectStoreNames.contains('products');
          const hasRecycle = db.objectStoreNames.contains('recycle_bin');
          if (hasProducts && hasRecycle) {
            resolve();
            return;
          }
          // 缺少对象仓库，主动提升版本创建
          const newVersion = (db.version || 1) + 1;
          db.close();
          const upgradeReq = indexedDB.open('temu_collector', newVersion);
          upgradeReq.onupgradeneeded = (ev) => {
            const upgradeDb = ev.target.result;
            if (!upgradeDb.objectStoreNames.contains('products')) {
              upgradeDb.createObjectStore('products', { keyPath: 'id' });
            }
            if (!upgradeDb.objectStoreNames.contains('recycle_bin')) {
              const recycleStore = upgradeDb.createObjectStore('recycle_bin', { keyPath: 'id' });
              recycleStore.createIndex('deletedAt', 'deletedAt', { unique: false });
            }
          };
          upgradeReq.onsuccess = (ev) => {
            db = ev.target.result;
            resolve();
          };
          upgradeReq.onerror = (ev) => {
            console.error('数据库升级打开失败:', ev.target?.error || ev);
            reject(ev.target?.error || ev);
          };
        } catch (successErr) {
          console.error('初始化数据库成功回调处理失败:', successErr);
          reject(successErr);
        }
      };

      openReq.onerror = (e) => {
        const err = e.target?.error || e;
        console.error('数据库打开失败:', err);
        if (err && (err.name === 'UnknownError' || err.name === 'AbortError')) {
          try {
            console.warn('尝试删除损坏的数据库并重新初始化...');
            const delReq = indexedDB.deleteDatabase('temu_collector');
            delReq.onsuccess = () => {
              console.log('数据库删除成功，重新创建...');
              const reopenReq = indexedDB.open('temu_collector');
              reopenReq.onupgradeneeded = (ev) => {
                try {
                  const upgradeDb = ev.target.result;
                  if (!upgradeDb.objectStoreNames.contains('products')) {
                    upgradeDb.createObjectStore('products', { keyPath: 'id' });
                  }
                  if (!upgradeDb.objectStoreNames.contains('recycle_bin')) {
                    const recycleStore = upgradeDb.createObjectStore('recycle_bin', { keyPath: 'id' });
                    recycleStore.createIndex('deletedAt', 'deletedAt', { unique: false });
                  }
                } catch (upgradeErr) {
                  console.error('数据库升级失败:', upgradeErr);
                  reject(upgradeErr);
                }
              };
              reopenReq.onsuccess = (re) => {
                db = re.target.result;
                resolve();
              };
              reopenReq.onerror = (re) => {
                console.error('数据库重新打开失败:', re.target?.error || re);
                reject(re.target?.error || re);
              };
            };
            delReq.onerror = (delErrEvt) => {
              console.error('删除数据库失败:', delErrEvt.target?.error || delErrEvt);
              reject(err);
            };
          } catch (delErr) {
            console.error('删除数据库异常:', delErr);
            reject(err);
          }
        } else {
          reject(err);
        }
      };
    } catch (err) {
      console.error('初始化数据库异常:', err);
      reject(err);
    }
  });
}

// 渲染缩略图列表
function renderList(products) {
  const list = document.getElementById('list');
  list.innerHTML = '';
  if (!products.length) {
    list.innerHTML = '<p>暂无采集数据</p>';
    return;
  }
  products.forEach(item => {
    const div = document.createElement('div');
    div.className = 'item';
    let imgHtml = item.imgBlobUrl ? `<img src="${item.imgBlobUrl}" style="max-width:60px;max-height:60px;">` : (item.img ? `<img src="${item.img}" style="max-width:60px;max-height:60px;">` : '<div style="width:60px;height:60px;background:#eee;"></div>');
    div.innerHTML = imgHtml;
    list.appendChild(div);
  });
}

// 全屏图片画廊筛选
function renderFullscreenGallery(products, startIdx = 0) {
  const modal = document.getElementById('fullscreen-modal');
  const list = document.getElementById('fullscreen-list');
  list.innerHTML = '';
  if (!products.length) {
    list.innerHTML = '<p style="color:#fff;text-align:center;">暂无图片</p>';
    modal.style.display = 'block';
    return;
  }
  // 批量选择状态
  let selected = new Set();
  // 工具栏
  const toolbar = document.createElement('div');
  toolbar.style = 'width:100vw;text-align:center;margin-bottom:24px;';
  toolbar.innerHTML = `
    <button class="btn" id="select-all">全选</button>
    <button class="btn" id="deselect-all">取消全选</button>
    <button class="btn" id="delete-selected">批量删除</button>
    <span style="color:#fff;margin-left:16px;">已选 <span id="sel-count">0</span> 张</span>
  `;
  list.appendChild(toolbar);
  // 图片网格
  const grid = document.createElement('div');
  grid.style = 'display:flex;flex-wrap:wrap;gap:24px;justify-content:center;';
  products.forEach((item, idx) => {
    if (!(item.imgBlobUrl || item.img)) return;
    const div = document.createElement('div');
    div.style = 'position:relative;background:#222;border-radius:8px;padding:12px;box-shadow:0 2px 12px rgba(0,0,0,0.18);display:flex;flex-direction:column;align-items:center;';
    div.innerHTML = `
      <img src="${item.imgBlobUrl || item.img}" style="max-width:220px;max-height:220px;object-fit:contain;background:#fff;border-radius:6px;">
      <input type="checkbox" class="img-checkbox" data-idx="${idx}" style="margin-top:10px;transform:scale(1.5);">
    `;
    grid.appendChild(div);
  });
  list.appendChild(grid);
  // 事件绑定
  function updateSelCount() {
    document.getElementById('sel-count').innerText = selected.size;
  }
  list.querySelectorAll('.img-checkbox').forEach(cb => {
    cb.onchange = function() {
      const i = +cb.dataset.idx;
      if (cb.checked) selected.add(i); else selected.delete(i);
      updateSelCount();
    };
  });
  document.getElementById('select-all').onclick = function() {
    list.querySelectorAll('.img-checkbox').forEach(cb => { cb.checked = true; selected.add(+cb.dataset.idx); });
    updateSelCount();
  };
  document.getElementById('deselect-all').onclick = function() {
    list.querySelectorAll('.img-checkbox').forEach(cb => { cb.checked = false; });
    selected.clear();
    updateSelCount();
  };
  document.getElementById('delete-selected').onclick = function() {
    if (!selected.size) return;
    const remain = products.filter((_, i) => !selected.has(i));
    saveAllProducts(remain).then(() => renderFullscreenGallery(remain)).catch(e => {
      console.error('删除选中项目失败:', e);
    });
  };
  updateSelCount();
  modal.style.display = 'block';
}

document.getElementById('fullscreen-view').onclick = function() {
  getAllProducts().then(arr => renderFullscreenGallery(arr)).catch(e => {
    console.error('获取产品数据失败:', e);
  });
};
document.getElementById('close-fullscreen').onclick = function() {
  document.getElementById('fullscreen-modal').style.display = 'none';
};

// 智能标题处理函数（与gallery.js保持一致）
function getSmartTitle(product) {
  // 1. 优先使用保存的图片alt属性（最准确的标题）
  if (product.imgAlt && product.imgAlt.length > 15 && /[a-zA-Z]/.test(product.imgAlt)) {
    console.log(`📝 使用保存的图片alt属性: ${product.imgAlt.substring(0, 50)}...`);
    return product.imgAlt;
  }
  
  // 2. 如果原标题不是默认格式，直接使用
  if (product.title && 
      !product.title.startsWith('批量采集') && 
      !product.title.startsWith('商品') &&
      product.title.length > 10) {
    return product.title;
  }
  
  // 3. 生成基于时间的标题
  if (product.timestamp || product.addedAt) {
    const timestamp = product.timestamp || product.addedAt;
    const date = new Date(timestamp);
    const dateStr = date.toLocaleDateString('zh-CN');
    return `商品 ${dateStr}`;
  }
  
  // 4. 使用原标题作为最后备用
  return product.title || '未知商品';
}

document.getElementById('export-csv').onclick = async function() {
  try {
    const products = await getAllProducts();
    const { filterRegex, prohibitedRegex } = await loadWordRegexes();
    let totalFilterCleaned = 0;
    let totalProhibitedCleaned = 0;

    const header = ['商品ID','图片链接','商品标题'];
    const rows = products.map((p) => {
      let title = getSmartTitle(p) || '';
      const imgUrlRaw = p.img || '';
      let imgUrl = imgUrlRaw.includes('format/avif') ? imgUrlRaw.replace('format/avif', 'format/webp') : imgUrlRaw;

      if (filterRegex) totalFilterCleaned += [...title.matchAll(filterRegex)].length;
      if (prohibitedRegex) totalProhibitedCleaned += [...title.matchAll(prohibitedRegex)].length;
      title = applyClean(title, filterRegex, prohibitedRegex);

const exportedId = String(p.id || '').replace(/^kj/, 'SC');
return [exportedId, imgUrl, title];
    });

    const csv = header.join(',') + '\n' + rows.map(r => r.map(x => '"'+(x||'').replace(/"/g,'""')+'"').join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'temu_products.csv';
    a.click();
    URL.revokeObjectURL(url);

    alert(`✅ 成功导出 ${products.length} 条数据！\n• 清洗过滤词: ${totalFilterCleaned} 个\n• 清洗违禁词: ${totalProhibitedCleaned} 个`);
  } catch (e) {
    console.error('导出CSV失败:', e);
    alert('导出失败，请重试');
  }
};

document.getElementById('clear-all').onclick = function() {
  clearAllProducts().then(() => renderList([])).catch(e => {
    console.error('清空产品失败:', e);
    alert('清空失败，请重试');
  });
};

document.getElementById('batch-collect').onclick = function() {
  try {
    chrome.runtime.sendMessage({action: 'batchCollect'}).catch(err => {
      console.warn('批量采集消息发送失败:', err);
    });
  } catch (error) {
    console.error('批量采集按钮点击错误:', error);
  }
};

// IndexedDB操作
function getAllProducts() {
  return new Promise(resolve => {
    const tx = db.transaction(['products'], 'readonly');
    const store = tx.objectStore('products');
    const req = store.getAll();
    req.onsuccess = () => {
      const arr = req.result || [];
      arr.forEach(item => {
        if (item.imgBlob) {
          item.imgBlobUrl = URL.createObjectURL(item.imgBlob);
        }
      });
      resolve(arr);
    };
    req.onerror = () => resolve([]);
  });
}
function saveAllProducts(arr) {
  return new Promise(resolve => {
    const tx = db.transaction(['products'], 'readwrite');
    const store = tx.objectStore('products');
    store.clear().onsuccess = () => {
      // 去重逻辑：确保没有重复的图片链接
      const uniqueProducts = [];
      const seenImages = new Set();
      
      arr.forEach(item => {
        // 使用图片URL作为唯一标识（去除查询参数）
        const imgKey = item.img ? item.img.split('?')[0] : null;
        
        if (imgKey && !seenImages.has(imgKey)) {
          seenImages.add(imgKey);
          uniqueProducts.push(item);
        } else if (!imgKey) {
          // 如果没有图片URL，仍然添加项目
          uniqueProducts.push(item);
        } else {
          console.log('跳过重复商品:', imgKey);
        }
      });
      
      console.log(`去重后保存 ${uniqueProducts.length} 条数据（原 ${arr.length} 条）`);
      
      uniqueProducts.forEach(item => store.put(item));
      resolve();
    };
  });
}
function clearAllProducts() {
  return new Promise((resolve, reject) => {
    try {
      const tx = db.transaction(['products'], 'readwrite');
      const clearRequest = tx.objectStore('products').clear();
      clearRequest.onsuccess = () => resolve();
      clearRequest.onerror = (e) => {
        console.error('清空产品数据失败:', e);
        reject(e);
      };
      tx.onerror = (e) => {
        console.error('清空产品事务失败:', e);
        reject(e);
      };
    } catch (error) {
      console.error('清空产品操作失败:', error);
      reject(error);
    }
  });
}

// 先尝试通过后台统一检查更新（更稳定），失败再回退到直连 version.json
async function tryBackgroundUpdateCheck() {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage({ action: 'checkForUpdates' }, (resp) => {
        console.log('后台返回更新检查结果:', resp);
        resolve(resp || { updateAvailable: false });
      });
    } catch (e) {
      console.warn('后台检查更新失败，将回退直连:', e);
      resolve({ updateAvailable: false, error: e?.message });
    }
  });
}

// ====== 新增：在线版本检查与提示（在 popup 中执行） ======
function isNewerVersion(latest, current) {
  const lp = String(latest).split('.').map(Number);
  const cp = String(current).split('.').map(Number);
  for (let i = 0; i < Math.max(lp.length, cp.length); i++) {
    const ln = lp[i] || 0;
    const cn = cp[i] || 0;
    if (ln > cn) return true;
    if (ln < cn) return false;
  }
  return false;
}

async function checkAndPromptUpdateInPopup(currentVersion, proceedToGallery) {
  try {
    const resp = await fetch('https://aygtemu.github.io/temu-/version.json?t=' + Date.now(), { cache: 'no-cache' });
    if (!resp.ok) throw new Error('获取在线版本信息失败');

    // 尝试解析 JSON；若失败则不阻塞流程
    let info;
    try {
      info = await resp.json();
    } catch (parseErr) {
      console.warn('version.json 解析失败，跳过更新提示并进入画廊：', parseErr);
      await proceedToGallery();
      return true; // 已处理并进入画廊
    }

    const latestVersion = info.version;
    const updateContent = info.updateContent || '暂无更新说明';
    const downloadUrl = info.downloadUrl || 'https://aygtemu.github.io/temu-/temuSan_latest.zip';

    if (!isNewerVersion(latestVersion, currentVersion)) {
      return false; // 无更新，不显示提示
    }

    const overlay = document.createElement('div');
    overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.4);backdrop-filter:blur(2px);z-index:9999;display:flex;align-items:center;justify-content:center;';
    const panel = document.createElement('div');
    panel.style.cssText = 'max-width:520px;width:calc(100vw - 24px);max-height:85vh;overflow:auto;background:#fff;border-radius:12px;padding:18px;box-shadow:0 12px 40px rgba(0,0,0,0.25);text-align:left;';
    panel.innerHTML = `
      <h3 style="margin:0 0 8px;color:#ff6700;">发现新版本 ${latestVersion}</h3>
      <p style="margin:0 0 6px;color:#333;">当前版本：${currentVersion}</p>
      <div style="background:#f8f9fa;border:1px solid #eee;border-radius:8px;padding:10px;margin:10px 0;">
        <div style="font-weight:bold;margin-bottom:6px;color:#222;">更新内容：</div>
        <div style="white-space:pre-wrap;line-height:1.6;color:#444;max-height:40vh;overflow:auto;">${updateContent}</div>
      </div>
      <div style="background:#fff7e6;border:1px solid #ffe7ba;border-radius:8px;padding:10px;margin:10px 0;">
        <div style="font-weight:bold;margin-bottom:6px;color:#aa6a0a;">覆盖更新步骤（Windows）：</div>
        <ol style="padding-left:18px;color:#5c3c00;line-height:1.6;">
          <li>点击“立即更新”，浏览器开始下载压缩包（可选择保存位置）。</li>
          <li>下载完成后，右键压缩包选择“解压到…”，解压得到新版本文件夹。</li>
          <li>建议先备份旧版本：将原插件目录完整复制到 <code>d:\\temuSan插件_备份_日期</code>。</li>
          <li>用新版本文件夹内的全部文件覆盖原插件目录，例如 <code>d:\\temuSan插件</code>。</li>
          <li>打开 <code>chrome://extensions/</code>，开启“开发者模式”，找到 TEMU采集插件并点击“重新加载”。</li>
          <li>重新点击插件图标即可进入最新版本画廊。</li>
        </ol>
      </div>
      <div style="display:flex;gap:8px;justify-content:flex-end;margin-top:10px;">
        <button id="skip-update" style="background:#6c757d;color:#fff;border:none;padding:8px 10px;border-radius:6px;cursor:pointer;">暂不更新，进入画廊</button>
        <button id="do-update" style="background:#ff6700;color:#fff;border:none;padding:8px 10px;border-radius:6px;cursor:pointer;">立即更新</button>
      </div>
    `;
    overlay.appendChild(panel);
    document.body.appendChild(overlay);

    document.getElementById('skip-update').onclick = async () => {
      document.body.removeChild(overlay);
      await proceedToGallery();
    };
    const doUpdateBtnPopup = document.getElementById('do-update');
    doUpdateBtnPopup.onclick = () => {
      try {
        if (chrome.downloads && chrome.downloads.download) {
          // 使用下载API并监听完成后自动关闭弹窗
          doUpdateBtnPopup.disabled = true;
          doUpdateBtnPopup.textContent = '正在下载...';
          chrome.downloads.download({ url: downloadUrl, saveAs: true }, (downloadId) => {
            if (typeof downloadId === 'number') {
              const onChanged = function(delta) {
                if (delta.id === downloadId && delta.state && delta.state.current === 'complete') {
                  try { chrome.downloads.onChanged.removeListener(onChanged); } catch (_) {}
                  try { document.body.removeChild(overlay); } catch (_) {}
                } else if (delta.id === downloadId && delta.state && delta.state.current === 'interrupted') {
                  try { chrome.downloads.onChanged.removeListener(onChanged); } catch (_) {}
                  doUpdateBtnPopup.disabled = false;
                  doUpdateBtnPopup.textContent = '立即更新';
                  alert('下载被中断，请重试或手动打开下载链接。');
                }
              };
              try { chrome.downloads.onChanged.addListener(onChanged); } catch (_) {}
            } else {
              // 若无法获取下载ID，退回用新标签页打开
              try { window.open(downloadUrl, '_blank'); } catch (_) {}
            }
          });
        } else {
          // 无下载API则直接打开新标签页（无法自动侦测完成）
          try { window.open(downloadUrl, '_blank'); } catch (_) {}
        }
      } catch (e) {
        console.error('下载更新失败:', e);
        // 兜底提示，但不打断流程
        alert('下载更新失败，请稍后重试或手动打开下载链接。');
      }
    };

    return true; // 已显示提示
  } catch (error) {
    console.warn('检查更新失败（不阻塞进入画廊）:', error);
    return false; // 检查失败，继续正常流程
  }
}

// 页面初始化
async function initApp() {
  try {
    // 首先检查插件激活状态
    const { isActivated, version } = await checkPluginActivation();
    
    if (!isActivated) {
      // 如果未激活，显示激活提示
      showActivationPrompt();
      return;
    }

    const proceedToGallery = async () => {
      // 初始化数据库并在新标签页打开画廊，避免弹窗内出现全屏遮罩导致狭窄问题
      await initDB();
      setupUIByVersion(version);
      try {
        window.open(chrome.runtime.getURL('gallery.html'), '_blank');
        window.close();
      } catch (_) {
        // 回退：在弹窗中仅渲染列表，不默认打开全屏弹层
        const products = await getAllProducts();
        renderList(products);
        // 保留按钮触发全屏视图
      }
    };

    const currentVersion = chrome.runtime.getManifest().version;
    // 优先走后台检查，保证结果一致；如无更新或失败，再回退直连检查
    const bg = await tryBackgroundUpdateCheck();
    if (bg && bg.updateAvailable === true) {
      console.log(`检测到新版本(后台)：latest=${bg.version} current=${bg.currentVersion || currentVersion}`);
      const shown = await checkAndPromptUpdateInPopup(currentVersion, proceedToGallery);
      if (!shown) await proceedToGallery();
      return;
    }

    // 回退：直接检查 version.json
    const shown = await checkAndPromptUpdateInPopup(currentVersion, proceedToGallery);
    if (!shown) {
      await proceedToGallery();
    }
  } catch (error) {
    console.error('应用初始化失败:', error);
  }
}

// 启动应用
initApp();

// ==================== 导入导出功能 ====================

// 导出数据功能
document.getElementById('export-data').onclick = async function() {
  try {
    const products = await getAllProducts();
    if (products.length === 0) {
      alert('当前没有可导出的数据！');
      return;
    }

    const { filterRegex, prohibitedRegex } = await loadWordRegexes();
    let totalFilterCleaned = 0;
    let totalProhibitedCleaned = 0;

    // 准备导出数据结构（清洗 title 与 imgAlt）
    const exportData = {
      version: '1.0',
      exportTime: new Date().toISOString(),
      exportFilter: 'all',
      totalCount: products.length,
      data: products.map(item => {
        let title = getSmartTitle(item) || '';
        let imgAlt = item.imgAlt || '';
        if (filterRegex) {
          totalFilterCleaned += [...title.matchAll(filterRegex)].length;
          totalFilterCleaned += [...imgAlt.matchAll(filterRegex)].length;
        }
        if (prohibitedRegex) {
          totalProhibitedCleaned += [...title.matchAll(prohibitedRegex)].length;
          totalProhibitedCleaned += [...imgAlt.matchAll(prohibitedRegex)].length;
        }
        title = applyClean(title, filterRegex, prohibitedRegex);
        imgAlt = applyClean(imgAlt, filterRegex, prohibitedRegex);
        return {
          id: item.id,
          title,
          img: item.img,
          imgAlt,
          url: item.url,
          time: item.time,
          timestamp: item.timestamp,
          addedAt: item.addedAt,
          sourceUrl: item.sourceUrl,
          type: item.type || 'collected',
          category: item.category || '采集记录',
          status: item.status || 'collected'
        };
      })
    };

    // 生成文件名
    const now = new Date();
    const dateStr = now.toISOString().slice(0, 19).replace(/[:-]/g, '').replace('T', '_');
    const fileName = `TEMU画廊数据_全部_${dateStr}.json`;

    // 创建并下载文件
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    console.log(`✅ 已导出 ${products.length} 条数据到文件: ${fileName}`);
    alert(`✅ 成功导出 ${products.length} 条数据！\n• 清洗过滤词: ${totalFilterCleaned} 个\n• 清洗违禁词: ${totalProhibitedCleaned} 个\n文件名: ${fileName}`);
  } catch (e) {
    console.error('导出数据失败:', e);
    alert('导出数据失败，请重试！');
  }
};

// 导入数据功能
document.getElementById('import-data').onclick = function() {
  const fileInput = document.getElementById('import-file');
  fileInput.click();
};

// 处理文件导入
document.getElementById('import-file').onchange = function(event) {
  const file = event.target.files[0];
  if (!file) return;
  
  if (!file.name.endsWith('.json')) {
    alert('请选择有效的 JSON 数据文件！');
    return;
  }
  
  const reader = new FileReader();
  reader.onload = async function(e) {
    try {
      const jsonData = JSON.parse(e.target.result);
      
      // 验证数据格式
      if (!jsonData.version || !jsonData.data || !Array.isArray(jsonData.data)) {
        throw new Error('文件格式不正确，请选择有效的画廊数据文件！');
      }
      
      const importData = jsonData.data;
      if (importData.length === 0) {
        alert('文件中没有可导入的数据！');
        return;
      }
      
      // 询问导入方式
      const importMode = confirm(
        `检测到 ${importData.length} 条数据\n` +
        `导出时间: ${new Date(jsonData.exportTime).toLocaleString('zh-CN')}\n\n` +
        `选择导入方式:\n` +
        `确定 = 追加导入（保留现有数据）\n` +
        `取消 = 替换导入（清空现有数据后导入）`
      );
      
      const existingProducts = await getAllProducts();
      let successCount = 0;
      let duplicateCount = 0;
      let errorCount = 0;
      
      if (importMode) {
        // 追加模式：检查重复
        console.log('📥 开始追加导入数据...');
        
        const existingIds = new Set(existingProducts.map(p => p.id));
        const newProducts = [...existingProducts];
        
        for (const item of importData) {
          try {
            // 检查是否重复
            if (existingIds.has(item.id)) {
              duplicateCount++;
              console.log(`⚠️ 跳过重复数据: ${item.id}`);
              continue;
            }
            
            // 确保数据完整性
            const newItem = {
              id: item.id || `import_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
              title: item.title || '导入的商品',
              img: item.img,
              imgAlt: item.imgAlt || '',
              url: item.url || '',
              time: item.time || new Date().toISOString(),
              timestamp: item.timestamp || Date.now(),
              addedAt: item.addedAt || Date.now(),
              sourceUrl: item.sourceUrl || item.url || '',
              type: item.type || 'collected',
              category: item.category || '导入数据',
              status: item.status || 'collected'
            };
            
            newProducts.push(newItem);
            successCount++;
            
          } catch (error) {
            console.error('导入单条数据失败:', error, item);
            errorCount++;
          }
        }
        
        await saveAllProducts(newProducts);
        
      } else {
        // 替换模式：清空后导入
        if (!confirm('⚠️ 替换导入将清空所有现有数据，确定要继续吗？\n\n此操作不可撤销！')) {
          return;
        }
        
        console.log('🔄 开始替换导入数据...');
        
        const newProducts = [];
        
        // 导入新数据
        for (const item of importData) {
          try {
            const newItem = {
              id: item.id || `import_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
              title: item.title || '导入的商品',
              img: item.img,
              imgAlt: item.imgAlt || '',
              url: item.url || '',
              time: item.time || new Date().toISOString(),
              timestamp: item.timestamp || Date.now(),
              addedAt: item.addedAt || Date.now(),
              sourceUrl: item.sourceUrl || item.url || '',
              type: item.type || 'collected',
              category: item.category || '导入数据',
              status: item.status || 'collected'
            };
            
            newProducts.push(newItem);
            successCount++;
            
          } catch (error) {
            console.error('导入单条数据失败:', error, item);
            errorCount++;
          }
        }
        
        await saveAllProducts(newProducts);
      }
      
      // 刷新页面显示
      const updatedProducts = await getAllProducts();
      renderList(updatedProducts);
      renderFullscreenGallery(updatedProducts);
      
      // 清空文件输入
      event.target.value = '';
      
      // 显示导入结果
      let resultMessage = `✅ 数据导入完成！\n\n`;
      resultMessage += `成功导入: ${successCount} 条\n`;
      if (duplicateCount > 0) {
        resultMessage += `跳过重复: ${duplicateCount} 条\n`;
      }
      if (errorCount > 0) {
        resultMessage += `导入失败: ${errorCount} 条\n`;
      }
      resultMessage += `\n当前总数据: ${updatedProducts.length} 条`;
      
      alert(resultMessage);
      
      console.log(`📥 导入完成: 成功 ${successCount}, 重复 ${duplicateCount}, 失败 ${errorCount}`);
      
    } catch (error) {
      console.error('解析导入文件失败:', error);
      alert('文件格式错误或损坏，请检查文件是否为有效的画廊数据文件！');
    }
  };
  
  reader.onerror = function() {
    alert('读取文件失败，请重试！');
  };
  
  reader.readAsText(file, 'utf-8');
};


// 词库加载与清洗辅助
const PROHIBITED_WORDS_KEY = 'temu_prohibited_words';
const FILTER_WORDS_KEY = 'temu_filter_words';
async function loadWordRegexes() {
  return new Promise(resolve => {
    try {
      chrome.storage?.local?.get([PROHIBITED_WORDS_KEY, FILTER_WORDS_KEY], (res) => {
        const prohibited = new Set(res?.[PROHIBITED_WORDS_KEY] || []);
        const filter = new Set(res?.[FILTER_WORDS_KEY] || []);
        const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const build = (set, useWordBoundary) => {
          const words = Array.from(set).map(w => (w||'').trim()).filter(Boolean);
          if (!words.length) return null;
          const pattern = words.map(escapeRegex).join('|');
          const base = useWordBoundary ? `\\b(${pattern})\\b` : `(${pattern})`;
          return new RegExp(base, 'gi');
        };
        resolve({
          filterRegex: build(filter, false),
          prohibitedRegex: build(prohibited, true)
        });
      });
    } catch (e) {
      resolve({ filterRegex: null, prohibitedRegex: null });
    }
  });
}
function applyClean(text, filterRegex, prohibitedRegex) {
  if (!text) return text;
  let t = text;
  if (filterRegex) t = t.replace(filterRegex, '');
  if (prohibitedRegex) t = t.replace(prohibitedRegex, '');
  return t.replace(/\s+/g, ' ').trim();
}
