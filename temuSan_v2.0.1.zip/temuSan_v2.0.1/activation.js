// 生成机器码（基于浏览器信息和系统信息）
function generateMachineCode() {
  // 获取浏览器和系统信息（尽可能使用稳定的特征）
  const navigatorInfo = {
    // 使用经过处理的userAgent，移除可能变化的部分
    userAgent: navigator.userAgent.replace(/Chrome\/\d+\.\d+/, 'Chrome').replace(/Firefox\/\d+\.\d+/, 'Firefox'),
    platform: navigator.platform,
    language: navigator.language,
    hardwareConcurrency: navigator.hardwareConcurrency || 'unknown',
    deviceMemory: navigator.deviceMemory || 'unknown',
    // 添加一些稳定性更高的信息
    screenWidth: screen.width,
    screenHeight: screen.height,
    colorDepth: screen.colorDepth
  };
  
  // 创建一个基于这些信息的哈希值作为机器码
  const infoStr = JSON.stringify(navigatorInfo);
  let hash = 0;
  if (infoStr.length === 0) return hash;
  for (let i = 0; i < infoStr.length; i++) {
    const char = infoStr.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32bit integer
  }
  
  // 将哈希值转换为16进制字符串并格式化
  const hexHash = Math.abs(hash).toString(16);
  const formattedHash = hexHash.padStart(16, '0');
  
  // 将机器码格式化为更易读的形式，例如：XXXX-XXXX-XXXX-XXXX
  const parts = [];
  for (let i = 0; i < formattedHash.length; i += 4) {
    parts.push(formattedHash.substr(i, 4));
  }
  
  return parts.join('-');
}

// 复制文本到剪贴板
function copyToClipboard(text) {
  return navigator.clipboard.writeText(text).then(() => {
    showNotification('复制成功！', 'success');
  }).catch(err => {
    console.error('复制失败:', err);
    showNotification('复制失败，请手动复制', 'error');
    
    // 降级方案：使用传统的复制方法
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.left = '-999999px';
    textArea.style.top = '-999999px';
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    try {
      document.execCommand('copy');
      showNotification('复制成功！', 'success');
    } catch (err) {
      showNotification('复制失败，请手动复制', 'error');
    }
    document.body.removeChild(textArea);
  });
}

// 显示通知信息
function showNotification(message, type = 'info') {
  const resultElement = document.getElementById('activation-result');
  resultElement.textContent = message;
  resultElement.className = 'activation-result';
  resultElement.classList.add(type);
  resultElement.style.display = 'block'; // 确保通知显示出来
  
  // 3秒后自动隐藏通知
  setTimeout(() => {
    resultElement.style.display = 'none';
  }, 3000);
}

// 复制全部信息
function copyAllInfo() {
  const machineCode = document.getElementById('machine-code').textContent;
  const contact = document.getElementById('contact').value;
  const versionSelect = document.getElementById('version');
  const version = versionSelect.options[versionSelect.selectedIndex].text;
  
  if (!contact) {
    showNotification('请先填写联系方式', 'error');
    return;
  }
  
  const allInfo = `机器码: ${machineCode}\n联系方式: ${contact}\n版本: ${version}`;
  copyToClipboard(allInfo);
}

// 保存版本信息
function saveVersionInfo(version) {
  chrome.storage.local.set({
    pluginVersion: version
  }, () => {
    console.log('版本信息已保存:', version);
  });
}

// 验证激活码
function verifyActivationCode() {
  const activationCode = document.getElementById('activation-code').value.trim();
  const machineCode = document.getElementById('machine-code').textContent;
  const contact = document.getElementById('contact').value.trim();
  // 注意：这里不再使用页面上的版本选择，而是从激活码中解析版本信息
  
  if (!activationCode) {
    showNotification('请输入激活码', 'error');
    return;
  }
  
  if (!contact) {
    showNotification('请输入联系方式', 'error');
    return;
  }
  
  try {
    // 解析激活码，同时验证联系方式
    const parsedResult = parseActivationCode(activationCode, machineCode, contact);
    
    // 检查激活码是否已过期
    if (parsedResult.expired) {
      showNotification('该激活码已过期，请使用新的激活码', 'error');
      return;
    }
    
    if (!parsedResult.valid) {
      // 提供更具体的错误信息
      showNotification('激活码无效、与机器码不匹配或联系方式不匹配', 'error');
      // 在控制台显示详细信息，方便调试
      console.log('激活失败详情 - 激活码格式检查:', {
        activationCode: activationCode,
        machineCode: machineCode,
        contact: contact
      });
      return;
    }
    
    // 获取激活天数和版本信息
    const activationDays = parsedResult.days;
    const version = parsedResult.version;
    const generatedTime = parsedResult.generatedTime;
    
    // 检查激活码是否已被使用
    if (checkIfActivationCodeUsed(activationCode)) {
      showNotification('该激活码已被使用，请使用新的激活码', 'error');
      return;
    }
    
    // 计算激活到期时间
    const now = new Date();
    const expireDate = new Date(generatedTime.getTime() + activationDays * 24 * 60 * 60 * 1000);
    
    // 保存激活状态，包括版本信息和激活码
    saveActivationStatus(true, machineCode, expireDate.toISOString(), version, activationCode);
    
    // 显示成功信息，包括到期时间
    const expireDateString = expireDate.toLocaleDateString('zh-CN');
    showNotification(`激活成功！到期时间：${expireDateString}，即将跳转到主界面...`, 'success');
    
    // 2秒后跳转到popup.html
    setTimeout(() => {
      window.location.href = 'popup.html';
    }, 2000);
  } catch (error) {
    console.error('激活码验证失败:', error);
    // 提供更详细的错误信息，帮助用户理解问题
    showNotification('激活码验证失败，请检查激活码格式是否正确', 'error');
    console.log('激活失败错误详情:', error);
  }
}

// 检查激活码是否已被使用
function checkIfActivationCodeUsed(activationCode) {
  try {
    // 从localStorage读取已使用的激活码信息
    const usedCodes = localStorage.getItem('usedActivationCodes');
    const usedCodesArray = usedCodes ? JSON.parse(usedCodes) : [];
    
    // 检查激活码是否已在使用列表中
    return usedCodesArray.includes(activationCode);
  } catch (error) {
    console.error('检查激活码使用状态失败:', error);
    // 出错时默认返回false，避免误判
    return false;
  }
}

// 解析激活码
function parseActivationCode(activationCode, machineCode, contact) {
  try {
    // 激活码格式：天数版本生成时间-机器码前缀-联系方式哈希前缀
    const parts = activationCode.split('-');
    
    if (parts.length !== 3) {
      return { valid: false, reason: 'activation_code_format' };
    }
    
    // 解析天数、版本信息和生成时间
    const infoPart = parts[0];
    if (infoPart.length < 13) { // 至少需要13位：4位天数+1位版本+8位时间戳
      return { valid: false, reason: 'activation_code_too_short' };
    }
    
    // 前4位是天数
    const daysStr = infoPart.substring(0, 4);
    const days = parseInt(daysStr);
    
    // 第5位是版本编码
    const versionCode = infoPart.charAt(4);
    const version = versionCode === '1' ? 'single' : versionCode === '2' ? 'batch' : null;
    
    // 后8位是生成时间戳（Unix时间戳的前8位，16进制）
    const timestampStr = infoPart.substring(5, 13);
    const timestamp = parseInt(timestampStr, 16); // 16进制转10进制
    
    // 验证机器码前缀
    const machineCodeHash = simpleHash(machineCode);
    const machineCodePrefix = Math.abs(machineCodeHash).toString(16).substring(0, 8).toUpperCase();
    
    if (parts[1] !== machineCodePrefix) {
      return { valid: false, reason: 'machine_code_mismatch' };
    }
    
    // 验证联系方式哈希前缀
    const contactHash = simpleHash(contact);
    const contactHashPrefix = Math.abs(contactHash).toString(16).substring(0, 4).toUpperCase();
    
    if (parts[2] !== contactHashPrefix) {
      return { valid: false, reason: 'contact_mismatch' };
    }
    
    // 验证天数和版本是否有效
    if (isNaN(days) || days <= 0 || !version) {
      return { valid: false, reason: 'invalid_days_or_version' };
    }
    
    // 检查天数是否合理（防止过长的有效期）
    // 假设最大有效期为3650天（约10年），超过这个时间的激活码视为无效
    if (days > 3650) {
      return { valid: false, reason: 'invalid_days_range' };
    }
    
    // 检查激活码是否已过期
    // 计算激活码的过期时间
    const generatedTime = new Date(timestamp * 1000); // 时间戳转毫秒
    const expireTime = new Date(generatedTime.getTime() + days * 24 * 60 * 60 * 1000);
    const now = new Date();
    
    // 如果当前时间超过了激活码的过期时间，说明激活码已过期
    if (now > expireTime) {
      return { valid: false, expired: true, reason: 'activation_code_expired' };
    }
    
    return { valid: true, days: days, version: version, generatedTime: generatedTime };
  } catch (error) {
    console.error('解析激活码失败:', error);
    return { valid: false, reason: 'parsing_error' };
  }
}

// 增强verifyActivationCode函数，使用更具体的错误原因
function verifyActivationCode() {
  const activationCode = document.getElementById('activation-code').value.trim();
  const machineCode = document.getElementById('machine-code').textContent;
  const contact = document.getElementById('contact').value.trim();
  // 注意：这里不再使用页面上的版本选择，而是从激活码中解析版本信息
  
  if (!activationCode) {
    showNotification('请输入激活码', 'error');
    return;
  }
  
  if (!contact) {
    showNotification('请输入联系方式', 'error');
    return;
  }
  
  try {
    // 解析激活码，同时验证联系方式
    const parsedResult = parseActivationCode(activationCode, machineCode, contact);
    
    // 检查激活码是否已过期
    if (parsedResult.expired) {
      showNotification('该激活码已过期，请使用新的激活码', 'error');
      return;
    }
    
    if (!parsedResult.valid) {
      // 根据失败原因显示更具体的错误信息
      let errorMessage = '激活码验证失败';
      switch(parsedResult.reason) {
        case 'activation_code_format':
          errorMessage = '激活码格式错误，请检查格式是否正确';
          break;
        case 'activation_code_too_short':
          errorMessage = '激活码长度不足，请检查是否输入完整';
          break;
        case 'machine_code_mismatch':
          errorMessage = '激活码与机器码不匹配，请使用对应您机器的激活码';
          break;
        case 'contact_mismatch':
          errorMessage = '激活码与联系方式不匹配，请检查联系方式是否正确';
          break;
        case 'invalid_days_or_version':
          errorMessage = '激活码中的天数或版本信息无效';
          break;
        case 'invalid_days_range':
          errorMessage = '激活码有效期过长，可能是无效的激活码';
          break;
        case 'activation_code_expired':
          errorMessage = '该激活码已过期，请使用新的激活码';
          break;
        case 'parsing_error':
          errorMessage = '激活码解析失败，请检查激活码格式是否正确';
          break;
        default:
          errorMessage = '激活码无效、与机器码不匹配或联系方式不匹配';
      }
      
      showNotification(errorMessage, 'error');
      // 在控制台显示详细信息，方便调试
      console.log('激活失败详情:', {
        activationCode: activationCode,
        machineCode: machineCode,
        contact: contact,
        reason: parsedResult.reason
      });
      return;
    }
    
    // 获取激活天数和版本信息
    const activationDays = parsedResult.days;
    const version = parsedResult.version;
    const generatedTime = parsedResult.generatedTime;
    
    // 检查激活码是否已被使用
    if (checkIfActivationCodeUsed(activationCode)) {
      showNotification('该激活码已被使用，请使用新的激活码', 'error');
      return;
    }
    
    // 计算激活到期时间
    const now = new Date();
    const expireDate = new Date(generatedTime.getTime() + activationDays * 24 * 60 * 60 * 1000);
    
    // 保存激活状态，包括版本信息和激活码
    saveActivationStatus(true, machineCode, expireDate.toISOString(), version, activationCode);
    
    // 显示成功信息，包括到期时间
    const expireDateString = expireDate.toLocaleDateString('zh-CN');
    showNotification(`激活成功！到期时间：${expireDateString}，即将跳转到主界面...`, 'success');
    
    // 2秒后跳转到popup.html
    setTimeout(() => {
      window.location.href = 'popup.html';
    }, 2000);
  } catch (error) {
    console.error('激活码验证失败:', error);
    // 提供更详细的错误信息，帮助用户理解问题
    showNotification('激活码验证过程中发生错误，请检查激活码格式是否正确', 'error');
    console.log('激活失败错误详情:', error);
  }
}

// 简单哈希函数
function simpleHash(str) {
  let hash = 0;
  if (str.length === 0) return hash;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32bit integer
  }
  return hash;
}

// 保存激活状态
function saveActivationStatus(isActivated, machineCode, expireDate, version, activationCode) {
  const dataToSave = {
    pluginActivated: isActivated,
    activatedMachineCode: machineCode,
    activationDate: new Date().toISOString(),
    pluginVersion: version,
    usedActivationCode: activationCode // 保存使用的激活码
  };
  
  // 如果有到期时间，也保存到期时间
  if (expireDate) {
    dataToSave.expireDate = expireDate;
  }
  
  chrome.storage.local.set(dataToSave, () => {
    console.log('激活状态已保存:', { isActivated, machineCode, version, expireDate, activationCode });
    
    // 如果是激活操作，将激活码添加到已使用列表
    if (isActivated && activationCode) {
      addUsedActivationCode(activationCode);
    }
  });
}

// 添加已使用的激活码到记录
function addUsedActivationCode(activationCode) {
  try {
    // 从localStorage读取已使用的激活码信息
    const usedCodes = localStorage.getItem('usedActivationCodes');
    const usedCodesArray = usedCodes ? JSON.parse(usedCodes) : [];
    
    // 如果激活码不在列表中，则添加
    if (!usedCodesArray.includes(activationCode)) {
      usedCodesArray.push(activationCode);
      // 保存更新后的列表
      localStorage.setItem('usedActivationCodes', JSON.stringify(usedCodesArray));
      console.log('激活码已添加到已使用列表');
    }
  } catch (error) {
    console.error('保存已使用激活码失败:', error);
  }
}

// 检查是否已经激活
function checkActivationStatus() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['pluginActivated'], (result) => {
      const isActivated = result.pluginActivated || false;
      resolve(isActivated);
    });
  });
}

// 初始化页面
async function initPage() {
  // 检查是否已经激活
  const isActivated = await checkActivationStatus();
  
  if (isActivated) {
    // 如果已经激活，直接跳转到主界面
    window.location.href = 'popup.html';
    return;
  }
  
  // 生成并显示机器码
  const machineCode = generateMachineCode();
  document.getElementById('machine-code').textContent = machineCode;
  
  // 绑定一键复制全部信息按钮事件
  document.getElementById('copy-all-info').addEventListener('click', copyAllInfo);
  
  // 绑定验证激活码按钮事件
  document.getElementById('verify-activation-code').addEventListener('click', verifyActivationCode);
  
  // 当版本选择改变时保存版本信息
  document.getElementById('version').addEventListener('change', (e) => {
    saveVersionInfo(e.target.value);
  });
  
  // 默认保存当前选择的版本
  const defaultVersion = document.getElementById('version').value;
  saveVersionInfo(defaultVersion);
}

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', initPage);